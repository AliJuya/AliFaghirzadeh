"""
AeroSecLab Recon Engine — Analysis: Swagger / OpenAPI Intelligence

Discovers and extracts Swagger / OpenAPI specifications from common paths.
Builds a complete endpoint inventory from each spec including:
  - all paths + HTTP methods
  - parameters (query, body, header, path)
  - authentication schemes
  - sensitive endpoints (admin, auth, financial, internal)

Detection-only — only fetches publicly-served spec files.
"""

from __future__ import annotations

import concurrent.futures
import json
import re
from pathlib import Path
from typing import Dict, List, Set
from urllib.parse import urljoin

from ..core.models import ModuleReport, ReconReport, Finding, Parameter
from ..core.config import REQUEST_TIMEOUT
from ..core.logger import log
from ..core.http_utils import safe_get


MODULE_NAME = "swagger_intel"


SPEC_PATHS = [
    "/swagger.json", "/swagger.yaml", "/swagger.yml",
    "/openapi.json", "/openapi.yaml", "/openapi.yml",
    "/v2/api-docs", "/v3/api-docs", "/v3/api-docs.yaml",
    "/api-docs", "/api-docs/swagger.json",
    "/api/swagger.json", "/api/openapi.json", "/api/v1/swagger.json",
    "/api/v2/swagger.json", "/api/v3/swagger.json",
    "/swagger/v1/swagger.json", "/swagger/v2/swagger.json",
    "/api/swagger/v1/swagger.json",
    "/swagger-ui/swagger.json", "/swagger-ui.html",
    "/swagger-resources",
    "/docs/swagger.json", "/docs/api/swagger.json",
    "/api/spec", "/api/spec.json",
    "/.well-known/openapi.json",
]

SENSITIVE_PATH_KEYWORDS = [
    "admin", "auth", "login", "logout", "password", "token", "secret",
    "credential", "apikey", "api_key", "key",
    "user", "users", "account", "profile",
    "transfer", "withdraw", "deposit", "send", "fund", "wallet",
    "payment", "pay", "balance", "invoice", "checkout", "card",
    "internal", "private", "debug", "test", "dev",
    "delete", "drop", "remove", "destroy",
    "upload", "download", "export", "import",
    "config", "settings", "manage",
    "role", "permission", "grant",
    "kyc", "verify", "approve",
]


def run(
    target     : str,
    report     : ReconReport,
    mod_report : ModuleReport,
    output_dir : Path,
):
    log("INFO", target, "Swagger / OpenAPI Intel — starting")

    if not report.live_hosts:
        mod_report.summary = {"skipped": "no live hosts"}
        return

    # Generate candidate URLs
    candidates: Set[str] = set()
    for host in report.live_hosts:
        for path in SPEC_PATHS:
            candidates.add(host.url.rstrip("/") + path)

    # Also use crawler discoveries
    for link in (report.crawled_links or []):
        url = link.url if hasattr(link, 'url') else str(link)
        url_l = url.lower()
        if any(p in url_l for p in ["swagger.json", "openapi.json",
                                     "api-docs", "api/spec"]):
            candidates.add(url)

    log("INFO", target, f"  Probing {len(candidates)} spec candidates")

    findings: List[Finding] = []
    specs:    List[Dict] = []
    discovered_params: List[Parameter] = []

    with concurrent.futures.ThreadPoolExecutor(max_workers=10) as ex:
        futures = {ex.submit(_fetch_and_parse_spec, url): url
                   for url in list(candidates)[:80]}
        for fut in concurrent.futures.as_completed(futures):
            try:
                result = fut.result()
                if not result:
                    continue
                specs.append(result)
                findings.extend(_findings_from_spec(result))
                discovered_params.extend(_params_from_spec(result))
            except Exception:
                pass

    # Add discovered parameters to report
    if discovered_params:
        existing = {(p.url, p.name, p.method) for p in report.parameters}
        for p in discovered_params:
            if (p.url, p.name, p.method) not in existing:
                report.parameters.append(p)
                existing.add((p.url, p.name, p.method))

    mod_report.findings.extend(findings)
    mod_report.summary = {
        "candidates_probed": len(candidates),
        "specs_found"      : len(specs),
        "endpoints_total"  : sum(s.get("endpoint_count", 0) for s in specs),
        "params_discovered": len(discovered_params),
        "findings"         : len(findings),
        "spec_urls"        : [s["url"] for s in specs],
    }
    mod_report.data = {
        "specs": [
            {
                "url": s["url"],
                "title": s.get("title", ""),
                "version": s.get("version", ""),
                "endpoint_count": s.get("endpoint_count", 0),
                "auth_schemes": s.get("auth_schemes", []),
                "sensitive_endpoints": s.get("sensitive_endpoints", [])[:50],
                "all_endpoints_sample": s.get("endpoints", [])[:200],
            }
            for s in specs
        ],
    }

    # Save full specs
    if specs:
        spec_dir = output_dir / "swagger"
        spec_dir.mkdir(exist_ok=True)
        for i, s in enumerate(specs):
            (spec_dir / f"spec_{i}.json").write_text(
                json.dumps(s.get("raw", {}), indent=2, default=str)[:1000000]
            )

    log("OK", target, f"  Swagger Intel complete: {len(specs)} specs, "
        f"{sum(s.get('endpoint_count',0) for s in specs)} endpoints discovered")


def _fetch_and_parse_spec(url: str) -> Dict:
    """Fetch URL and try to parse as Swagger/OpenAPI spec."""
    r = safe_get(url, timeout=10)
    if r is None or r.status_code != 200:
        return {}

    body = (r.text or "")[:5_000_000]  # 5MB cap
    spec = None

    # Try JSON
    if body.lstrip().startswith("{"):
        try:
            spec = json.loads(body)
        except Exception:
            pass

    # Try YAML if installed
    if spec is None and (body.lstrip().startswith(("openapi:", "swagger:", "info:"))):
        try:
            import yaml  # may not be installed
            spec = yaml.safe_load(body)
        except Exception:
            pass

    if not isinstance(spec, dict):
        return {}

    # Validate it's a Swagger/OpenAPI spec
    is_swagger_v2 = "swagger" in spec
    is_openapi_v3 = "openapi" in spec
    if not (is_swagger_v2 or is_openapi_v3):
        return {}

    info = spec.get("info", {}) or {}
    paths = spec.get("paths", {}) or {}

    endpoints: List[Dict] = []
    sensitive_endpoints: List[Dict] = []

    for path, path_obj in paths.items():
        if not isinstance(path_obj, dict):
            continue
        for method, op in path_obj.items():
            if method.lower() not in ("get", "post", "put", "delete", "patch",
                                       "head", "options"):
                continue
            if not isinstance(op, dict):
                continue
            ep = {
                "path": path,
                "method": method.upper(),
                "summary": (op.get("summary", "") or "")[:200],
                "operationId": op.get("operationId", ""),
                "tags": op.get("tags", []),
                "params": _summarize_params(op.get("parameters", []) or []),
                "auth_required": bool(op.get("security")),
            }
            endpoints.append(ep)
            # Sensitive?
            path_lower = path.lower()
            summary_lower = (op.get("summary", "") or "").lower()
            for kw in SENSITIVE_PATH_KEYWORDS:
                if kw in path_lower or kw in summary_lower:
                    ep["sensitive_keyword"] = kw
                    sensitive_endpoints.append(ep)
                    break

    # Auth schemes
    auth_schemes = []
    if is_openapi_v3:
        components = spec.get("components", {}) or {}
        sec_schemes = components.get("securitySchemes", {}) or {}
        auth_schemes = list(sec_schemes.keys())
    elif is_swagger_v2:
        sec_defs = spec.get("securityDefinitions", {}) or {}
        auth_schemes = list(sec_defs.keys())

    return {
        "url": url,
        "title": info.get("title", ""),
        "version": info.get("version", ""),
        "spec_type": "openapi3" if is_openapi_v3 else "swagger2",
        "endpoint_count": len(endpoints),
        "endpoints": endpoints,
        "sensitive_endpoints": sensitive_endpoints,
        "auth_schemes": auth_schemes,
        "raw": spec,
    }


def _summarize_params(params: List[Dict]) -> List[Dict]:
    summary = []
    for p in params:
        if not isinstance(p, dict):
            continue
        summary.append({
            "name": p.get("name", ""),
            "in":   p.get("in", ""),
            "required": p.get("required", False),
            "type": (p.get("schema", {}) or {}).get("type") or p.get("type", ""),
        })
    return summary


def _findings_from_spec(spec: Dict) -> List[Finding]:
    findings = []
    url = spec["url"]

    findings.append(Finding(
        severity    = "info",
        title       = (f"API specification disclosed: {spec.get('title','')} "
                       f"v{spec.get('version','')}"),
        url         = url,
        evidence    = (f"{spec.get('spec_type','spec')} spec with "
                       f"{spec.get('endpoint_count', 0)} endpoints, "
                       f"{len(spec.get('auth_schemes', []))} auth schemes"),
        module      = MODULE_NAME,
        remediation = ("Verify spec disclosure is intentional. Consider serving spec only "
                       "to authenticated users in production."),
        tags        = ["swagger", "openapi", "info-disclosure"],
    ))

    # Sensitive endpoints
    sens = spec.get("sensitive_endpoints", [])
    if sens:
        sample = sens[:8]
        evidence = "; ".join(f"{e['method']} {e['path']}" for e in sample)
        # Check if any sensitive endpoint has auth_required=False
        no_auth = [e for e in sens if not e.get("auth_required")]
        sev = "high" if no_auth else "medium"
        findings.append(Finding(
            severity    = sev,
            title       = (f"Sensitive API endpoints exposed in spec: {len(sens)} found"),
            url         = url,
            evidence    = (f"{len(sens)} endpoints match sensitive keywords. "
                           f"{len(no_auth)} appear to NOT require auth. "
                           f"Examples: {evidence}"),
            module      = MODULE_NAME,
            remediation = ("Audit authorization on these endpoints. Confirm 'security' "
                           "is set in the OpenAPI spec for each sensitive op."),
            tags        = ["swagger", "sensitive-endpoints", "attack-surface"] +
                          (["auth-bypass-candidate"] if no_auth else []),
        ))

    # No auth schemes at all
    if not spec.get("auth_schemes"):
        findings.append(Finding(
            severity    = "medium",
            title       = f"API spec defines NO auth schemes: {url}",
            url         = url,
            evidence    = "No securityDefinitions / securitySchemes in spec",
            module      = MODULE_NAME,
            remediation = "Define and apply security requirements to operations.",
            tags        = ["swagger", "no-auth"],
        ))

    return findings


def _params_from_spec(spec: Dict) -> List[Parameter]:
    """Convert spec endpoints into Parameter objects for the global inventory."""
    params: List[Parameter] = []
    base_url = spec["url"].rsplit("/", 1)[0]  # crude

    for ep in spec.get("endpoints", []):
        ep_url = base_url + ep["path"]
        for p in ep.get("params", []):
            param_in = p.get("in", "query")
            params.append(Parameter(
                name=p.get("name", ""),
                url=ep_url,
                method=ep["method"],
                type=param_in,
                example=str(p.get("type", "")),
            ))
    return params
