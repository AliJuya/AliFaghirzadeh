"""
AeroSecLab Recon Engine — Analysis: Cloud Asset Discovery

Generates likely cloud bucket names from target metadata and probes them
for existence on AWS S3, GCS, and Azure Blob. Reports:
  - bucket exists + publicly listable (critical)
  - bucket exists + access denied (medium)
  - bucket does not exist (info, may be claimable)

Detection-only — only GET/HEAD requests. No uploads, no writes.
"""

from __future__ import annotations

import concurrent.futures
import re
import string
from pathlib import Path
from typing import Dict, List, Set

from ..core.models import ModuleReport, ReconReport, Finding
from ..core.config import REQUEST_TIMEOUT
from ..core.logger import log
from ..core.http_utils import safe_get


MODULE_NAME = "cloud_assets"


# Common suffixes organizations use for their buckets
BUCKET_SUFFIXES = [
    "", "-backup", "-backups", "-prod", "-production", "-dev", "-development",
    "-stg", "-staging", "-test", "-qa", "-uat", "-demo",
    "-assets", "-static", "-media", "-images", "-files", "-uploads",
    "-data", "-logs", "-archive", "-archives",
    "-public", "-private", "-internal", "-external",
    "-us", "-eu", "-ap", "-east", "-west",
    "-app", "-web", "-api",
    "-v1", "-v2",
    "-reports", "-exports", "-dumps",
    "-ci", "-cd", "-cicd", "-build",
]


def run(
    target     : str,
    report     : ReconReport,
    mod_report : ModuleReport,
    output_dir : Path,
):
    log("INFO", target, "Cloud Asset Discovery — starting")

    # Base names to permute: apex without TLD, common brand variants
    base_names = _generate_base_names(target, report)

    # Generate all candidates
    bucket_names = set()
    for base in base_names:
        for suffix in BUCKET_SUFFIXES:
            name = f"{base}{suffix}"
            if _is_valid_bucket_name(name):
                bucket_names.add(name)

    log("INFO", target, f"  Generated {len(bucket_names)} candidate bucket names "
        f"from {len(base_names)} base names")

    # Probe each on S3, GCS, Azure
    findings: List[Finding] = []
    results:  List[Dict] = []

    # Cap to avoid excessive probing
    candidates = list(bucket_names)[:300]

    with concurrent.futures.ThreadPoolExecutor(max_workers=20) as ex:
        futures = {ex.submit(_probe_bucket, name): name for name in candidates}
        for fut in concurrent.futures.as_completed(futures):
            try:
                bucket_results = fut.result()
                for r in bucket_results:
                    if r["status"] in ("public-list", "exists-private", "public-read"):
                        results.append(r)
                        findings.append(_finding_from_result(r))
            except Exception:
                pass

    mod_report.findings.extend(findings)
    mod_report.summary = {
        "bases_generated"    : len(base_names),
        "candidates_probed"  : len(candidates),
        "buckets_found"      : len(results),
        "publicly_listable"  : len([r for r in results if r["status"] == "public-list"]),
        "providers_tested"   : ["AWS S3", "Google Cloud Storage", "Azure Blob"],
    }
    mod_report.data = {"buckets": results}

    log("OK", target, f"  Cloud assets complete: {len(results)} buckets found")


def _generate_base_names(target: str, report: ReconReport) -> Set[str]:
    """Build list of plausible bucket base names from the target + whois data."""
    bases = set()

    # apex without TLD
    parts = target.split(".")
    if len(parts) >= 2:
        brand = parts[-2].lower()
        bases.add(brand)
        # full apex
        bases.add(target.replace(".", "-").lower())
        bases.add(target.replace(".", "").lower())

    # From WHOIS registrant org
    if report.whois and report.whois.registrant_org:
        org = report.whois.registrant_org.lower()
        # Remove common suffixes
        org = re.sub(r'\b(inc|llc|ltd|limited|gmbh|ag|sa|srl|co|corp|corporation)\b',
                     '', org)
        org = re.sub(r'[^a-z0-9]+', '-', org).strip('-')
        if org and len(org) >= 3:
            bases.add(org)
            bases.add(org.replace("-", ""))

    # From ASN org
    if report.asn and report.asn.org:
        org = report.asn.org.lower()
        org = re.sub(r'[^a-z0-9]+', '-', org).strip('-')
        if org and len(org) >= 3:
            bases.add(org)

    # From discovered S3 buckets in JS intel
    if report.js_intel and report.js_intel.all_s3_buckets:
        for b in report.js_intel.all_s3_buckets[:20]:
            # Extract bucket name from hostname
            m = re.match(r'([a-z0-9-]+)\.s3', b, re.I)
            if m:
                bases.add(m.group(1).lower())

    return bases


def _is_valid_bucket_name(name: str) -> bool:
    """AWS S3 bucket naming rules (also reasonable for GCS/Azure)."""
    if len(name) < 3 or len(name) > 63:
        return False
    if not re.match(r'^[a-z0-9][a-z0-9.-]*[a-z0-9]$', name):
        return False
    if '..' in name or '.-' in name or '-.' in name:
        return False
    # Avoid IP-like names
    if re.match(r'^\d+\.\d+\.\d+\.\d+$', name):
        return False
    return True


def _probe_bucket(name: str) -> List[Dict]:
    """Probe a bucket name across AWS S3, GCS, Azure. Returns list of results."""
    results = []

    # ─── AWS S3 ─────────────────────────────────────────────
    # Virtual-hosted style
    for region_part in ["", ".us-east-1", ".eu-west-1", ".ap-southeast-1"]:
        url = f"https://{name}.s3{region_part}.amazonaws.com/"
        r = safe_get(url, timeout=6, allow_redirects=False)
        if r is None:
            continue
        status, detail = _classify_s3_response(r)
        if status != "not-found":
            results.append({
                "provider": "AWS S3",
                "bucket": name,
                "url": url,
                "status": status,
                "http_status": r.status_code,
                "detail": detail,
            })
            break

    # ─── Google Cloud Storage ───────────────────────────────
    gcs_url = f"https://storage.googleapis.com/{name}/"
    r = safe_get(gcs_url, timeout=6, allow_redirects=False)
    if r:
        status, detail = _classify_gcs_response(r)
        if status != "not-found":
            results.append({
                "provider": "Google Cloud Storage",
                "bucket": name,
                "url": gcs_url,
                "status": status,
                "http_status": r.status_code,
                "detail": detail,
            })

    # ─── Azure Blob ─────────────────────────────────────────
    az_url = f"https://{name}.blob.core.windows.net/"
    r = safe_get(az_url, timeout=6, allow_redirects=False)
    if r:
        status, detail = _classify_azure_response(r)
        if status != "not-found":
            results.append({
                "provider": "Azure Blob",
                "bucket": name,
                "url": az_url,
                "status": status,
                "http_status": r.status_code,
                "detail": detail,
            })

    return results


def _classify_s3_response(r) -> tuple:
    """Classify S3 response."""
    body = (r.text or "")[:1500]
    if r.status_code == 200 and "<ListBucketResult" in body:
        return "public-list", "Bucket listing publicly readable"
    if r.status_code == 403 and "AccessDenied" in body:
        return "exists-private", "Bucket exists but listing denied"
    if r.status_code == 404 and "NoSuchBucket" in body:
        return "not-found", "Bucket does not exist (may be claimable)"
    if r.status_code == 301 and "PermanentRedirect" in body:
        return "exists-private", "Bucket exists (redirected to correct region)"
    return "not-found", ""


def _classify_gcs_response(r) -> tuple:
    body = (r.text or "")[:1500]
    if r.status_code == 200 and ("<ListBucketResult" in body or "<?xml" in body):
        return "public-list", "GCS bucket listing publicly readable"
    if r.status_code in (401, 403) and "does not have" in body:
        return "exists-private", "Bucket exists but access denied"
    if r.status_code == 404 and ("NoSuchBucket" in body or "does not exist" in body):
        return "not-found", "Bucket does not exist"
    return "not-found", ""


def _classify_azure_response(r) -> tuple:
    body = (r.text or "")[:1500]
    if r.status_code == 200:
        return "public-list", "Azure Blob publicly listable"
    if r.status_code in (400, 403):
        return "exists-private", "Blob container exists, access denied"
    if r.status_code == 404 and "ResourceNotFound" in body:
        return "not-found", "Container does not exist"
    return "not-found", ""


def _finding_from_result(result: Dict) -> Finding:
    """Convert a cloud-asset result into a Finding."""
    sev_map = {
        "public-list":     "critical",
        "public-read":     "high",
        "exists-private":  "low",
    }
    severity = sev_map.get(result["status"], "info")
    status_desc = {
        "public-list": "Publicly listable (attackers can enumerate all contents)",
        "public-read": "Publicly readable",
        "exists-private": "Exists but access-denied (informational)",
    }.get(result["status"], result["status"])

    return Finding(
        severity    = severity,
        title       = (f"{result['provider']} bucket found: {result['bucket']} "
                       f"({result['status']})"),
        url         = result["url"],
        evidence    = (f"Bucket '{result['bucket']}' on {result['provider']}. "
                       f"HTTP {result['http_status']}. {status_desc}. "
                       f"{result.get('detail','')}"),
        module      = MODULE_NAME,
        remediation = ("For public-list: immediately disable public listing and audit "
                       "contents for sensitive data. For private buckets: ensure bucket "
                       "policies and ACLs are correctly scoped."),
        tags        = ["cloud", result["provider"].lower().replace(" ", "-"),
                       result["status"]],
    )
