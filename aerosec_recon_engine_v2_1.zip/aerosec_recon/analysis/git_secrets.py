"""
AeroSecLab Recon Engine — Analysis: Git Repository Exposure

Detects exposed .git/ directories on web servers and enumerates what's
accessible. Does NOT clone or extract the repository — just reports the
exposure surface so the asset owner can take action.

Files probed (all GET, no POST, no exfiltration):
  /.git/HEAD, /.git/config, /.git/index
  /.git/logs/HEAD, /.git/refs/heads/main (or master)
  /.git/COMMIT_EDITMSG, /.git/description
  /.gitignore, /.git/info/exclude

Severity ladder:
  HEAD only           → medium (likely full repo via git-dumper)
  HEAD + config       → high   (remotes leak credentials in URL)
  HEAD + index        → high   (file tree enumerable)
  All present         → critical
"""

from __future__ import annotations

import concurrent.futures
import re
from pathlib import Path
from typing import Dict, List

from ..core.models import ModuleReport, ReconReport, Finding, LiveHost
from ..core.config import REQUEST_TIMEOUT
from ..core.logger import log
from ..core.http_utils import safe_get


MODULE_NAME = "git_secrets"


GIT_PROBES = {
    "/.git/HEAD":              "Git repository HEAD",
    "/.git/config":            "Git config (may contain remote URLs with credentials)",
    "/.git/index":             "Git index (file tree)",
    "/.git/logs/HEAD":         "Commit history",
    "/.git/refs/heads/main":   "Main branch ref",
    "/.git/refs/heads/master": "Master branch ref",
    "/.git/COMMIT_EDITMSG":    "Last commit message",
    "/.git/description":       "Git repo description",
    "/.gitignore":             "Gitignore (low value)",
    "/.git/info/exclude":      "Git info/exclude",
    "/.git/info/refs":         "Git refs info",
    "/.git/objects/info/packs":"Git object pack list",
    # SVN
    "/.svn/entries":           "Subversion entries",
    "/.svn/wc.db":             "Subversion working copy DB",
    # Mercurial
    "/.hg/hgrc":               "Mercurial config",
    "/.hg/store/00manifest.i": "Mercurial manifest",
    # Bazaar
    "/.bzr/branch/branch.conf": "Bazaar branch config",
    # CVS
    "/CVS/Root":               "CVS root",
    "/CVS/Entries":            "CVS entries",
}

# Validate response is actually a git file (not 404 page returning 200)
GIT_HEAD_PATTERNS = re.compile(
    r'^ref:\s+refs/|^[a-f0-9]{40}$|^[a-f0-9]{64}$',
    re.M
)
GIT_CONFIG_MARKERS = ["[core]", "[remote ", "[branch "]
GIT_INDEX_MAGIC = b"DIRC"  # Git index magic bytes


def run(
    target     : str,
    report     : ReconReport,
    mod_report : ModuleReport,
    output_dir : Path,
):
    log("INFO", target, "Git Secrets — starting")

    if not report.live_hosts:
        mod_report.summary = {"skipped": "no live hosts"}
        return

    findings: List[Finding] = []
    exposures: List[Dict] = []

    with concurrent.futures.ThreadPoolExecutor(max_workers=12) as ex:
        futures = {ex.submit(_check_host, host): host for host in report.live_hosts}
        for fut in concurrent.futures.as_completed(futures):
            try:
                host_findings, host_exposure = fut.result()
                findings.extend(host_findings)
                if host_exposure:
                    exposures.append(host_exposure)
            except Exception:
                pass

    mod_report.findings.extend(findings)
    mod_report.summary = {
        "hosts_probed"     : len(report.live_hosts),
        "exposed_hosts"    : len(exposures),
        "findings"         : len(findings),
        "critical_count"   : len([f for f in findings if f.severity == "critical"]),
        "high_count"       : len([f for f in findings if f.severity == "high"]),
    }
    mod_report.data = {"exposures": exposures}
    log("OK", target, f"  Git secrets complete: {len(exposures)} exposed hosts, "
        f"{len(findings)} findings")


def _check_host(host: LiveHost) -> tuple:
    """Probe a single host for git/svn/hg exposure."""
    findings: List[Finding] = []
    exposure: Dict = {"fqdn": host.fqdn, "url": host.url, "files_found": []}
    confirmed_git = False

    for path, description in GIT_PROBES.items():
        url = host.url.rstrip("/") + path
        r   = safe_get(url, timeout=6)
        if r is None or r.status_code != 200:
            continue
        body = r.text or ""

        # Validate by content (avoid 200-but-actually-404 pages)
        valid = False
        evidence_extra = ""

        if path == "/.git/HEAD" and GIT_HEAD_PATTERNS.search(body[:200]):
            valid = True
            evidence_extra = f"Body: {body[:80].strip()}"
        elif path == "/.git/config" and any(m in body[:500] for m in GIT_CONFIG_MARKERS):
            valid = True
            # Look for credentials in remote URL
            cred_m = re.search(r'url\s*=\s*https?://([^:\s]+:[^@\s]+)@', body)
            if cred_m:
                evidence_extra = f"!!! CREDENTIALS in remote URL !!! Body excerpt: {body[:300]}"
            else:
                evidence_extra = f"Config: {body[:300]}"
        elif path == "/.git/index":
            # Index file is binary; check magic bytes
            try:
                if r.content.startswith(GIT_INDEX_MAGIC):
                    valid = True
                    evidence_extra = "Binary index file (DIRC magic confirmed)"
            except Exception:
                pass
        elif path.startswith("/.git/refs/heads/"):
            if re.match(r'^[a-f0-9]{40}\s*$', body[:50]) or re.match(r'^[a-f0-9]{64}\s*$', body[:80]):
                valid = True
                evidence_extra = f"SHA: {body[:60].strip()}"
        elif path == "/.git/logs/HEAD":
            if re.search(r'^[a-f0-9]{40}\s+[a-f0-9]{40}', body):
                valid = True
                evidence_extra = f"Log entries (truncated): {body[:200]}"
        elif path == "/.svn/entries":
            if "12" in body[:10] or "<wc-entries" in body:
                valid = True
                evidence_extra = f"SVN entries: {body[:100]}"
        elif path == "/.hg/hgrc" and "[" in body[:200]:
            valid = True
            evidence_extra = f"hg config: {body[:200]}"
        elif path == "/.gitignore":
            valid = True  # not security-critical but useful
            evidence_extra = f"gitignore: {body[:200]}"
        elif path == "/.git/COMMIT_EDITMSG" or path == "/.git/description":
            valid = bool(body.strip())
            evidence_extra = f"Content: {body[:200]}"
        else:
            # Generic: must be small and not look like an HTML 404 page
            if len(body) < 5000 and "<html" not in body.lower()[:200]:
                valid = True
                evidence_extra = f"Body: {body[:150]}"

        if not valid:
            continue

        confirmed_git = confirmed_git or "/.git/" in path
        exposure["files_found"].append({"path": path, "evidence": evidence_extra[:300]})

        # Per-file finding
        # Severity assignment
        if path == "/.git/config" and "CREDENTIALS" in evidence_extra:
            sev = "critical"
        elif path == "/.git/config":
            sev = "high"
        elif path == "/.git/HEAD":
            sev = "high"
        elif path == "/.git/index":
            sev = "high"
        elif path == "/.git/logs/HEAD":
            sev = "medium"
        elif path == "/.svn/wc.db":
            sev = "high"
        elif path == "/.hg/hgrc":
            sev = "medium"
        elif path == "/.gitignore":
            sev = "low"
        else:
            sev = "medium"

        findings.append(Finding(
            severity    = sev,
            title       = f"VCS file exposed: {path} on {host.fqdn}",
            url         = url,
            evidence    = f"{description}. {evidence_extra}",
            module      = MODULE_NAME,
            remediation = ("Block all dotfile/dotdir requests at the web server "
                           "(deny ^/\\.). Remove .git from production deployments."),
            tags        = ["git-exposure", "info-disclosure"] +
                          (["credentials"] if "CREDENTIALS" in evidence_extra else []),
        ))

    # Summary finding for the host if multiple files exposed
    if len(exposure["files_found"]) >= 3 and confirmed_git:
        findings.append(Finding(
            severity    = "critical",
            title       = f"Full Git repository likely downloadable: {host.fqdn}",
            url         = host.url,
            evidence    = (f"Multiple .git files exposed ({len(exposure['files_found'])}). "
                           f"An attacker can reconstruct the full repo with `git-dumper`."),
            module      = MODULE_NAME,
            remediation = ("Immediately remove .git from web root. Audit commit history "
                           "for leaked credentials. Rotate any keys ever committed."),
            tags        = ["git-exposure", "full-repo", "critical"],
        ))

    return findings, exposure if exposure["files_found"] else None
