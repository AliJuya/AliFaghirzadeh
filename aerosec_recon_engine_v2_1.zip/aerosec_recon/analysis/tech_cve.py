"""
AeroSecLab Recon Engine — Analysis: Tech / CVE Correlation

Two jobs:
  1. Build a complete inventory of (host, technology, version) tuples and
     correlate each entry with any nuclei findings for that host. This makes
     the report show "nginx 1.18.0 — 3 nuclei findings" inline instead of
     forcing reviewers to cross-reference modules manually.

  2. Apply a curated table of high-confidence version→CVE mappings to flag
     known-vulnerable software detected by web_probe / httpx. Only emits
     findings for *exact* version matches or *clearly-EOL* version branches —
     avoids false positives.

Detection-only — purely consumes data already collected by other modules.
"""

from __future__ import annotations

import re
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from ..core.logger import log
from ..core.models import ModuleReport, ReconReport, Finding


MODULE_NAME = "tech_cve"


# Exact (tech_name_lowercase, version) → (severity, finding_title, cve_id, remediation)
# Curated to high-confidence — version must match exactly.
EXACT_VERSION_RISKS: Dict[Tuple[str, str], Tuple[str, str, str, str]] = {
    # Apache httpd
    ("apache",       "2.4.49"): ("critical", "Apache httpd 2.4.49 — path traversal & RCE",
                                  "CVE-2021-41773",
                                  "Upgrade Apache httpd to 2.4.51 or later."),
    ("apache",       "2.4.50"): ("critical", "Apache httpd 2.4.50 — path traversal & RCE",
                                  "CVE-2021-42013",
                                  "Upgrade Apache httpd to 2.4.51 or later."),
    # nginx (very old)
    ("nginx",        "1.3.13"): ("medium",   "Very old nginx version detected",
                                  "",
                                  "Upgrade nginx to a current stable release."),
    ("nginx",        "1.20.0"): ("medium",   "nginx 1.20.0 — DNS resolver vuln",
                                  "CVE-2021-23017",
                                  "Upgrade to nginx 1.20.1 or later."),
    # Spring4Shell era
    ("spring",       "5.3.17"): ("critical", "Spring 5.3.17 — Spring4Shell candidate",
                                  "CVE-2022-22965",
                                  "Upgrade Spring Framework to 5.3.18+ / 5.2.20+."),
    # Log4Shell-era artifacts (best detected via Server header rarely; included as a hint)
    ("log4j",        "2.14.1"): ("critical", "Log4j 2.14.1 — Log4Shell vulnerable",
                                  "CVE-2021-44228",
                                  "Upgrade Log4j to 2.17.1 or later."),
    # Confluence
    ("confluence",   "7.13.0"): ("critical", "Confluence 7.13.0 — OGNL injection RCE",
                                  "CVE-2021-26084",
                                  "Upgrade Atlassian Confluence to 7.13.7 or later."),
    # GitLab (older versions)
    ("gitlab",       "11.9.0"): ("high",     "Old GitLab version detected",
                                  "",
                                  "Upgrade GitLab to a current supported release."),
    ("gitlab",       "13.10.3"): ("critical","GitLab 13.10.3 — ExifTool RCE",
                                  "CVE-2021-22205",
                                  "Upgrade GitLab to 13.10.4 / 13.9.6 / 13.8.8 or later."),
    # Drupal
    ("drupal",       "7.58"):    ("critical","Drupal 7.58 — Drupalgeddon2 RCE",
                                  "CVE-2018-7600",
                                  "Upgrade Drupal core to 7.59 / 8.5.1 or later."),
    # Jenkins (very old)
    ("jenkins",      "2.137"):   ("high",    "Jenkins 2.137 — multiple CVEs",
                                  "",
                                  "Upgrade Jenkins to current LTS."),
    # WordPress (placeholder for known-vulnerable releases)
    ("wordpress",    "5.0.0"):   ("high",    "WordPress 5.0.0 — multiple CVEs",
                                  "",
                                  "Upgrade WordPress to current release."),
    # Strapi v3.x is EOL
    ("strapi cms",   "3.6.10"):  ("medium",  "Strapi v3.x is end-of-life",
                                  "",
                                  "Migrate to Strapi v4 (EOL since 2023)."),
}


# (tech_name_lowercase, branch_predicate) → finding
# Used when exact-version match misses but the branch is clearly EOL/old
def _old_branch_check(name_key: str, version: str) -> Optional[Tuple[str, str, str, str]]:
    if not version:
        return None
    m = re.match(r"(\d+)\.(\d+)", version)
    if not m:
        return None
    major, minor = int(m.group(1)), int(m.group(2))

    if name_key == "nginx" and major == 1 and minor <= 14:
        return ("medium", f"Very old nginx branch: {version}", "",
                "Upgrade to nginx 1.24+ for current security patches.")

    if name_key == "apache" and major == 2 and minor == 2:
        return ("high", f"End-of-life Apache httpd 2.2.x branch: {version}", "",
                "Apache 2.2.x reached EOL July 2017. Upgrade to 2.4.x.")

    if name_key in {"jenkins", "grafana", "gitlab"} and major < 9:
        return ("medium", f"Outdated {name_key.title()} version: {version}", "",
                f"Upgrade {name_key.title()} to a currently-supported release.")

    if name_key == "wordpress" and major == 4:
        return ("high", f"End-of-life WordPress 4.x branch: {version}", "",
                "WordPress 4.x reached EOL December 2022. Upgrade to 6.x.")

    if name_key == "drupal" and major == 7:
        return ("high", f"End-of-life Drupal 7 detected: {version}", "",
                "Drupal 7 reached EOL January 2025. Migrate to Drupal 10.")

    if name_key == "php" and version.startswith(("5.", "7.0", "7.1", "7.2", "7.3")):
        return ("high", f"End-of-life PHP version: {version}", "",
                "Upgrade to PHP 8.2 or later.")

    if name_key == "node.js" and major <= 14:
        return ("medium", f"End-of-life Node.js branch: {version}", "",
                "Upgrade to a Node.js LTS release (18+ or 20+).")

    return None


def run(
    target     : str,
    report     : ReconReport,
    mod_report : ModuleReport,
    output_dir : Path,
):
    log("INFO", target, "Tech / CVE Correlation — starting")

    findings: List[Finding] = []

    # Build inventory: every (host, tech, version) tuple
    inventory: List[Dict] = []

    # Pull nuclei findings indexed by URL for cross-correlation
    nuclei_mod = getattr(report, 'module_nuclei_scan', None)
    nuclei_by_url: Dict[str, List[Dict]] = {}
    if nuclei_mod and nuclei_mod.findings:
        for f in nuclei_mod.findings:
            url = f.url or ""
            # Index by host (origin) so all paths under the host get correlated
            try:
                from urllib.parse import urlparse
                parsed = urlparse(url)
                origin = f"{parsed.scheme}://{parsed.netloc}"
            except Exception:
                origin = url
            nuclei_by_url.setdefault(origin, []).append({
                "title": f.title,
                "severity": f.severity,
                "url": f.url,
                "cve": f.cve,
                "tags": f.tags,
            })

    # Iterate over live hosts and their detected tech
    for host in report.live_hosts:
        host_url = host.url
        host_origin = host_url  # already an origin in our model
        host_nuclei = nuclei_by_url.get(host_origin, [])

        for tech in host.tech:
            name_key = (tech.name or "").lower().strip()
            ver = (tech.version or "").strip()
            entry = {
                "host":     host.fqdn,
                "url":      host_url,
                "tech":     tech.name,
                "version":  ver,
                "category": tech.category or "",
                "supporting_nuclei_count": len(host_nuclei),
                "supporting_nuclei_sample": host_nuclei[:3],
            }
            inventory.append(entry)

            # Exact match check
            key = (name_key, ver)
            if key in EXACT_VERSION_RISKS:
                sev, title, cve, remediation = EXACT_VERSION_RISKS[key]
                findings.append(Finding(
                    severity    = sev,
                    title       = title,
                    url         = host_url,
                    evidence    = (f"Detected: {tech.name} {ver} on {host.fqdn}. "
                                   f"Nuclei findings on this host: {len(host_nuclei)}."),
                    module      = MODULE_NAME,
                    cve         = cve,
                    remediation = remediation,
                    tags        = [name_key, "version-risk", "exact-match"] +
                                  (["cve"] if cve else []),
                ))
                continue

            # EOL branch heuristic
            branch_check = _old_branch_check(name_key, ver)
            if branch_check:
                sev, title, cve, remediation = branch_check
                findings.append(Finding(
                    severity    = sev,
                    title       = title,
                    url         = host_url,
                    evidence    = (f"Detected: {tech.name} {ver} on {host.fqdn}. "
                                   f"Nuclei findings on this host: {len(host_nuclei)}."),
                    module      = MODULE_NAME,
                    cve         = cve,
                    remediation = remediation,
                    tags        = [name_key, "version-risk", "eol-branch"],
                ))

        # Also surface ports that cms_probes / service_exposure didn't catch
        # but are well-known high-value services
        for port in host.ports:
            svc = (port.service or "").lower()
            if svc in {"jenkins", "docker", "redis", "mongodb",
                       "elasticsearch", "rabbitmq", "memcached"}:
                # Only emit a finding if no other module already flagged it
                # (keep severity low to avoid double-counting)
                findings.append(Finding(
                    severity    = "info",
                    title       = f"High-value service detected: {svc} on port {port.port}",
                    url         = host_url,
                    evidence    = (f"Service fingerprint: {port.service} "
                                   f"{port.version or ''} on {host.fqdn}:{port.port}").strip(),
                    module      = MODULE_NAME,
                    remediation = "Verify the service is intentionally exposed and authenticated.",
                    tags        = ["service-fingerprint", svc],
                ))

    mod_report.findings.extend(findings)
    mod_report.summary = {
        "inventory_items": len(inventory),
        "exact_matches"  : sum(1 for f in findings if "exact-match" in f.tags),
        "eol_branches"   : sum(1 for f in findings if "eol-branch" in f.tags),
        "service_hints"  : sum(1 for f in findings if "service-fingerprint" in f.tags),
        "findings"       : len(findings),
        "nuclei_correlated_hosts": len(nuclei_by_url),
    }
    mod_report.data = {
        "inventory": inventory[:200],
        "nuclei_by_origin_count": {k: len(v) for k, v in nuclei_by_url.items()},
    }

    log("OK", target,
        f"  Tech / CVE correlation complete: {len(inventory)} inventory items, "
        f"{len(findings)} findings, {len(nuclei_by_url)} hosts cross-correlated with nuclei")
