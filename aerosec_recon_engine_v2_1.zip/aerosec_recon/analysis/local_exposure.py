"""
AeroSecLab Recon Engine — Analysis: Local Exposure Sweep

Sweeps the full SENSITIVE_PATHS list against every live host to find:
  - exposed dotfiles (.env, .DS_Store, .htaccess)
  - backup artifacts (*.bak, *.sql, *.zip, *.tar.gz)
  - server-status / phpinfo / debug endpoints
  - default admin paths (/admin, /panel, /console)
  - WebDAV / TRACE / OPTIONS leaks
  - JSON responses that contain secret-ish keywords (password, token, apikey)

Complements the more targeted modules (`git_secrets`, `cms_probes`,
`swagger_intel`, `graphql_intel`) by catching the long tail of misconfigurations.

Detection-only: GET requests + safe OPTIONS/TRACE method probes. Never POST,
never authenticate, never modify.
"""

from __future__ import annotations

import concurrent.futures
import json
from pathlib import Path
from typing import Dict, List, Set, Tuple
from urllib.parse import urljoin

from ..core.config import SENSITIVE_PATHS
from ..core.http_utils import safe_get, safe_request
from ..core.logger import log
from ..core.models import ModuleReport, ReconReport, Finding, LiveHost


MODULE_NAME = "local_exposure"


# Path-substring → (severity, finding-title, remediation) classification.
# Order matters: more specific patterns first so /admin/init resolves to Strapi
# rather than the generic /admin entry.
HIGH_RISK_PATTERNS: List[Tuple[str, str, str, str]] = [
    # most-specific first
    ("/.git/",          "critical", "Git metadata exposed",
        "Block dotdir requests at the web server. Rotate any credentials ever committed."),
    ("/.svn/",          "critical", "Subversion metadata exposed",
        "Block dotdir requests; remove .svn from production deployments."),
    ("/.hg/",           "critical", "Mercurial metadata exposed",
        "Block dotdir requests; remove .hg from production deployments."),
    ("/dump.sql",       "critical", "Database dump exposed",
        "Delete the dump immediately and rotate any database credentials it contained."),
    ("/database.sql",   "critical", "Database dump exposed",
        "Delete the dump immediately and rotate any database credentials it contained."),
    ("/db.sql",         "critical", "Database dump exposed",
        "Delete the dump immediately and rotate any database credentials it contained."),
    ("/.env",           "high",     "Environment file exposed",
        "Remove the .env from web root. Rotate every secret it contained."),
    ("/wp-config",      "critical", "WordPress configuration backup exposed",
        "Remove the file. Rotate DB credentials and WordPress salts."),
    ("/backup",         "high",     "Backup artifact exposed",
        "Remove backup files from the web-accessible directory."),
    ("/actuator/heapdump", "critical", "Spring heapdump downloadable",
        "Disable the heapdump endpoint in production."),
    ("/actuator/env",   "high",     "Spring Actuator env endpoint exposed",
        "Disable management endpoints or restrict to admin via Spring Security."),
    ("/actuator/mappings", "high",  "Spring Actuator mappings exposed",
        "Disable the mappings endpoint in production."),
    ("/actuator",       "medium",   "Spring Actuator base reachable",
        "Restrict the actuator base path to authenticated administrators."),
    ("/server-status",  "medium",   "Apache server-status exposed",
        "Restrict /server-status to localhost or remove ExtendedStatus."),
    ("/phpinfo",        "medium",   "phpinfo() page exposed",
        "Remove phpinfo from any reachable directory."),
    ("/info.php",       "medium",   "phpinfo() page exposed",
        "Remove the file from web root."),
    ("/swagger",        "medium",   "Swagger/OpenAPI surface reachable",
        "Restrict API documentation to authenticated users in production."),
    ("/openapi",        "medium",   "OpenAPI spec reachable",
        "Restrict API documentation to authenticated users in production."),
    ("/graphql",        "medium",   "GraphQL endpoint reachable",
        "Confirm introspection is disabled and authorization is enforced on every operation."),
    ("/console",        "high",     "Application console reachable",
        "Restrict console / shell-like endpoints to admin-only access."),
    ("/h2-console",     "high",     "H2 database console reachable",
        "Disable the H2 console in production."),
    ("/phpmyadmin",     "high",     "phpMyAdmin reachable",
        "Restrict phpMyAdmin to internal IPs / VPN."),
    ("/adminer",        "high",     "Adminer reachable",
        "Restrict Adminer to internal IPs / VPN, or remove from web root."),
    ("/debug",          "medium",   "Debug surface reachable",
        "Disable debug endpoints in production."),
    ("/admin",          "low",      "Admin surface reachable",
        "Confirm the admin surface is intended and properly access-controlled."),
    ("/.well-known/",   "info",     "Well-known path served",
        "Standard /.well-known/ path — verify the contents are intended."),
]

# File extensions that indicate a backup/source/key artifact at the path itself
SENSITIVE_EXTENSIONS = (
    ".bak", ".old", ".swp", ".save", ".orig", ".copy", ".tmp",
    ".sql", ".dump", ".tar.gz", ".tgz", ".zip", ".7z", ".rar",
    ".pem", ".key", ".crt", ".p12", ".pfx",
    ".log",
)

# Keywords that, if found in a JSON response, indicate likely secret leak
JSON_SECRET_KEYWORDS = (
    "password", "passwd", "secret", "token", "apikey", "api_key",
    "private_key", "client_secret", "access_key", "auth_token",
    "db_password", "smtp_password", "aws_secret",
)


def run(
    target     : str,
    report     : ReconReport,
    mod_report : ModuleReport,
    output_dir : Path,
):
    log("INFO", target, "Local Exposure Sweep — starting")

    if not report.live_hosts:
        log("WARN", target, "  No live hosts to sweep")
        mod_report.summary = {"skipped": "no live hosts"}
        return

    raw_dir = output_dir / MODULE_NAME
    raw_dir.mkdir(exist_ok=True)

    # Build base list (deduplicated)
    bases = sorted({h.url.rstrip("/") for h in report.live_hosts if h.url})

    # Limit paths swept per base to keep runs practical at scale.
    # SENSITIVE_PATHS is ~120 entries; that's 120 × N_hosts requests.
    # Cap to first 120 (the curated/high-signal ones).
    priority_paths = list(dict.fromkeys(SENSITIVE_PATHS))[:120]

    log("INFO", target,
        f"  Sweeping {len(priority_paths)} paths × {len(bases)} bases "
        f"(~{len(priority_paths)*len(bases)} probes)")

    findings: List[Finding] = []
    interesting: List[Dict] = []
    seen: Set[Tuple[str, str]] = set()

    # Per-host probe in parallel; each host probes its paths sequentially
    # to keep the request rate reasonable per origin.
    with concurrent.futures.ThreadPoolExecutor(max_workers=10) as ex:
        futures = {
            ex.submit(_sweep_host, base, priority_paths): base
            for base in bases
        }
        for fut in concurrent.futures.as_completed(futures):
            try:
                host_findings, host_interesting = fut.result()
                # Dedupe across hosts on (path, status, content-type)
                for entry in host_interesting:
                    key = (entry["path"], entry["status"])
                    if key not in seen:
                        seen.add(key)
                        interesting.append(entry)
                findings.extend(host_findings)
            except Exception as e:
                log("ERR", target, f"  sweep failed: {e}")

    # Save raw artifact
    (raw_dir / "interesting_paths.json").write_text(
        json.dumps(interesting, indent=2)
    )

    mod_report.findings.extend(findings)
    mod_report.summary = {
        "bases_swept"      : len(bases),
        "paths_per_base"   : len(priority_paths),
        "interesting_paths": len(interesting),
        "findings"         : len(findings),
        "critical"         : sum(1 for f in findings if f.severity == "critical"),
        "high"             : sum(1 for f in findings if f.severity == "high"),
    }
    mod_report.data = {
        "interesting_paths_count": len(interesting),
        "interesting_paths_sample": interesting[:50],
    }

    log("OK", target,
        f"  Local Exposure complete: {len(interesting)} hits, "
        f"{len(findings)} findings")


def _sweep_host(base: str, paths: List[str]) -> Tuple[List[Finding], List[Dict]]:
    """Sweep one base host across the given path list."""
    findings: List[Finding] = []
    interesting: List[Dict] = []

    # Method probes once per host (TRACE is a high-signal misconfig)
    r_trace, _ = safe_request("TRACE", base, timeout=4)
    if r_trace and r_trace.status_code not in (400, 403, 405, 501):
        findings.append(Finding(
            severity    = "medium",
            title       = "HTTP TRACE method enabled",
            url         = base,
            evidence    = f"TRACE returned status {r_trace.status_code}",
            module      = MODULE_NAME,
            remediation = "Disable TRACE at the web server / WAF.",
            tags        = ["http-method", "trace"],
        ))

    # OPTIONS to capture Allow header (often reveals WebDAV verbs)
    r_opts, _ = safe_request("OPTIONS", base, timeout=4)
    if r_opts:
        allow = r_opts.headers.get("Allow", "") or r_opts.headers.get("allow", "")
        if allow:
            unusual_verbs = {"PROPFIND", "PROPPATCH", "MKCOL", "COPY", "MOVE",
                             "LOCK", "UNLOCK", "REPORT", "VERSION-CONTROL"}
            present = [v for v in unusual_verbs if v in allow.upper()]
            if present:
                findings.append(Finding(
                    severity    = "medium",
                    title       = f"WebDAV-style HTTP methods enabled: {', '.join(present)}",
                    url         = base,
                    evidence    = f"Allow header: {allow[:200]}",
                    module      = MODULE_NAME,
                    remediation = "Disable WebDAV unless explicitly required.",
                    tags        = ["http-method", "webdav"],
                ))

    # Path sweep
    for path in paths:
        url = urljoin(base + "/", path.lstrip("/"))
        r = safe_get(url, allow_redirects=False, timeout=5)
        if not r or r.status_code >= 400:
            continue

        body = (r.text or "")[:1500]
        ct   = (r.headers.get("content-type") or "").lower()
        size = len(r.content) if r.content else 0

        # Skip catch-all SPAs that return 200 + HTML for every path
        if r.status_code == 200 and "text/html" in ct and len(body) > 200:
            # Check if it looks like the same generic SPA index
            if any(marker in body[:500].lower() for marker in
                   ["<!doctype html", "<html"]) and path not in ("/", "/index.html"):
                # Only flag HTML responses that contain the path's specific marker
                # OR look unusually short (real content vs SPA shell)
                path_keyword = path.strip("/").split("/")[0].lower()
                if path_keyword and path_keyword not in body.lower():
                    # Likely SPA fallback — skip
                    continue

        interesting.append({
            "url": url,
            "path": path,
            "status": r.status_code,
            "content_type": ct,
            "size_bytes": size,
        })

        # Classify
        sev, title, remediation = _classify(path, body, ct)

        # Deeper checks for JSON responses with secret-keywords
        if "application/json" in ct and any(kw in body.lower() for kw in JSON_SECRET_KEYWORDS):
            sev = "high"
            title = "JSON response contains potential secret keys"
            remediation = ("Audit the response — sensitive keys should never appear "
                           "in publicly-reachable JSON. Restrict access or scrub the response.")

        findings.append(Finding(
            severity    = sev,
            title       = f"{title}: {path}",
            url         = url,
            evidence    = (f"status={r.status_code} ct={ct[:50]} size={size}b "
                           f"body_excerpt={body[:200]!r}")[:400],
            module      = MODULE_NAME,
            remediation = remediation,
            tags        = ["exposure", path.strip("/").split("/")[0] or "root"],
        ))

    return findings, interesting


def _classify(path: str, body: str, content_type: str) -> Tuple[str, str, str]:
    """Match path → (severity, title, remediation). Most-specific first."""
    pl = path.lower()
    for marker, sev, title, remediation in HIGH_RISK_PATTERNS:
        if marker in pl:
            return sev, title, remediation

    # Sensitive file extensions
    if any(pl.endswith(ext) for ext in SENSITIVE_EXTENSIONS):
        return ("high", "Sensitive artifact accessible",
                "Remove the file from web root. Rotate any secrets it may have contained.")

    # Otherwise it's just an interesting path
    return ("low", "Reachable interesting path",
            "Verify whether this path should be publicly reachable.")
