"""
AeroSecLab Recon Engine — Analysis: Parameter Extractor
Tools: arjun, paramspider
Discovers hidden/undocumented parameters on discovered endpoints.
"""

from __future__ import annotations

import json
import re
import tempfile
from pathlib import Path
from typing import List, Set
from urllib.parse import urlparse, parse_qs

from ..core.models import (
    ModuleReport, ReconReport, Parameter, Finding
)
from ..core.config import get_tool, TOOL_TIMEOUT
from ..core.logger import log
from ..core.http_utils import run_tool


MODULE_NAME = "param_extractor"

# High-value parameter names to flag
INTERESTING_PARAMS = {
    # IDOR / Access Control
    "id", "user_id", "uid", "account_id", "order_id",
    "transaction_id", "invoice_id", "wallet_id", "fund_id",
    # File Inclusion
    "file", "filename", "path", "dir", "folder", "include",
    "template", "page", "view", "load", "read",
    # Redirect
    "redirect", "url", "return_url", "next", "goto",
    "redirect_uri", "callback", "target", "dest",
    # SSRF
    "webhook", "hook", "callback_url", "endpoint", "proxy",
    "remote", "fetch", "request", "host",
    # Injection
    "query", "search", "filter", "sort", "order", "format",
    "type", "action", "cmd", "command", "exec",
    # Auth
    "token", "api_key", "key", "secret", "password",
    "auth", "session", "csrf", "nonce",
    # Debug
    "debug", "test", "dev", "verbose", "trace",
}


def run(
    target     : str,
    report     : ReconReport,
    mod_report : ModuleReport,
    output_dir : Path,
):
    log("INFO", target, "Parameter Extractor — starting")

    param_dir = output_dir / "params"
    param_dir.mkdir(exist_ok=True)

    # Collect interesting endpoints to test
    test_urls = _collect_test_urls(report, target)
    log("INFO", target, f"  Testing {len(test_urls)} endpoints for hidden params")

    all_params: List[Parameter] = []

    # ── arjun — HTTP parameter discovery ─────────────────────────────
    if get_tool("arjun"):
        arjun_params = _run_arjun(test_urls[:20], target, param_dir)
        all_params.extend(arjun_params)
        log("OK", target, f"  arjun → {len(arjun_params)} parameters")

    # ── paramspider — historical parameter mining ─────────────────────
    if get_tool("paramspider"):
        spider_params = _run_paramspider(target, param_dir)
        all_params.extend(spider_params)
        log("OK", target, f"  paramspider → {len(spider_params)} parameters")

    # ── Extract params from crawled URLs ─────────────────────────────
    crawl_params = _extract_from_crawled_urls(report.crawled_links, target)
    all_params.extend(crawl_params)
    log("OK", target, f"  crawled URLs → {len(crawl_params)} parameters")

    # ── Extract params from JS intel ─────────────────────────────────
    if report.js_intel:
        js_params = _extract_from_js_paths(
            report.js_intel.all_api_paths + report.js_intel.all_transfer_paths,
            target
        )
        all_params.extend(js_params)

    # ── Deduplicate ────────────────────────────────────────────────────
    seen = set()
    unique_params = []
    for p in all_params:
        key = f"{p.url}|{p.name}|{p.method}"
        if key not in seen:
            seen.add(key)
            unique_params.append(p)

    report.parameters = unique_params

    # ── Generate findings ─────────────────────────────────────────────
    findings = _generate_findings(unique_params, target)
    mod_report.findings.extend(findings)

    # ── Save ──────────────────────────────────────────────────────────
    _save_params(unique_params, param_dir)

    mod_report.summary = {
        "total_parameters" : len(unique_params),
        "endpoints_tested" : len(test_urls),
        "interesting_params": sum(1 for p in unique_params
                                 if p.name.lower() in INTERESTING_PARAMS),
        "findings"         : len(findings),
    }
    mod_report.data = {
        "parameters": [
            {"url": p.url, "name": p.name, "method": p.method,
             "type": p.type}
            for p in unique_params[:200]
        ]
    }
    log("OK", target, f"  Param extraction complete: {len(unique_params)} params")


# ─────────────────────────────────────────────
# URL COLLECTION
# ─────────────────────────────────────────────

def _collect_test_urls(report: ReconReport, target: str) -> List[str]:
    """Collect URLs worth testing for hidden parameters."""
    urls: Set[str] = set()

    # Live host root URLs
    for host in report.live_hosts:
        urls.add(host.url)
        urls.add(f"{host.url}/api")
        urls.add(f"{host.url}/api/v1")
        urls.add(f"{host.url}/api/v2")

    # Crawled URLs — focus on API-looking paths
    for link in report.crawled_links:
        parsed = urlparse(link.url)
        path   = parsed.path.lower()
        if any(kw in path for kw in [
            "/api/", "/v1/", "/v2/", "/v3/",
            "/user", "/account", "/wallet", "/order",
            "/search", "/filter", "/list",
        ]):
            # Clean URL (no existing params — arjun adds its own)
            clean = f"{parsed.scheme}://{parsed.netloc}{parsed.path}"
            urls.add(clean)

    # JS-discovered API paths
    if report.js_intel:
        for host in report.live_hosts[:3]:
            for path in report.js_intel.all_api_paths[:30]:
                urls.add(f"{host.url.rstrip('/')}{path}")

    return list(urls)


# ─────────────────────────────────────────────
# ARJUN
# ─────────────────────────────────────────────

def _run_arjun(
    urls      : List[str],
    target    : str,
    out_dir   : Path,
) -> List[Parameter]:
    params   = []
    arjun    = get_tool("arjun")
    out_file = str(out_dir / "arjun.json")

    with tempfile.NamedTemporaryFile(mode="w", suffix=".txt", delete=False) as f:
        f.write("\n".join(urls))
        url_file = f.name

    stdout, _, _ = run_tool(
        [
            arjun,
            "-i", url_file,
            "-oJ", out_file,
            "-t", "10",           # threads
            "--stable",           # stable mode (no false positives)
            "-q",                 # quiet
        ],
        timeout=TOOL_TIMEOUT,
        target=target,
    )

    out_path = Path(out_file)
    if out_path.exists():
        try:
            data = json.loads(out_path.read_text())
            for url, result in data.items():
                for method, param_list in result.items():
                    if isinstance(param_list, list):
                        for param_name in param_list:
                            params.append(Parameter(
                                name   = param_name,
                                url    = url,
                                method = method.upper(),
                                type   = "query" if method.upper() == "GET" else "body",
                            ))
        except Exception:
            pass

    import os
    try:
        os.unlink(url_file)
    except Exception:
        pass

    return params


# ─────────────────────────────────────────────
# PARAMSPIDER
# ─────────────────────────────────────────────

def _run_paramspider(target: str, out_dir: Path) -> List[Parameter]:
    params      = []
    paramspider = get_tool("paramspider")

    stdout, _, _ = run_tool(
        [
            paramspider,
            "-d", target,
            "--subs",
            "-l", "high",
            "-o", str(out_dir / "paramspider"),
        ],
        timeout=TOOL_TIMEOUT,
        target=target,
    )

    # paramspider outputs files per domain
    for file in out_dir.glob("**/*.txt"):
        if "paramspider" in str(file):
            for line in file.read_text().splitlines():
                line = line.strip()
                if not line or "FUZZ" not in line:
                    continue
                parsed = urlparse(line)
                if not parsed.query:
                    continue
                for param_name in parse_qs(parsed.query).keys():
                    if param_name != "FUZZ":
                        clean_url = f"{parsed.scheme}://{parsed.netloc}{parsed.path}"
                        params.append(Parameter(
                            name   = param_name,
                            url    = clean_url,
                            method = "GET",
                            type   = "query",
                        ))

    return params


# ─────────────────────────────────────────────
# EXTRACT FROM CRAWLED URLS
# ─────────────────────────────────────────────

def _extract_from_crawled_urls(crawled, target: str) -> List[Parameter]:
    params = []
    seen   : Set[str] = set()

    for link in crawled:
        parsed = urlparse(link.url)
        if not parsed.query:
            continue
        base_url = f"{parsed.scheme}://{parsed.netloc}{parsed.path}"
        for param_name, values in parse_qs(parsed.query).items():
            key = f"{base_url}|{param_name}"
            if key not in seen:
                seen.add(key)
                params.append(Parameter(
                    name    = param_name,
                    url     = base_url,
                    method  = "GET",
                    type    = "query",
                    example = values[0] if values else "",
                ))

    return params


# ─────────────────────────────────────────────
# EXTRACT FROM JS PATHS
# ─────────────────────────────────────────────

def _extract_from_js_paths(paths: List[str], target: str) -> List[Parameter]:
    """Look for path parameter patterns in JS API paths."""
    params = []
    # Patterns like /api/v2/user/{id} or /api/v2/user/:id
    id_re = re.compile(r'[/{:]([a-zA-Z][a-zA-Z0-9_]*(?:_id|Id|ID))(?:[/}]|$)')
    for path in paths:
        for match in id_re.findall(path):
            params.append(Parameter(
                name   = match,
                url    = path,
                method = "GET",
                type   = "path",
            ))
    return params


# ─────────────────────────────────────────────
# FINDINGS
# ─────────────────────────────────────────────

def _generate_findings(params: List[Parameter], target: str) -> List[Finding]:
    findings  = []
    seen_keys : Set[str] = set()

    interesting = [p for p in params if p.name.lower() in INTERESTING_PARAMS]

    # Group by URL for cleaner reporting
    by_url: dict = {}
    for p in interesting:
        by_url.setdefault(p.url, [])
        by_url[p.url].append(p.name)

    for url, param_names in by_url.items():
        # Classify the risk
        idor_params    = [n for n in param_names if re.search(r'_id$|^id$|^uid$', n, re.I)]
        redirect_params= [n for n in param_names
                         if n.lower() in ("redirect","url","next","goto","return_url","redirect_uri")]
        ssrf_params    = [n for n in param_names
                         if n.lower() in ("webhook","callback_url","endpoint","proxy","remote","fetch","host")]
        file_params    = [n for n in param_names
                         if n.lower() in ("file","path","filename","dir","include","template","page","load")]
        debug_params   = [n for n in param_names
                         if n.lower() in ("debug","test","dev","verbose","trace")]

        if ssrf_params:
            findings.append(Finding(
                severity    = "high",
                title       = f"Potential SSRF parameters: {ssrf_params}",
                url         = url,
                evidence    = f"Parameters: {ssrf_params} — test with internal/cloud metadata URLs",
                module      = MODULE_NAME,
                remediation = "Validate and whitelist allowed URL schemes and hosts; use SSRF protection middleware",
                tags        = ["ssrf", "param", "high-value"],
            ))

        if redirect_params:
            findings.append(Finding(
                severity    = "medium",
                title       = f"Potential open redirect parameters: {redirect_params}",
                url         = url,
                evidence    = f"Parameters: {redirect_params}",
                module      = MODULE_NAME,
                remediation = "Validate redirect targets against an allowlist of trusted domains",
                tags        = ["open-redirect", "param"],
            ))

        if file_params:
            findings.append(Finding(
                severity    = "high",
                title       = f"Potential path traversal parameters: {file_params}",
                url         = url,
                evidence    = f"Parameters: {file_params}",
                module      = MODULE_NAME,
                remediation = "Canonicalize file paths; use allowlists; never pass raw user input to file operations",
                tags        = ["path-traversal", "lfi", "param"],
            ))

        if idor_params:
            findings.append(Finding(
                severity    = "medium",
                title       = f"Potential IDOR parameters: {idor_params}",
                url         = url,
                evidence    = f"Parameters: {idor_params}",
                module      = MODULE_NAME,
                remediation = "Enforce object-level authorization checks on all ID parameters",
                tags        = ["idor", "param"],
            ))

        if debug_params:
            findings.append(Finding(
                severity    = "low",
                title       = f"Debug parameters discovered: {debug_params}",
                url         = url,
                evidence    = f"Parameters: {debug_params}",
                module      = MODULE_NAME,
                remediation = "Disable debug parameters in production",
                tags        = ["debug", "param"],
            ))

    return findings


# ─────────────────────────────────────────────
# SAVE
# ─────────────────────────────────────────────

def _save_params(params: List[Parameter], out_dir: Path):
    lines = [f"{p.method} {p.url} [{p.type}] {p.name}" for p in params]
    (out_dir / "all_params.txt").write_text("\n".join(lines))

    data = [
        {"url": p.url, "name": p.name, "method": p.method, "type": p.type}
        for p in params
    ]
    (out_dir / "all_params.json").write_text(json.dumps(data, indent=2))
