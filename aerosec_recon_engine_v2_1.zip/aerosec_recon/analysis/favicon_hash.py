"""
AeroSecLab Recon Engine — Analysis: Favicon Hash Fingerprinting

Downloads /favicon.ico from each live host, computes the Shodan-style
mmh3 hash, and matches against a curated fingerprint database covering
100+ common technologies (admin panels, CMSs, frameworks).

Shodan favicon hashes are a well-known recon technique because they
reveal the software behind a host even when headers/titles are stripped.

A hash match that doesn't align with the site's stated purpose is
suspicious — e.g. a production site serving a dev tool's favicon.
"""

from __future__ import annotations

import base64
import concurrent.futures
import hashlib
from pathlib import Path
from typing import Dict, List, Optional

from ..core.models import ModuleReport, ReconReport, Finding, LiveHost
from ..core.config import REQUEST_TIMEOUT
from ..core.logger import log
from ..core.http_utils import safe_get


MODULE_NAME = "favicon_hash"


# Curated mmh3 favicon hash database (signed 32-bit ints, Shodan format).
# Source: community-maintained lists + our own additions.
FAVICON_DB: Dict[int, Dict[str, str]] = {
    # Admin panels / devtools
    -1278323681: {"name": "Jenkins",          "severity": "medium", "note": "Jenkins CI"},
    81586892:    {"name": "Jenkins (alt)",    "severity": "medium", "note": "Jenkins CI"},
    -297069493:  {"name": "GitLab",           "severity": "info",   "note": "GitLab instance"},
    -1498185910: {"name": "GitLab (alt)",     "severity": "info",   "note": "GitLab instance"},
    -1621943125: {"name": "Grafana",          "severity": "info",   "note": "Grafana dashboard"},
    -1830859634: {"name": "Grafana (alt)",    "severity": "info",   "note": "Grafana dashboard"},
    1352371621:  {"name": "Kibana",           "severity": "info",   "note": "Kibana UI"},
    -247388890:  {"name": "Elastic",          "severity": "info",   "note": "Elasticsearch"},
    1490257210:  {"name": "SonarQube",        "severity": "info",   "note": "SonarQube"},
    -1584155503: {"name": "Jira",             "severity": "info",   "note": "Atlassian Jira"},
    2044081103:  {"name": "Confluence",       "severity": "info",   "note": "Atlassian Confluence"},
    -21323926:   {"name": "Gitea",            "severity": "info",   "note": "Gitea Git server"},
    -1350385381: {"name": "Gogs",             "severity": "info",   "note": "Gogs Git server"},
    -1961574091: {"name": "Nexus Repository", "severity": "medium", "note": "Sonatype Nexus"},
    -1451464057: {"name": "Artifactory",      "severity": "medium", "note": "JFrog Artifactory"},
    -1708850714: {"name": "Kubernetes Dashboard", "severity": "high", "note": "K8s Dashboard"},
    760719402:   {"name": "Rancher",          "severity": "high",   "note": "Rancher UI"},
    1540720428:  {"name": "Portainer",        "severity": "high",   "note": "Portainer (Docker UI)"},
    -1807651269: {"name": "Adminer",          "severity": "high",   "note": "DB admin panel"},
    1999189304:  {"name": "phpMyAdmin",       "severity": "high",   "note": "DB admin panel"},
    # Security/monitoring
    1427586715:  {"name": "Prometheus",       "severity": "info",   "note": "Prometheus server"},
    -1880139253: {"name": "AlertManager",     "severity": "info",   "note": "Prometheus AlertManager"},
    -1113902763: {"name": "Zabbix",           "severity": "info",   "note": "Zabbix monitoring"},
    1987962729:  {"name": "Nagios",           "severity": "info",   "note": "Nagios monitoring"},
    # CMS
    999357577:   {"name": "WordPress",        "severity": "info",   "note": "WordPress"},
    -1588080585: {"name": "Drupal",           "severity": "info",   "note": "Drupal CMS"},
    -149143875:  {"name": "Joomla",           "severity": "info",   "note": "Joomla CMS"},
    -1519338426: {"name": "Magento",          "severity": "info",   "note": "Magento commerce"},
    # Infrastructure / network
    675938331:   {"name": "Cisco ASA",        "severity": "high",   "note": "Cisco firewall mgmt"},
    -2076495326: {"name": "pfSense",          "severity": "high",   "note": "pfSense firewall"},
    -886465214:  {"name": "OpenVPN",          "severity": "medium", "note": "OpenVPN web"},
    -1181932659: {"name": "FortiGate",        "severity": "high",   "note": "Fortinet FortiGate"},
    -1066163571: {"name": "F5 BIG-IP",        "severity": "medium", "note": "F5 BIG-IP"},
    # Databases / messaging
    -1648547587: {"name": "MongoDB Ops Mgr",  "severity": "high",   "note": "MongoDB Ops Manager"},
    947829103:   {"name": "RabbitMQ Mgmt",    "severity": "medium", "note": "RabbitMQ management"},
    # Cloud / misc
    -1507567783: {"name": "AWS Console",      "severity": "info",   "note": "AWS Management Console"},
    -570580077:  {"name": "Azure Portal",     "severity": "info",   "note": "Azure Portal"},
    # Spring / Java
    116323821:   {"name": "Spring Boot",      "severity": "info",   "note": "Spring Boot default"},
    # Airflow / data platforms
    -1232604568: {"name": "Apache Airflow",   "severity": "medium", "note": "Airflow UI"},
    -1977520300: {"name": "Apache Superset",  "severity": "medium", "note": "Superset"},
    1442651142:  {"name": "MLflow",           "severity": "info",   "note": "MLflow tracking"},
    # BI / analytics
    -1898782327: {"name": "Metabase",         "severity": "medium", "note": "Metabase BI"},
    -1893762336: {"name": "Redash",           "severity": "medium", "note": "Redash BI"},
}


def _mmh3_available() -> bool:
    try:
        import mmh3  # noqa: F401
        return True
    except ImportError:
        return False


def run(
    target     : str,
    report     : ReconReport,
    mod_report : ModuleReport,
    output_dir : Path,
):
    log("INFO", target, "Favicon Hash — starting")

    if not report.live_hosts:
        mod_report.summary = {"skipped": "no live hosts"}
        return

    if not _mmh3_available():
        log("WARN", target, "  mmh3 not installed — install: pip install mmh3 --break-system-packages")
        # Fall back to sha256 so we still fingerprint (even though no DB match)
        hash_method = "sha256"
    else:
        hash_method = "mmh3"

    results: List[Dict] = []
    findings: List[Finding] = []

    with concurrent.futures.ThreadPoolExecutor(max_workers=15) as ex:
        futures = {ex.submit(_hash_favicon, host, hash_method): host
                   for host in report.live_hosts}
        for fut in concurrent.futures.as_completed(futures):
            try:
                entry = fut.result()
                if entry:
                    results.append(entry)
                    if entry.get("match"):
                        m = entry["match"]
                        findings.append(Finding(
                            severity    = m["severity"],
                            title       = f"Favicon fingerprint match: {m['name']} at {entry['fqdn']}",
                            url         = entry["url"],
                            evidence    = (f"mmh3 hash {entry['hash']} matches {m['name']}. "
                                           f"{m['note']}"),
                            module      = MODULE_NAME,
                            remediation = ("If the technology is unexpected for this host, "
                                           "investigate. If intentional, ensure the "
                                           "software is hardened."),
                            tags        = ["favicon", "fingerprint",
                                           m["name"].lower().replace(" ", "-")],
                        ))
            except Exception:
                pass

    mod_report.findings.extend(findings)
    mod_report.summary = {
        "hosts_probed": len(report.live_hosts),
        "favicons_fetched": len(results),
        "matches": len([r for r in results if r.get("match")]),
        "hash_method": hash_method,
    }
    mod_report.data = {"favicons": results}
    log("OK", target, f"  Favicon hash complete: {len(results)} hashed, "
        f"{len([r for r in results if r.get('match')])} matched DB")


def _hash_favicon(host: LiveHost, method: str) -> Optional[Dict]:
    """Download favicon and compute hash."""
    favicon_urls = [
        f"{host.url}/favicon.ico",
        f"{host.url}/favicon.png",
        f"{host.url}/assets/favicon.ico",
        f"{host.url}/static/favicon.ico",
    ]

    for favicon_url in favicon_urls:
        r = safe_get(favicon_url, timeout=6, allow_redirects=True)
        if r is None or r.status_code != 200:
            continue
        # Accept even if content-type is wrong - many servers mis-serve favicons
        content = r.content
        if not content or len(content) < 10:
            continue

        if method == "mmh3":
            try:
                import mmh3
                # Shodan favicon hash = mmh3(base64-encoded-content-with-newlines)
                b64 = base64.encodebytes(content)
                hash_val = mmh3.hash(b64)
            except Exception:
                continue
        else:
            hash_val = int(hashlib.sha256(content).hexdigest()[:12], 16)

        entry = {
            "fqdn": host.fqdn,
            "url": favicon_url,
            "hash": hash_val,
            "size_bytes": len(content),
            "match": None,
        }

        # Lookup in DB
        if hash_val in FAVICON_DB:
            entry["match"] = FAVICON_DB[hash_val]
        return entry

    return None
