"""
AeroSecLab Recon Engine — Analysis: Link Crawler
Tools: katana, gau, waybackurls, hakrawler
Crawls live hosts and archives to build comprehensive URL map.
"""

from __future__ import annotations

import json
import re
import tempfile
from pathlib import Path
from typing import List, Set
from urllib.parse import urljoin, urlparse

from ..core.models import (
    ModuleReport, ReconReport, CrawledLink, Finding
)
from ..core.config import (
    get_tool, TOOL_TIMEOUT, MAX_CRAWL_DEPTH, MAX_CRAWL_PAGES,
)
from ..core.logger import log
from ..core.http_utils import run_tool, safe_get


MODULE_NAME = "link_crawler"

# Interesting path keywords to flag
SENSITIVE_PATH_KEYWORDS = [
    "admin", "debug", "test", "backup", "config", "secret", "private",
    "internal", "management", "console", "dashboard", "panel",
    "upload", "download", "export", "import", "dump", "log",
    ".env", ".git", ".sql", ".bak", ".conf", ".key", ".pem",
    "swagger", "api-docs", "openapi", "graphql",
    "actuator", "health", "metrics", "status",
]


def run(
    target     : str,
    report     : ReconReport,
    mod_report : ModuleReport,
    output_dir : Path,
):
    log("INFO", target, "Link Crawler — starting")

    all_urls: Set[str] = set()
    crawl_dir = output_dir / "crawl"
    crawl_dir.mkdir(exist_ok=True)

    # Collect target URLs from live hosts
    target_urls = [h.url for h in report.live_hosts]
    # Prioritize apex + main subdomains
    target_urls = sorted(set(target_urls), key=lambda u: (
        0 if target in u and u.count(".") <= 1 else 1
    ))[:20]

    if not target_urls:
        target_urls = [f"https://{target}", f"http://{target}"]

    # ── katana — active crawler ───────────────────────────────────────
    if get_tool("katana"):
        katana_urls = _run_katana(target_urls, target, crawl_dir)
        all_urls.update(katana_urls)
        log("OK", target, f"  katana → {len(katana_urls)}")

    # ── gau — historical URLs ──────────────────────────────────────────
    if get_tool("gau"):
        gau_urls = _run_gau(target, crawl_dir)
        all_urls.update(gau_urls)
        log("OK", target, f"  gau → {len(gau_urls)}")

    # ── waybackurls ────────────────────────────────────────────────────
    if get_tool("waybackurls"):
        wb_urls = _run_waybackurls(target, crawl_dir)
        all_urls.update(wb_urls)
        log("OK", target, f"  waybackurls → {len(wb_urls)}")

    # ── hakrawler ──────────────────────────────────────────────────────
    if get_tool("hakrawler"):
        hak_urls = _run_hakrawler(target_urls[:5], target, crawl_dir)
        all_urls.update(hak_urls)
        log("OK", target, f"  hakrawler → {len(hak_urls)}")

    # ── Fallback: basic requests crawler ─────────────────────────────
    if not all_urls:
        basic_urls = _basic_crawl(target_urls[:3], target)
        all_urls.update(basic_urls)

    # ── Filter to target domain only ──────────────────────────────────
    filtered = _filter_to_target(all_urls, target)
    log("OK", target, f"  Total URLs (in-scope): {len(filtered)}")

    # ── Save to report ────────────────────────────────────────────────
    crawled_links = [
        CrawledLink(url=url, source=MODULE_NAME)
        for url in sorted(filtered)
    ]
    report.crawled_links = crawled_links

    # ── Generate findings ─────────────────────────────────────────────
    findings = _analyze_urls(filtered, target)
    mod_report.findings.extend(findings)

    # Save raw URL list
    (crawl_dir / "all_urls.txt").write_text("\n".join(sorted(filtered)))

    # ── Summary ───────────────────────────────────────────────────────
    ext_counts = _count_extensions(filtered)
    mod_report.summary = {
        "total_urls"       : len(filtered),
        "sensitive_paths"  : sum(1 for u in filtered
                                if any(k in u.lower() for k in SENSITIVE_PATH_KEYWORDS)),
        "extension_counts" : ext_counts,
        "findings"         : len(findings),
        "tools_used"       : [t for t in ["katana","gau","waybackurls","hakrawler"]
                              if get_tool(t)],
    }
    mod_report.data = {
        "sample_urls"      : sorted(filtered)[:200],
        "sensitive_urls"   : [u for u in filtered
                             if any(k in u.lower() for k in SENSITIVE_PATH_KEYWORDS)][:50],
    }
    log("OK", target, f"  Crawl complete: {len(filtered)} URLs, {len(findings)} findings")


# ─────────────────────────────────────────────
# TOOL RUNNERS
# ─────────────────────────────────────────────

def _run_katana(urls: List[str], target: str, out_dir: Path) -> Set[str]:
    found    = set()
    katana   = get_tool("katana")
    out_file = str(out_dir / "katana.txt")

    # Write URLs to temp file
    with tempfile.NamedTemporaryFile(mode="w", suffix=".txt", delete=False) as f:
        f.write("\n".join(urls))
        url_file = f.name

    stdout, _, _ = run_tool(
        [
            katana,
            "-list", url_file,
            "-depth", str(MAX_CRAWL_DEPTH),
            "-js-crawl",           # Parse JS files for URLs
            "-known-files", "all", # robots.txt, sitemap.xml
            "-automatic-form-fill",
            "-ct", str(MAX_CRAWL_PAGES),
            "-c", "20",
            "-rate-limit", "150",
            "-timeout", "10",
            "-silent",
            "-o", out_file,
        ],
        timeout=TOOL_TIMEOUT,
        target=target,
    )

    out_path = Path(out_file)
    if out_path.exists():
        found.update(l.strip() for l in out_path.read_text().splitlines() if l.strip())

    import os
    try:
        os.unlink(url_file)
    except Exception:
        pass

    return found


def _run_gau(target: str, out_dir: Path) -> Set[str]:
    found    = set()
    gau      = get_tool("gau")
    out_file = str(out_dir / "gau.txt")

    stdout, _, _ = run_tool(
        [
            gau,
            "--threads", "5",
            "--timeout", "60",
            "--blacklist", "png,jpg,gif,svg,ico,woff,woff2,ttf,css",
            "--subs",
            "--o", out_file,
            target,
        ],
        timeout=TOOL_TIMEOUT,
        target=target,
    )

    out_path = Path(out_file)
    if out_path.exists():
        found.update(l.strip() for l in out_path.read_text().splitlines() if l.strip())

    return found


def _run_waybackurls(target: str, out_dir: Path) -> Set[str]:
    found       = set()
    waybackurls = get_tool("waybackurls")
    out_file    = str(out_dir / "waybackurls.txt")

    stdout, _, _ = run_tool(
        [waybackurls, target],
        timeout=TOOL_TIMEOUT,
        target=target,
    )

    if stdout:
        lines = stdout.splitlines()
        found.update(l.strip() for l in lines if l.strip())
        (out_dir / "waybackurls.txt").write_text(stdout)

    return found


def _run_hakrawler(
    urls    : List[str],
    target  : str,
    out_dir : Path,
) -> Set[str]:
    found      = set()
    hakrawler  = get_tool("hakrawler")

    stdin_data = "\n".join(urls)

    stdout, _, _ = run_tool(
        [
            hakrawler,
            "-depth", str(MAX_CRAWL_DEPTH),
            "-insecure",
            "-subs",
            "-u",      # Unique URLs only
        ],
        timeout=TOOL_TIMEOUT,
        target=target,
        stdin=stdin_data,
    )

    if stdout:
        found.update(l.strip() for l in stdout.splitlines() if l.strip())

    return found


# ─────────────────────────────────────────────
# FALLBACK CRAWLER
# ─────────────────────────────────────────────

def _basic_crawl(start_urls: List[str], target: str) -> Set[str]:
    """Basic BFS crawler using requests."""
    found    : Set[str] = set()
    visited  : Set[str] = set()
    queue    : List[str] = list(start_urls)
    max_pages = 50

    LINK_RE = re.compile(
        r'(?:href|src|action|data-url|data-href)=["\']([^"\'#?][^"\']*)["\']',
        re.I
    )

    while queue and len(visited) < max_pages:
        url = queue.pop(0)
        if url in visited:
            continue
        visited.add(url)

        r = safe_get(url, allow_redirects=True)
        if not r or r.status_code >= 400:
            continue

        found.add(url)

        ct = r.headers.get("content-type", "").lower()
        if "text/html" not in ct:
            continue

        base_url = url
        for link in LINK_RE.findall(r.text):
            full = urljoin(base_url, link)
            parsed = urlparse(full)
            if target in parsed.netloc and full not in visited:
                queue.append(full)
                found.add(full)

    return found


# ─────────────────────────────────────────────
# FILTERING & ANALYSIS
# ─────────────────────────────────────────────

def _filter_to_target(urls: Set[str], target: str) -> Set[str]:
    """Keep only URLs belonging to the target domain."""
    filtered = set()
    for url in urls:
        try:
            parsed = urlparse(url)
            if not parsed.scheme or not parsed.netloc:
                continue
            netloc = parsed.netloc.lower().split(":")[0]
            if netloc == target or netloc.endswith(f".{target}"):
                filtered.add(url)
        except Exception:
            pass
    return filtered


def _analyze_urls(urls: Set[str], target: str) -> List[Finding]:
    """Generate findings from crawled URLs."""
    findings = []
    flagged  : Set[str] = set()

    for url in sorted(urls):
        url_lower = url.lower()
        parsed    = urlparse(url)
        path      = parsed.path.lower()

        for keyword in SENSITIVE_PATH_KEYWORDS:
            if keyword in path and url not in flagged:
                sev = _path_severity(path)
                if sev in ("high", "critical"):
                    findings.append(Finding(
                        severity    = sev,
                        title       = f"Sensitive URL discovered: {path}",
                        url         = url,
                        evidence    = f"Path contains keyword: {keyword}",
                        module      = MODULE_NAME,
                        remediation = "Verify access control on this endpoint; restrict to authorized users",
                        tags        = ["crawl", "sensitive-path", keyword],
                    ))
                    flagged.add(url)
                break

        # Detect IDOR candidates: sequential IDs in path
        if re.search(r'/\d{1,8}(?:/|$)', path):
            if any(kw in path for kw in [
                "user", "account", "order", "transaction",
                "invoice", "fund", "wallet", "payment",
            ]):
                findings.append(Finding(
                    severity    = "medium",
                    title       = f"Potential IDOR endpoint (numeric ID in path)",
                    url         = url,
                    evidence    = f"URL contains numeric ID: {path}",
                    module      = MODULE_NAME,
                    remediation = "Test for IDOR — try accessing other user IDs",
                    tags        = ["idor", "crawl"],
                ))

    # Check for backup/export files
    backup_exts = [".bak", ".backup", ".old", ".orig", ".copy",
                   ".sql", ".dump", ".tar.gz", ".zip", ".7z"]
    for url in urls:
        path = urlparse(url).path.lower()
        if any(path.endswith(ext) for ext in backup_exts):
            findings.append(Finding(
                severity    = "high",
                title       = f"Backup/archive file accessible: {path}",
                url         = url,
                evidence    = f"File with backup extension found: {path}",
                module      = MODULE_NAME,
                remediation = "Remove backup files from web-accessible directories",
                tags        = ["backup", "info-disclosure"],
            ))

    return findings


def _path_severity(path: str) -> str:
    critical = {".env", ".git", ".sql", ".key", ".pem", "private", "secret"}
    high     = {"admin", "debug", "backup", "config", "dump", "export",
                "actuator", "console", "management"}
    medium   = {"test", "swagger", "api-docs", "openapi", "graphql", "panel"}

    if any(kw in path for kw in critical):
        return "high"
    if any(kw in path for kw in high):
        return "high"
    if any(kw in path for kw in medium):
        return "medium"
    return "info"


def _count_extensions(urls: Set[str]) -> dict:
    counts = {}
    for url in urls:
        ext = re.search(r'\.([a-z0-9]{2,5})(?:\?|$)', urlparse(url).path.lower())
        if ext:
            key = ext.group(1)
            counts[key] = counts.get(key, 0) + 1
    return dict(sorted(counts.items(), key=lambda x: x[1], reverse=True)[:20])
