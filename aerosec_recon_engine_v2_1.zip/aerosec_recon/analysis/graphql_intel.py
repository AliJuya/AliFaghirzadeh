"""
AeroSecLab Recon Engine — Analysis: GraphQL Intelligence

For each /graphql, /api/graphql, /v1/graphql endpoint discovered (via crawler
or known paths), attempts schema introspection and extracts:
  - all types
  - all queries / mutations / subscriptions
  - sensitive fields (auth, payment, admin, internal)

Detection-only — does NOT execute mutations or fetch user data.
Only sends the standard introspection query (which is itself a *read* operation).
"""

from __future__ import annotations

import concurrent.futures
import json
import re
from pathlib import Path
from typing import Dict, List, Set
from urllib.parse import urljoin

from ..core.models import ModuleReport, ReconReport, Finding
from ..core.config import REQUEST_TIMEOUT
from ..core.logger import log
from ..core.http_utils import safe_post, safe_get


MODULE_NAME = "graphql_intel"


GRAPHQL_PATHS = [
    "/graphql", "/api/graphql", "/v1/graphql", "/v2/graphql",
    "/graphql/v1", "/graphql/v2", "/api/v1/graphql", "/api/v2/graphql",
    "/query", "/api/query",
    "/graphiql",            # may indicate graphql nearby
    "/playground",
    "/altair",
    "/voyager",
]

INTROSPECTION_QUERY = """
query IntrospectionQuery {
  __schema {
    queryType { name }
    mutationType { name }
    subscriptionType { name }
    types {
      kind
      name
      description
      fields(includeDeprecated: true) {
        name
        description
        args { name type { name kind ofType { name kind } } }
        type { name kind ofType { name kind } }
      }
      inputFields { name type { name kind ofType { name kind } } }
    }
  }
}
"""

SENSITIVE_FIELD_KEYWORDS = [
    "password", "passwd", "secret", "token", "auth", "credential",
    "admin", "internal", "private", "ssn", "card", "iban", "pan",
    "balance", "wallet", "transfer", "withdraw", "deposit",
    "user", "email", "phone", "kyc",
]


def run(
    target     : str,
    report     : ReconReport,
    mod_report : ModuleReport,
    output_dir : Path,
):
    log("INFO", target, "GraphQL Intel — starting")

    if not report.live_hosts:
        mod_report.summary = {"skipped": "no live hosts"}
        return

    # Build candidate URL list
    candidates: Set[str] = set()
    for host in report.live_hosts:
        for path in GRAPHQL_PATHS:
            candidates.add(host.url.rstrip("/") + path)

    # Also use crawler results to discover non-standard paths
    for link in (report.crawled_links or []):
        url = link.url.lower() if hasattr(link, 'url') else str(link).lower()
        if "graphql" in url or url.endswith("/graphql"):
            candidates.add(link.url if hasattr(link, 'url') else link)

    log("INFO", target, f"  Probing {len(candidates)} GraphQL candidates")

    findings: List[Finding] = []
    schemas:  List[Dict] = []

    with concurrent.futures.ThreadPoolExecutor(max_workers=10) as ex:
        futures = {ex.submit(_probe_graphql_endpoint, url): url
                   for url in list(candidates)[:60]}
        for fut in concurrent.futures.as_completed(futures):
            try:
                result = fut.result()
                if not result:
                    continue
                if result.get("introspection_enabled"):
                    schemas.append(result)
                    findings.extend(_findings_from_schema(result))
                elif result.get("endpoint_exists"):
                    findings.append(Finding(
                        severity    = "info",
                        title       = f"GraphQL endpoint detected (no introspection): {result['url']}",
                        url         = result["url"],
                        evidence    = (f"Endpoint returns {result['status']} to introspection query. "
                                       f"Introspection appears disabled — good!"),
                        module      = MODULE_NAME,
                        remediation = "Continue to keep introspection disabled in production.",
                        tags        = ["graphql", "info"],
                    ))
            except Exception:
                pass

    mod_report.findings.extend(findings)
    mod_report.summary = {
        "endpoints_probed"          : len(candidates),
        "introspection_enabled_count": len(schemas),
        "findings"                  : len(findings),
        "endpoints_with_introspection": [s["url"] for s in schemas],
    }
    mod_report.data = {
        "schemas": [
            {
                "url": s["url"],
                "types_count": len(s.get("types", [])),
                "queries_count": len(s.get("queries", [])),
                "mutations_count": len(s.get("mutations", [])),
                "sensitive_fields": s.get("sensitive_fields", [])[:50],
                "all_queries": [q["name"] for q in s.get("queries", [])][:100],
                "all_mutations": [m["name"] for m in s.get("mutations", [])][:100],
            }
            for s in schemas
        ],
    }

    # Save full schemas to disk
    if schemas:
        gql_dir = output_dir / "graphql"
        gql_dir.mkdir(exist_ok=True)
        for i, s in enumerate(schemas):
            (gql_dir / f"schema_{i}.json").write_text(
                json.dumps(s, indent=2, default=str)
            )

    log("OK", target, f"  GraphQL complete: {len(schemas)} schemas extracted, "
        f"{len(findings)} findings")


def _probe_graphql_endpoint(url: str) -> Dict:
    """Probe a URL for GraphQL with introspection."""
    # First, send the introspection query
    r = safe_post(url, json_body={"query": INTROSPECTION_QUERY}, timeout=12)
    if r is None:
        return {}

    # Check if it's a GraphQL endpoint at all
    ct = r.headers.get("content-type", "").lower()
    body = (r.text or "")[:50000]

    if r.status_code in (404, 400) and "graphql" not in body.lower():
        return {}

    if "application/json" not in ct and "{" not in body[:100]:
        return {}

    try:
        data = r.json()
    except Exception:
        return {"endpoint_exists": True, "url": url, "status": r.status_code,
                "introspection_enabled": False}

    # Check for schema
    schema = (data.get("data", {}) or {}).get("__schema") if isinstance(data, dict) else None
    if not schema:
        # Endpoint exists but introspection blocked
        return {"endpoint_exists": True, "url": url, "status": r.status_code,
                "introspection_enabled": False, "raw_response": str(data)[:200]}

    # Parse schema
    types_list = schema.get("types", []) or []
    query_type_name    = (schema.get("queryType")    or {}).get("name", "")
    mutation_type_name = (schema.get("mutationType") or {}).get("name", "")
    sub_type_name      = (schema.get("subscriptionType") or {}).get("name", "")

    queries = []
    mutations = []
    subscriptions = []
    sensitive_fields = []

    for t in types_list:
        if not isinstance(t, dict):
            continue
        type_name = t.get("name", "")
        fields = t.get("fields", []) or []

        for field in fields:
            field_name = field.get("name", "")
            if not field_name:
                continue

            field_info = {
                "name": field_name,
                "type": _extract_type_name(field.get("type", {})),
                "args": [a.get("name", "") for a in (field.get("args", []) or [])],
                "description": (field.get("description", "") or "")[:200],
            }

            # Bucket by parent type
            if type_name == query_type_name:
                queries.append(field_info)
            elif type_name == mutation_type_name:
                mutations.append(field_info)
            elif type_name == sub_type_name:
                subscriptions.append(field_info)

            # Flag sensitive
            field_lower = (field_name + " " + (field.get("description", "") or "")).lower()
            if any(kw in field_lower for kw in SENSITIVE_FIELD_KEYWORDS):
                sensitive_fields.append({
                    "type": type_name,
                    "field": field_name,
                    "field_type": field_info["type"],
                })

    return {
        "url": url,
        "status": r.status_code,
        "endpoint_exists": True,
        "introspection_enabled": True,
        "queries": queries,
        "mutations": mutations,
        "subscriptions": subscriptions,
        "types": [t.get("name", "") for t in types_list if t.get("name")],
        "sensitive_fields": sensitive_fields,
    }


def _extract_type_name(type_obj: Dict) -> str:
    """Extract human-readable type from GraphQL type object."""
    if not type_obj:
        return ""
    name = type_obj.get("name")
    if name:
        return name
    of_type = type_obj.get("ofType")
    if of_type:
        return _extract_type_name(of_type)
    return type_obj.get("kind", "")


def _findings_from_schema(schema: Dict) -> List[Finding]:
    """Generate findings from an extracted GraphQL schema."""
    findings = []
    url = schema["url"]

    # Finding: introspection enabled
    findings.append(Finding(
        severity    = "medium",
        title       = f"GraphQL introspection enabled: {url}",
        url         = url,
        evidence    = (f"Schema disclosed: {len(schema.get('queries',[]))} queries, "
                       f"{len(schema.get('mutations',[]))} mutations, "
                       f"{len(schema.get('types',[]))} types"),
        module      = MODULE_NAME,
        remediation = ("Disable GraphQL introspection in production. "
                       "Apollo: NODE_ENV=production. graphql-yoga: introspection: false."),
        tags        = ["graphql", "introspection", "info-disclosure"],
    ))

    # Finding: sensitive fields enumerated
    if schema.get("sensitive_fields"):
        sample = schema["sensitive_fields"][:8]
        evidence = "; ".join(f"{f['type']}.{f['field']}" for f in sample)
        findings.append(Finding(
            severity    = "high",
            title       = f"Sensitive GraphQL fields disclosed: {url}",
            url         = url,
            evidence    = (f"Found {len(schema['sensitive_fields'])} fields with "
                           f"sensitive keywords. Examples: {evidence}"),
            module      = MODULE_NAME,
            remediation = ("Disable introspection in production AND audit field-level "
                           "authorization on these endpoints."),
            tags        = ["graphql", "sensitive-fields", "auth-risk"],
        ))

    # Finding: dangerous mutations exist
    dangerous_mutation_keywords = [
        "delete", "remove", "drop", "destroy", "purge",
        "transfer", "withdraw", "send", "execute", "run",
        "createadmin", "grant", "elevate", "impersonate",
    ]
    dangerous_mutations = [
        m for m in schema.get("mutations", [])
        if any(kw in m["name"].lower() for kw in dangerous_mutation_keywords)
    ]
    if dangerous_mutations:
        names = [m["name"] for m in dangerous_mutations[:10]]
        findings.append(Finding(
            severity    = "high",
            title       = f"Dangerous GraphQL mutations discovered: {url}",
            url         = url,
            evidence    = f"Mutations with high-impact verbs: {', '.join(names)}",
            module      = MODULE_NAME,
            remediation = ("Audit authorization on each mutation. Ensure rate limiting. "
                           "Consider depth/complexity limits."),
            tags        = ["graphql", "high-impact-mutations"],
        ))

    return findings
