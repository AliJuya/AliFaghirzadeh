"""
AeroSecLab Recon Engine — Export: Executive Report Generator

Produces:
  report.json  — structured, schema-versioned machine-readable output
  report.md    — executive-quality markdown with:
                   * hero + risk grade
                   * executive summary (auto-generated bullets)
                   * risk dashboard (mermaid pie + bar charts)
                   * top findings with reproduction context
                   * asset inventory sorted by risk score
                   * per-severity finding detail
                   * attack-surface analysis (tech, ports, CDN)
                   * JS intelligence highlights
                   * methodology + tool inventory
                   * appendix (raw counts, scan timeline)
"""

from __future__ import annotations

import json
import re
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional

from ..core.models import ReconReport, Finding, LiveHost, Subdomain, Parameter
from ..core.risk_engine import (
    score_target, executive_summary_bullets, TargetScore, AssetScore, FindingScore
)


SEVERITY_EMOJI = {
    "critical": "🔴",
    "high"    : "🟠",
    "medium"  : "🟡",
    "low"     : "🔵",
    "info"    : "⚪",
}

SCHEMA_VERSION = "2.0"


class Reporter:
    def __init__(self, report: ReconReport, output_dir: Path):
        self.report     = report
        self.output_dir = output_dir
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.target_score: TargetScore = score_target(report)
        # Load previous report.json for diff (must happen BEFORE we overwrite it)
        self._previous = self._load_previous_report()
        self._diff: Optional[Dict] = None

    def _load_previous_report(self) -> Optional[Dict]:
        """Load the previous report.json if it exists, for diff comparison."""
        path = self.output_dir / "report.json"
        if not path.exists():
            return None
        try:
            return json.loads(path.read_text())
        except Exception:
            return None

    # ═════════════════════════════════════════════════════════════════
    # JSON EXPORT
    # ═════════════════════════════════════════════════════════════════

    def write_json(self):
        r = self.report
        ts = self.target_score
        data = {
            "schema_version": SCHEMA_VERSION,
            "meta": {
                "target"        : r.target,
                "generated_at"  : r.generated_at,
                "engine_version": r.engine_version,
                "engine_name"   : "AeroSecLab Recon Engine",
                "stats"         : r.stats(),
            },
            "risk": {
                "score"        : ts.score,
                "grade"        : ts.grade,
                "grade_color"  : ts.grade_color,
                "grade_summary": ts.summary,
                "top_findings" : [self._scored_finding_dict(fs)
                                  for fs in ts.top_findings],
                "per_asset"    : {
                    fqdn: {
                        "url"      : a.url,
                        "score"    : a.raw_score,
                        "critical" : a.critical_count,
                        "high"     : a.high_count,
                        "medium"   : a.medium_count,
                        "low"      : a.low_count,
                        "info"     : a.info_count,
                        "notes"    : a.notes,
                    }
                    for fqdn, a in ts.per_asset.items()
                },
            },
            "executive_summary": executive_summary_bullets(ts, r),
            "whois": r.whois.__dict__ if r.whois else {},
            "asn"  : r.asn.__dict__   if r.asn else {},
            "dns_records": [
                {"type": rec.type, "value": rec.value, "ttl": rec.ttl}
                for rec in r.dns_records
            ],
            "subdomains": self._subdomains_json(r),
            "live_hosts": self._live_hosts_json(r),
            "js_intel":   self._js_intel_json(r),
            "crawled_links": [
                {"url": l.url, "status": l.status}
                for l in (r.crawled_links or [])[:3000]
            ],
            "parameters": [
                {"url": p.url, "name": p.name, "method": p.method, "type": p.type}
                for p in r.parameters
            ],
            "findings": [
                {
                    "id"          : self._finding_id(f, i),
                    "severity"    : f.severity,
                    "title"       : f.title,
                    "url"         : f.url,
                    "evidence"    : f.evidence,
                    "module"      : f.module,
                    "cve"         : f.cve,
                    "remediation" : f.remediation,
                    "tags"        : f.tags,
                    "risk_score"  : self._risk_score_of(f),
                }
                for i, f in enumerate(r.all_findings())
            ],
            "modules": self._modules_to_dict(),
        }

        # Compute diff against previous report (if any)
        if self._previous:
            from ..core.risk_engine import diff_reports
            self._diff = diff_reports(self._previous, data)
            data["diff"] = self._diff

        out_path = self.output_dir / "report.json"
        out_path.write_text(json.dumps(data, indent=2, ensure_ascii=False,
                                       default=self._json_default))

        # Write sidecar diff file for easy consumption
        if self._diff is not None:
            diff_path = self.output_dir / "report_diff.json"
            diff_path.write_text(json.dumps(self._diff, indent=2, ensure_ascii=False,
                                            default=self._json_default))

    def _scored_finding_dict(self, fs: FindingScore) -> Dict:
        f = fs.finding
        return {
            "title"     : f.title,
            "severity"  : f.severity,
            "url"       : f.url,
            "cve"       : f.cve,
            "risk_score": fs.score,
            "reasons"   : fs.reasons,
            "module"    : f.module,
            "tags"      : f.tags,
        }

    def _risk_score_of(self, finding: Finding) -> float:
        from ..core.risk_engine import score_finding
        return score_finding(finding).score

    def _subdomains_json(self, r: ReconReport) -> List[Dict]:
        out = []
        for s in sorted(r.subdomains, key=lambda x: x.fqdn):
            out.append({
                "fqdn"   : s.fqdn,
                "ips"    : s.ips,
                "cname"  : s.cname,
                "source" : s.source,
                "live"   : s.live_host is not None,
                "status" : s.live_host.status if s.live_host else 0,
                "title"  : s.live_host.title  if s.live_host else "",
                "cdn"    : s.live_host.cdn    if s.live_host else "",
                "waf"    : s.live_host.waf    if s.live_host else "",
                "tech"   : [t.name for t in s.live_host.tech] if s.live_host else [],
            })
        return out

    def _live_hosts_json(self, r: ReconReport) -> List[Dict]:
        out = []
        for h in r.live_hosts:
            out.append({
                "fqdn"      : h.fqdn,
                "url"       : h.url,
                "final_url" : h.final_url,
                "ip"        : h.ip,
                "status"    : h.status,
                "title"     : h.title,
                "server"    : h.server,
                "cdn"       : h.cdn,
                "waf"       : h.waf,
                "is_spa"    : h.is_spa,
                "tech"      : [
                    {"name": t.name, "version": t.version, "category": t.category}
                    for t in h.tech
                ],
                "ports"     : [
                    {"port": p.port, "proto": p.protocol, "service": p.service,
                     "version": p.version, "banner": (p.banner or "")[:200]}
                    for p in h.ports
                ],
                "cert": {
                    "subject"    : h.cert.subject,
                    "issuer"     : h.cert.issuer,
                    "san_domains": h.cert.san_domains,
                    "valid_from" : h.cert.valid_from,
                    "valid_to"   : h.cert.valid_to,
                    "expired"    : h.cert.expired,
                    "self_signed": h.cert.self_signed,
                } if h.cert else {},
                "screenshot": h.headers.get("_screenshot_path") if h.headers else None,
            })
        return out

    def _js_intel_json(self, r: ReconReport) -> Dict:
        if not r.js_intel:
            return {"files_analyzed": 0}
        j = r.js_intel
        return {
            "files_analyzed"   : len(j.files),
            "api_urls"         : j.all_api_urls[:200],
            "api_paths"        : j.all_api_paths[:400],
            "transfer_paths"   : j.all_transfer_paths,
            "auth_headers"     : j.all_auth_headers,
            "api_keys"         : j.all_api_keys,
            "jwt_secrets_count": len(j.all_jwt_secrets),
            "s3_buckets"       : j.all_s3_buckets,
            "private_ips"      : j.all_private_ips,
            "websockets"       : j.all_websockets,
            "firebase"         : j.all_firebase,
        }

    def _modules_to_dict(self) -> Dict:
        result = {}
        for attr in vars(self.report):
            if attr.startswith("module_"):
                mod = getattr(self.report, attr)
                if mod:
                    result[attr] = {
                        "status"        : mod.status,
                        "duration_sec"  : mod.duration_sec,
                        "started_at"    : mod.started_at,
                        "finished_at"   : mod.finished_at,
                        "error"         : mod.error,
                        "summary"       : mod.summary,
                        "findings_count": len(mod.findings),
                    }
        return result

    def _finding_id(self, f: Finding, idx: int) -> str:
        import hashlib
        h = hashlib.sha256(f"{f.title}|{f.url}".encode()).hexdigest()[:8]
        return f"AERO-{f.module}-{f.severity}-{h}"

    def _json_default(self, obj):
        if hasattr(obj, "__dict__"):
            return obj.__dict__
        return str(obj)

    # ═════════════════════════════════════════════════════════════════
    # MARKDOWN EXPORT
    # ═════════════════════════════════════════════════════════════════

    def write_markdown(self):
        lines: List[str] = []
        r     = self.report
        ts    = self.target_score
        stats = r.stats()
        all_f = r.all_findings()
        now   = datetime.utcnow().strftime("%Y-%m-%d %H:%M UTC")

        lines.extend(self._build_hero(r, ts, stats, now))
        lines.extend(self._build_executive_summary(ts, r))
        lines.extend(self._build_diff_section())
        lines.extend(self._build_risk_dashboard(ts, stats, r))
        lines.extend(self._build_top_findings(ts))
        lines.extend(self._build_asset_inventory(ts, r))
        lines.extend(self._build_findings_by_severity(all_f))
        lines.extend(self._build_attack_surface(r))
        lines.extend(self._build_js_intelligence(r))
        lines.extend(self._build_cdn_waf(r))
        lines.extend(self._build_subdomain_table(r))
        lines.extend(self._build_org_info(r))
        lines.extend(self._build_methodology(r))
        lines.extend(self._build_appendix(r))

        out_path = self.output_dir / "report.md"
        out_path.write_text("\n".join(lines), encoding="utf-8")

    # ─────────────────────────────────────────────
    # HERO
    # ─────────────────────────────────────────────

    def _build_hero(self, r, ts, stats, now) -> List[str]:
        color_hex = ts.grade_color.lstrip('#')
        grade_badge = f"![Grade](https://img.shields.io/badge/grade-{ts.grade}-{color_hex})"
        score_badge = (f"![Risk Score](https://img.shields.io/badge/risk--score-"
                       f"{ts.score:.1f}%2F100-{color_hex})")
        findings_badge = (f"![Findings](https://img.shields.io/badge/findings-"
                         f"{stats['total_findings']}-informational)")
        crit_badge = f"![Critical](https://img.shields.io/badge/critical-{stats['critical']}-red)"
        high_badge = f"![High](https://img.shields.io/badge/high-{stats['high']}-orange)"

        return [
            f"# AeroSecLab Recon Report",
            f"",
            f"## 🎯 `{r.target}`",
            f"",
            f"{grade_badge} {score_badge} {findings_badge} {crit_badge} {high_badge}",
            f"",
            f"| Attribute | Value |",
            f"|---|---|",
            f"| **Target** | `{r.target}` |",
            f"| **Generated** | {now} |",
            f"| **Engine** | AeroSecLab Recon Engine v{r.engine_version} |",
            f"| **Risk Grade** | **{ts.grade}** — {ts.summary} |",
            f"| **Risk Score** | **{ts.score:.1f} / 100** |",
            f"| **Live Hosts** | {stats['live_hosts']} |",
            f"| **Subdomains** | {stats['subdomains_found']} |",
            f"| **Total Findings** | {stats['total_findings']} "
            f"(🔴 {stats['critical']} | 🟠 {stats['high']} | "
            f"🟡 {stats['medium']} | 🔵 {stats['low']}) |",
            f"",
            f"---",
            f"",
        ]

    # ─────────────────────────────────────────────
    # EXECUTIVE SUMMARY
    # ─────────────────────────────────────────────

    def _build_executive_summary(self, ts, r) -> List[str]:
        bullets = executive_summary_bullets(ts, r)
        lines = ["## 📋 Executive Summary", ""]
        for b in bullets:
            lines.append(f"- {b}")
        lines.extend(["", "---", ""])
        return lines

    # ─────────────────────────────────────────────
    # DIFF (vs previous run)
    # ─────────────────────────────────────────────

    def _build_diff_section(self) -> List[str]:
        if not self._diff:
            return []
        d = self._diff
        new_findings    = d.get("new_findings", []) or []
        resolved        = d.get("resolved_findings", []) or []
        new_hosts       = d.get("new_live_hosts", []) or []
        removed_hosts   = d.get("removed_live_hosts", []) or []
        score_delta     = d.get("score_delta", 0) or 0
        grade_change    = d.get("grade_change")
        prev_at         = d.get("previous_generated_at", "previous run")

        # Skip the section entirely if nothing actually changed
        if (not new_findings and not resolved and not new_hosts and
                not removed_hosts and abs(score_delta) < 0.1 and not grade_change):
            return []

        lines = ["## 🔄 Changes Since Previous Run", ""]
        lines.append(f"_Compared against report from `{prev_at}`._")
        lines.append("")

        # Score change
        if score_delta or grade_change:
            arrow = "📈" if score_delta > 0 else ("📉" if score_delta < 0 else "▶️")
            score_line = f"- {arrow} **Risk score change:** `{score_delta:+.1f}` points"
            if grade_change:
                score_line += f" — grade {grade_change[0]} → **{grade_change[1]}**"
            lines.append(score_line)
            lines.append("")

        # Counts table
        lines.extend([
            "| Change Type | Count |",
            "|---|---:|",
            f"| 🆕 New findings | {len(new_findings)} |",
            f"| ✅ Resolved findings | {len(resolved)} |",
            f"| 🆕 New live hosts | {len(new_hosts)} |",
            f"| 🗑️  Removed live hosts | {len(removed_hosts)} |",
            "",
        ])

        # New findings detail (most actionable)
        if new_findings:
            # Sort by severity
            sev_order = {"critical": 0, "high": 1, "medium": 2, "low": 3, "info": 4}
            new_sorted = sorted(new_findings,
                                key=lambda f: sev_order.get(f.get("severity"), 9))
            lines.append(f"### 🆕 New Findings ({len(new_sorted)})")
            lines.append("")
            lines.append("| Severity | Title | URL |")
            lines.append("|---|---|---|")
            for f in new_sorted[:25]:
                emoji = SEVERITY_EMOJI.get(f.get("severity", "info"), "⚪")
                title = self._escape_md(f.get("title", ""))
                url = self._safe_url(f.get("url", ""))
                lines.append(f"| {emoji} `{f.get('severity','').upper()}` | {title} | {url} |")
            if len(new_sorted) > 25:
                lines.append(f"| _... and {len(new_sorted)-25} more in `report_diff.json`_ | | |")
            lines.append("")

        # Resolved findings (positive signal)
        if resolved:
            lines.append(f"### ✅ Resolved Findings ({len(resolved)})")
            lines.append("")
            lines.append("| Severity | Title |")
            lines.append("|---|---|")
            for f in resolved[:15]:
                emoji = SEVERITY_EMOJI.get(f.get("severity", "info"), "⚪")
                title = self._escape_md(f.get("title", ""))
                lines.append(f"| {emoji} `{f.get('severity','').upper()}` | {title} |")
            if len(resolved) > 15:
                lines.append(f"| _... and {len(resolved)-15} more_ | |")
            lines.append("")

        # Hosts deltas
        if new_hosts:
            lines.append(f"### 🆕 New Live Hosts ({len(new_hosts)})")
            lines.append("")
            for url in new_hosts[:20]:
                lines.append(f"- {self._safe_url(url)}")
            lines.append("")

        if removed_hosts:
            lines.append(f"### 🗑️  Removed Live Hosts ({len(removed_hosts)})")
            lines.append("")
            for url in removed_hosts[:20]:
                lines.append(f"- {self._safe_url(url)}")
            lines.append("")

        lines.extend(["---", ""])
        return lines

    # ─────────────────────────────────────────────
    # RISK DASHBOARD
    # ─────────────────────────────────────────────

    def _build_risk_dashboard(self, ts, stats, r) -> List[str]:
        lines = ["## 📊 Risk Dashboard", "",
                 "### Finding Severity Distribution", "",
                 "```mermaid", "pie showData",
                 f'    title {stats["total_findings"]} total findings']

        for sev, count in [("Critical", stats['critical']), ("High", stats['high']),
                           ("Medium",   stats['medium']),   ("Low",  stats['low']),
                           ("Info",     stats['info'])]:
            if count > 0:
                lines.append(f'    "{sev}" : {count}')
        lines.extend(["```", ""])

        # Module contribution
        module_findings: Dict[str, int] = {}
        for attr in vars(r):
            if attr.startswith("module_"):
                mod = getattr(r, attr)
                if mod and mod.findings:
                    module_findings[attr.replace("module_", "")] = len(mod.findings)

        if module_findings:
            lines.extend(["### Findings per Module", "",
                         "| Module | Findings |", "|---|---:|"])
            for mod, count in sorted(module_findings.items(),
                                      key=lambda x: x[1], reverse=True):
                bar = "█" * min(30, count)
                lines.append(f"| `{mod}` | {bar} {count} |")
            lines.append("")

        # Top 5 risk assets
        ranked_assets = sorted(ts.per_asset.values(),
                              key=lambda a: a.raw_score, reverse=True)[:5]
        if ranked_assets and ranked_assets[0].raw_score > 0:
            lines.extend(["### Top 5 Assets by Risk Score", "",
                         "| Rank | Asset | Risk Score | 🔴 | 🟠 | 🟡 | 🔵 | ⚪ |",
                         "|------|-------|-----------:|---:|---:|---:|---:|---:|"])
            for i, a in enumerate(ranked_assets, 1):
                lines.append(
                    f"| {i} | `{a.fqdn}` | **{a.raw_score:.1f}** | "
                    f"{a.critical_count} | {a.high_count} | "
                    f"{a.medium_count} | {a.low_count} | {a.info_count} |"
                )
            lines.append("")

        lines.extend(["---", ""])
        return lines

    # ─────────────────────────────────────────────
    # TOP FINDINGS
    # ─────────────────────────────────────────────

    def _build_top_findings(self, ts) -> List[str]:
        lines = ["## 🔝 Top Findings (by risk score)", ""]
        if not ts.top_findings:
            lines.extend(["_No findings._", ""])
            return lines

        for i, fs in enumerate(ts.top_findings[:10], 1):
            f = fs.finding
            emoji = SEVERITY_EMOJI.get(f.severity, "⚪")
            url = self._safe_url(f.url)
            lines.extend([
                f"### {i}. {emoji} `{f.severity.upper()}` — {self._escape_md(f.title)}",
                f"",
                f"- **Risk score:** `{fs.score}` _(reasons: {', '.join(fs.reasons)})_",
                f"- **Affected URL:** {url}",
                f"- **Module:** `{f.module}`",
            ])
            if f.cve:
                lines.append(f"- **CVE:** `{f.cve}`")
            if f.tags:
                lines.append(f"- **Tags:** {', '.join(f'`{t}`' for t in f.tags[:10])}")
            lines.extend([
                f"- **Evidence:**", f"",
                f"```",
                f"{(f.evidence or '')[:600]}",
                f"```", f"",
                f"- **Remediation:** {f.remediation or '_(see references)_'}", f"",
            ])
        lines.extend(["---", ""])
        return lines

    # ─────────────────────────────────────────────
    # ASSET INVENTORY
    # ─────────────────────────────────────────────

    def _build_asset_inventory(self, ts, r) -> List[str]:
        lines = ["## 🗂️  Asset Inventory", ""]
        if not r.live_hosts:
            lines.extend(["_No live hosts detected._", ""])
            return lines

        sorted_hosts = sorted(
            r.live_hosts,
            key=lambda h: ts.per_asset[h.fqdn].raw_score
                          if h.fqdn in ts.per_asset else 0,
            reverse=True,
        )

        for host in sorted_hosts:
            a = ts.per_asset.get(host.fqdn)
            score_str = f"{a.raw_score:.1f}" if a else "0.0"

            lines.append(f"### `{host.fqdn}` — risk {score_str}")
            lines.append("")

            tech_str = ", ".join(t.name for t in host.tech[:10]) or "_none detected_"
            ports_str = ", ".join(f"{p.port}/{p.protocol}" for p in host.ports[:10]) or "_none_"

            lines.extend([
                f"| Attribute | Value |",
                f"|---|---|",
                f"| **URL** | {self._safe_url(host.url)} |",
                f"| **Status** | `{host.status}` |",
                f"| **Title** | {self._escape_md(host.title)} |",
                f"| **IP** | `{host.ip}` |",
                f"| **Server** | `{self._escape_md(host.server)}` |",
                f"| **CDN** | {host.cdn or '_none_'} |",
                f"| **WAF** | {host.waf or '_none_'} |",
                f"| **Technologies** | {self._escape_md(tech_str)} |",
                f"| **Open Ports** | {ports_str} |",
                f"| **SPA** | {'yes' if host.is_spa else 'no'} |",
            ])

            if a:
                lines.append(f"| **Findings** | 🔴 {a.critical_count} · 🟠 {a.high_count} · "
                            f"🟡 {a.medium_count} · 🔵 {a.low_count} · ⚪ {a.info_count} |")
                if a.notes:
                    notes = "; ".join(self._escape_md(n) for n in a.notes)
                    lines.append(f"| **Scoring notes** | {notes} |")

            if host.cert:
                cert_notes = []
                if host.cert.expired:
                    cert_notes.append("**EXPIRED**")
                if host.cert.self_signed:
                    cert_notes.append("**SELF-SIGNED**")
                cert_status = " · ".join(cert_notes) if cert_notes else "valid"
                lines.append(
                    f"| **TLS Certificate** | "
                    f"Issuer: `{self._escape_md(host.cert.issuer)}` · "
                    f"Valid to: `{host.cert.valid_to}` · {cert_status} |"
                )

            screenshot = host.headers.get("_screenshot_path") if host.headers else None
            if screenshot:
                lines.append(f"| **Screenshot** | `{screenshot}` |")

            lines.append("")

            if a and a.findings:
                top3 = sorted(a.findings, key=lambda fs: fs.score, reverse=True)[:3]
                lines.extend(["**Top findings on this asset:**", ""])
                for fs in top3:
                    emoji = SEVERITY_EMOJI.get(fs.finding.severity, "")
                    lines.append(f"- {emoji} `{fs.finding.severity.upper()}` "
                                f"({fs.score:.1f}) — {self._escape_md(fs.finding.title)}")
                lines.append("")

            lines.extend(["---", ""])

        return lines

    # ─────────────────────────────────────────────
    # FINDINGS BY SEVERITY
    # ─────────────────────────────────────────────

    def _build_findings_by_severity(self, all_f: List[Finding]) -> List[str]:
        lines = ["## 🎛️  All Findings by Severity", ""]

        for sev in ["critical", "high", "medium", "low", "info"]:
            sev_findings = [f for f in all_f if f.severity == sev]
            if not sev_findings:
                continue
            emoji = SEVERITY_EMOJI[sev]

            lines.append("<details>")
            lines.append(f"<summary><strong>{emoji} {sev.upper()} "
                        f"({len(sev_findings)})</strong></summary>")
            lines.append("")

            for i, f in enumerate(sev_findings, 1):
                url = self._safe_url(f.url)
                lines.append(f"**{i}. {self._escape_md(f.title)}**")
                lines.append("")
                lines.append(f"- URL: {url}")
                lines.append(f"- Module: `{f.module}`")
                if f.cve:
                    lines.append(f"- CVE: `{f.cve}`")
                if f.tags:
                    lines.append(f"- Tags: {', '.join(f'`{t}`' for t in f.tags[:8])}")
                lines.append(f"- Evidence:")
                lines.append("")
                lines.append("  ```")
                lines.append(f"  {(f.evidence or '')[:400]}")
                lines.append("  ```")
                if f.remediation:
                    lines.append(f"- Remediation: {self._escape_md(f.remediation)}")
                lines.append("")
            lines.extend(["</details>", ""])

        lines.extend(["---", ""])
        return lines

    # ─────────────────────────────────────────────
    # ATTACK SURFACE
    # ─────────────────────────────────────────────

    def _build_attack_surface(self, r) -> List[str]:
        lines = ["## 🔎 Attack Surface Analysis", ""]

        tech_freq: Dict[str, int] = {}
        for host in r.live_hosts:
            for t in host.tech:
                tech_freq[t.name] = tech_freq.get(t.name, 0) + 1

        if tech_freq:
            lines.extend(["### Technology Distribution", "",
                         "| Technology | Hosts |", "|---|---:|"])
            for tech, count in sorted(tech_freq.items(), key=lambda x: x[1],
                                       reverse=True)[:20]:
                bar = "▓" * min(20, count)
                lines.append(f"| {self._escape_md(tech)} | {bar} {count} |")
            lines.append("")

        port_freq: Dict[int, int] = {}
        for host in r.live_hosts:
            for p in host.ports:
                port_freq[p.port] = port_freq.get(p.port, 0) + 1

        if port_freq:
            lines.extend(["### Open Port Distribution", "",
                         "| Port | Count |", "|---:|---:|"])
            for port, count in sorted(port_freq.items(), key=lambda x: x[1],
                                       reverse=True)[:15]:
                lines.append(f"| `{port}` | {count} |")
            lines.append("")

        lines.extend(["---", ""])
        return lines

    # ─────────────────────────────────────────────
    # JS INTELLIGENCE
    # ─────────────────────────────────────────────

    def _build_js_intelligence(self, r) -> List[str]:
        if not r.js_intel:
            return []
        j = r.js_intel
        lines = ["## 🧠 JavaScript Intelligence", ""]
        lines.append(f"Analyzed **{len(j.files)}** JavaScript files.")
        lines.append("")

        def _block(title, items, limit=20):
            if not items:
                return
            lines.append(f"### {title}")
            lines.append("")
            lines.append("```")
            for item in items[:limit]:
                lines.append(str(item))
            if len(items) > limit:
                lines.append(f"... (+{len(items) - limit} more)")
            lines.append("```")
            lines.append("")

        _block("💸 Financial/Transfer API Paths", j.all_transfer_paths, 40)
        _block("🌐 WebSocket Endpoints", j.all_websockets)
        _block("🔐 Hardcoded Auth Headers", j.all_auth_headers)
        _block("🔑 Extracted API Keys (truncated)", j.all_api_keys)
        _block("🗄️  S3 Buckets Referenced", j.all_s3_buckets)
        _block("🏠 Internal IPs Leaked", j.all_private_ips)
        _block("🔥 Firebase References", j.all_firebase)
        _block("📡 API Base URLs", j.all_api_urls, 30)

        lines.extend(["---", ""])
        return lines

    # ─────────────────────────────────────────────
    # CDN / WAF
    # ─────────────────────────────────────────────

    def _build_cdn_waf(self, r) -> List[str]:
        if not r.live_hosts:
            return []
        cdn_freq: Dict[str, int] = {}
        waf_freq: Dict[str, int] = {}
        for h in r.live_hosts:
            cdn_freq[h.cdn or "none"] = cdn_freq.get(h.cdn or "none", 0) + 1
            waf_freq[h.waf or "none"] = waf_freq.get(h.waf or "none", 0) + 1

        lines = ["## 🛡️  CDN & WAF Coverage", "",
                 "| Layer | Breakdown |", "|---|---|"]
        cdn_str = ", ".join(f"{k} ({v})" for k, v in cdn_freq.items())
        waf_str = ", ".join(f"{k} ({v})" for k, v in waf_freq.items())
        lines.append(f"| **CDN** | {cdn_str} |")
        lines.append(f"| **WAF** | {waf_str} |")
        lines.append("")

        unprotected = [h for h in r.live_hosts if not h.cdn and not h.waf]
        if unprotected:
            lines.append(f"**Unprotected hosts** (no CDN, no WAF): {len(unprotected)}")
            lines.append("")
            for h in unprotected[:10]:
                lines.append(f"- `{h.fqdn}` → {self._safe_url(h.url)}")
            if len(unprotected) > 10:
                lines.append(f"- _... and {len(unprotected) - 10} more_")
            lines.append("")

        lines.extend(["---", ""])
        return lines

    # ─────────────────────────────────────────────
    # SUBDOMAIN TABLE
    # ─────────────────────────────────────────────

    def _build_subdomain_table(self, r) -> List[str]:
        if not r.subdomains:
            return []
        lines = [f"## 🌍 Subdomain Inventory ({len(r.subdomains)})", "",
                 "| FQDN | IPs | Live | Status | CDN | WAF | Source |",
                 "|---|---|:-:|:-:|---|---|---|"]
        for s in sorted(r.subdomains, key=lambda x: x.fqdn)[:200]:
            ips = ", ".join(s.ips[:2])
            live = "✅" if s.live_host else "—"
            status = str(s.live_host.status) if s.live_host else ""
            cdn = (s.live_host.cdn if s.live_host else "") or "—"
            waf = (s.live_host.waf if s.live_host else "") or "—"
            lines.append(
                f"| `{s.fqdn}` | {ips} | {live} | {status} | "
                f"{cdn} | {waf} | {s.source} |"
            )
        if len(r.subdomains) > 200:
            lines.append(f"| _... and {len(r.subdomains) - 200} more in JSON report_ | | | | | | |")
        lines.extend(["", "---", ""])
        return lines

    # ─────────────────────────────────────────────
    # ORG INFO
    # ─────────────────────────────────────────────

    def _build_org_info(self, r) -> List[str]:
        lines = []

        if r.whois:
            w = r.whois
            lines.extend([
                "## 🏢 Organization Intelligence", "",
                "### WHOIS", "",
                "| Field | Value |", "|---|---|",
                f"| **Registrar** | {self._escape_md(w.registrar)} |",
                f"| **Registered** | {w.registered} |",
                f"| **Expires** | {w.expires} |",
                f"| **Registrant Org** | {self._escape_md(w.registrant_org)} |",
                f"| **Country** | {w.registrant_country} |",
                f"| **Name Servers** | {', '.join(f'`{ns}`' for ns in w.name_servers[:5])} |",
                f"| **Emails** | {', '.join(w.emails[:5])} |",
                "",
            ])

        if r.asn:
            a = r.asn
            lines.extend([
                "### ASN / Network", "",
                "| Field | Value |", "|---|---|",
                f"| **ASN** | `{a.asn}` |",
                f"| **Org** | {self._escape_md(a.org)} |",
                f"| **Country** | {a.country} |",
                f"| **IPv4 Prefixes** | {', '.join(f'`{p}`' for p in a.prefixes_v4[:10])} |",
                "",
            ])

        if r.dns_records:
            lines.extend(["### DNS Records (apex)", "", "```"])
            for rec in r.dns_records[:30]:
                lines.append(f"{rec.type:8} {rec.value}")
            lines.extend(["```", ""])

        if lines:
            lines.extend(["---", ""])
        return lines

    # ─────────────────────────────────────────────
    # METHODOLOGY
    # ─────────────────────────────────────────────

    def _build_methodology(self, r) -> List[str]:
        lines = [
            "## 🧭 Methodology", "",
            "This report was generated by the AeroSecLab Recon Engine, which executes "
            "a staged pipeline across three phases:", "",
            "**Passive** — Gathers organizational, DNS, and certificate-transparency "
            "intelligence without touching the target's infrastructure. Sources include "
            "`crt.sh`, certificate transparency logs, passive DNS providers, WHOIS, "
            "and ASN databases.", "",
            "**Active** — Probes discovered assets with controlled HTTP/TCP traffic to "
            "identify live services, technology stacks, open ports, CDN/WAF protections, "
            "and known vulnerabilities via nuclei community templates. Includes "
            "subdomain-takeover detection against a curated fingerprint database.", "",
            "**Analysis** — Crawls live sites, mines JavaScript bundles for secrets and "
            "endpoint inventory, extracts GraphQL schemas and OpenAPI specs where "
            "disclosed, detects exposed version control artifacts, computes favicon "
            "hash fingerprints, and enumerates cloud bucket namespaces.", "",
            "**Scope adherence:** All modules are detection-only. No exploitation, no "
            "credential brute-force, no data exfiltration, no destructive tests.", "",
            "### Modules Executed", "",
            "| Module | Status | Duration | Findings |", "|---|---|---:|---:|",
        ]
        for attr in sorted(vars(r).keys()):
            if not attr.startswith("module_"):
                continue
            mod = getattr(r, attr)
            if not mod:
                continue
            icon = "✅" if mod.status == "ok" else ("❌" if mod.status == "error" else "⚠️")
            lines.append(
                f"| `{attr.replace('module_','')}` | {icon} {mod.status} | "
                f"{mod.duration_sec:.1f}s | {len(mod.findings)} |"
            )
        lines.extend(["", "---", ""])
        return lines

    # ─────────────────────────────────────────────
    # APPENDIX
    # ─────────────────────────────────────────────

    def _build_appendix(self, r) -> List[str]:
        lines = [
            "## 📎 Appendix", "",
            "### Raw Counts", "",
            f"- Subdomains discovered: **{len(r.subdomains)}**",
            f"- Live web hosts: **{len(r.live_hosts)}**",
            f"- DNS records: **{len(r.dns_records)}**",
            f"- Parameters catalogued: **{len(r.parameters)}**",
            f"- URLs crawled: **{len(r.crawled_links)}**",
            f"- JS files analyzed: **{len(r.js_intel.files) if r.js_intel else 0}**",
            "",
            "### Data Files", "",
            "All raw tool outputs are preserved in the scan output directory:", "",
            "- `report.json` — structured machine-readable results",
            "- `screenshots/` — visual evidence per live host (if captured)",
            "- `crawl/` — tool outputs from katana, gau, waybackurls, hakrawler",
            "- `js_intel/` — categorized JS mining results",
            "- `wafw00f/`, `nuclei.jsonl`, `httpx.json`, `masscan.json` — per-tool raw output",
            "- `graphql/`, `swagger/` — extracted schemas and specs",
            "",
            "---", "",
            f"*Report generated {datetime.utcnow().strftime('%Y-%m-%d %H:%M UTC')} "
            f"by AeroSecLab Recon Engine v{r.engine_version}*", "",
        ]
        return lines

    # ─────────────────────────────────────────────
    # HELPERS
    # ─────────────────────────────────────────────

    def _escape_md(self, text: Optional[str]) -> str:
        if not text:
            return ""
        text = str(text)
        text = text.replace("|", "\\|").replace("\n", " ").replace("\r", " ")
        return text[:200]

    def _safe_url(self, url: Optional[str]) -> str:
        if not url:
            return "_(n/a)_"
        u = str(url).replace("|", "%7C").replace("`", "'")
        return f"`{u}`"
