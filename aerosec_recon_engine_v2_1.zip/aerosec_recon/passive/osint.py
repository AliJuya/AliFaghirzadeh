"""
AeroSecLab Recon Engine — Passive: OSINT
Sources: HackerTarget, Shodan, SecurityTrails, VirusTotal,
         ThreatCrowd, BufferOver, Riddler, CommonCrawl
"""

from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Dict, List, Set

import requests

from ..core.models import ModuleReport, ReconReport, Subdomain, Finding
from ..core.config import (
    SHODAN_API_KEY, SECURITYTRAILS_KEY, VIRUSTOTAL_KEY,
    REQUEST_TIMEOUT,
)
from ..core.logger import log


MODULE_NAME = "osint"

UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"


def run(
    target     : str,
    report     : ReconReport,
    mod_report : ModuleReport,
    output_dir : Path,
):
    log("INFO", target, "OSINT — starting")
    found: Dict[str, Set[str]] = {}  # source -> set of subdomains

    # ── Free sources (no key needed) ─────────────────────────────────
    found["hackertarget"] = _hackertarget(target)
    log("OK", target, f"  HackerTarget → {len(found['hackertarget'])}")

    found["virustotal_free"] = _virustotal_free(target)
    log("OK", target, f"  VirusTotal (free) → {len(found['virustotal_free'])}")

    found["threatcrowd"] = _threatcrowd(target)
    log("OK", target, f"  ThreatCrowd → {len(found['threatcrowd'])}")

    found["bufferover"] = _bufferover(target)
    log("OK", target, f"  BufferOver → {len(found['bufferover'])}")

    found["riddler"] = _riddler(target)
    log("OK", target, f"  Riddler → {len(found['riddler'])}")

    found["commoncrawl"] = _commoncrawl(target)
    log("OK", target, f"  CommonCrawl → {len(found['commoncrawl'])}")

    found["urlscan"] = _urlscan(target)
    log("OK", target, f"  URLScan.io → {len(found['urlscan'])}")

    found["dnsdumpster"] = _dnsdumpster(target)
    log("OK", target, f"  DNSDumpster → {len(found['dnsdumpster'])}")

    found["wayback"] = _wayback_subdomains(target)
    log("OK", target, f"  WaybackMachine → {len(found['wayback'])}")

    # ── Sources requiring API keys ─────────────────────────────────
    if SHODAN_API_KEY:
        found["shodan"] = _shodan(target)
        log("OK", target, f"  Shodan → {len(found['shodan'])}")

    if SECURITYTRAILS_KEY:
        found["securitytrails"] = _securitytrails(target)
        log("OK", target, f"  SecurityTrails → {len(found['securitytrails'])}")

    if VIRUSTOTAL_KEY:
        found["virustotal"] = _virustotal_api(target)
        log("OK", target, f"  VirusTotal (API) → {len(found['virustotal'])}")

    # ── Aggregate and merge ───────────────────────────────────────────
    all_found: Set[str] = set()
    for source_subs in found.values():
        all_found |= source_subs

    existing_fqdns = {s.fqdn for s in report.subdomains}
    new_count = 0
    for fqdn in sorted(all_found):
        if fqdn not in existing_fqdns:
            report.subdomains.append(Subdomain(fqdn=fqdn, source=MODULE_NAME))
            existing_fqdns.add(fqdn)
            new_count += 1

    # ── Also check Shodan for exposed services/ports ──────────────────
    shodan_hosts = []
    if SHODAN_API_KEY:
        shodan_hosts = _shodan_host_search(target)
        for host_data in shodan_hosts:
            ip   = host_data.get("ip_str", "")
            org  = host_data.get("org", "")
            ports= host_data.get("ports", [])
            if ip:
                log("WARN", target, f"  Shodan host: {ip} ({org}) ports: {ports}")

    # ── Summary ───────────────────────────────────────────────────────
    source_counts = {src: len(subs) for src, subs in found.items()}
    mod_report.summary = {
        "total_unique"  : len(all_found),
        "new_subdomains": new_count,
        "sources"       : source_counts,
    }
    mod_report.data = {
        "subdomains_by_source": {src: sorted(subs) for src, subs in found.items()},
        "all_subdomains"      : sorted(all_found),
        "shodan_hosts"        : shodan_hosts,
    }

    out_file = output_dir / f"{MODULE_NAME}_raw.txt"
    out_file.write_text("\n".join(sorted(all_found)))
    log("OK", target, f"  OSINT complete: {len(all_found)} unique ({new_count} new)")


# ─────────────────────────────────────────────
# SOURCES
# ─────────────────────────────────────────────

def _clean(name: str, target: str) -> str:
    name = name.strip().lower().lstrip("*.")
    if name.endswith(f".{target}") or name == target:
        # Basic sanity — no spaces, no special chars except dot/hyphen
        if re.match(r'^[a-z0-9._-]+$', name):
            return name
    return ""


def _hackertarget(target: str) -> Set[str]:
    subs = set()
    try:
        r = requests.get(
            f"https://api.hackertarget.com/hostsearch/?q={target}",
            timeout=20, headers={"User-Agent": UA}
        )
        if r.ok and "API count exceeded" not in r.text:
            for line in r.text.splitlines():
                parts = line.split(",")
                if parts:
                    c = _clean(parts[0], target)
                    if c:
                        subs.add(c)
    except Exception:
        pass
    return subs


def _virustotal_free(target: str) -> Set[str]:
    subs = set()
    try:
        r = requests.get(
            f"https://www.virustotal.com/ui/domains/{target}/subdomains?limit=40",
            timeout=20,
            headers={"User-Agent": UA, "Accept": "application/json"}
        )
        if r.ok:
            data = r.json()
            for entry in data.get("data", []):
                fqdn = entry.get("id", "")
                c    = _clean(fqdn, target)
                if c:
                    subs.add(c)
    except Exception:
        pass
    return subs


def _virustotal_api(target: str) -> Set[str]:
    subs   = set()
    cursor = None
    for _ in range(10):  # Max 10 pages
        try:
            url    = f"https://www.virustotal.com/api/v3/domains/{target}/subdomains?limit=40"
            params = {}
            if cursor:
                params["cursor"] = cursor
            r = requests.get(url, params=params, timeout=20,
                             headers={"x-apikey": VIRUSTOTAL_KEY, "User-Agent": UA})
            if not r.ok:
                break
            data = r.json()
            for entry in data.get("data", []):
                c = _clean(entry.get("id", ""), target)
                if c:
                    subs.add(c)
            cursor = data.get("meta", {}).get("cursor")
            if not cursor:
                break
        except Exception:
            break
    return subs


def _threatcrowd(target: str) -> Set[str]:
    subs = set()
    try:
        r = requests.get(
            f"https://www.threatcrowd.org/searchApi/v2/domain/report/?domain={target}",
            timeout=20, headers={"User-Agent": UA}
        )
        if r.ok:
            for sub in r.json().get("subdomains", []):
                c = _clean(sub, target)
                if c:
                    subs.add(c)
    except Exception:
        pass
    return subs


def _bufferover(target: str) -> Set[str]:
    subs = set()
    try:
        r = requests.get(
            f"https://dns.bufferover.run/dns?q=.{target}",
            timeout=20, headers={"User-Agent": UA}
        )
        if r.ok:
            data = r.json()
            for record in data.get("FDNS_A", []) + data.get("RDNS", []):
                parts = record.split(",")
                for p in parts:
                    c = _clean(p.strip(), target)
                    if c:
                        subs.add(c)
    except Exception:
        pass
    return subs


def _riddler(target: str) -> Set[str]:
    subs = set()
    try:
        r = requests.get(
            f"https://riddler.io/search/exportcsv?q=pld:{target}",
            timeout=20, headers={"User-Agent": UA}
        )
        if r.ok:
            for line in r.text.splitlines()[1:]:
                parts = line.split(",")
                if len(parts) >= 5:
                    c = _clean(parts[4], target)
                    if c:
                        subs.add(c)
    except Exception:
        pass
    return subs


def _commoncrawl(target: str) -> Set[str]:
    subs = set()
    try:
        # Get latest index
        idx_r = requests.get(
            "https://index.commoncrawl.org/collinfo.json",
            timeout=15, headers={"User-Agent": UA}
        )
        if not idx_r.ok:
            return subs
        indexes = idx_r.json()
        latest  = indexes[0]["id"] if indexes else "CC-MAIN-2024-10"

        r = requests.get(
            f"https://index.commoncrawl.org/{latest}-index",
            params={"url": f"*.{target}", "output": "json", "limit": "500"},
            timeout=30, headers={"User-Agent": UA}
        )
        if r.ok:
            for line in r.text.splitlines():
                try:
                    entry = json.loads(line)
                    url   = entry.get("url", "")
                    from urllib.parse import urlparse
                    parsed = urlparse(url)
                    c = _clean(parsed.netloc, target)
                    if c:
                        subs.add(c)
                except Exception:
                    pass
    except Exception:
        pass
    return subs


def _urlscan(target: str) -> Set[str]:
    subs   = set()
    cursor = ""
    for _ in range(5):
        try:
            url    = f"https://urlscan.io/api/v1/search/?q=domain:{target}&size=100"
            if cursor:
                url += f"&search_after={cursor}"
            r = requests.get(url, timeout=20, headers={"User-Agent": UA})
            if not r.ok:
                break
            data = r.json()
            for result in data.get("results", []):
                page_domain = result.get("page", {}).get("domain", "")
                c = _clean(page_domain, target)
                if c:
                    subs.add(c)
            if not data.get("has_more"):
                break
            # Get next cursor from last result
            results = data.get("results", [])
            if results:
                cursor = results[-1].get("sort", [""])[0]
        except Exception:
            break
    return subs


def _dnsdumpster(target: str) -> Set[str]:
    """Scrape DNSDumpster for subdomains (no API key needed)."""
    subs = set()
    try:
        session = requests.Session()
        session.headers["User-Agent"] = UA
        # Get CSRF token
        r = session.get("https://dnsdumpster.com/", timeout=15)
        if not r.ok:
            return subs
        csrf = re.search(r'csrfmiddlewaretoken.*?value="([^"]+)"', r.text)
        if not csrf:
            return subs
        csrf_token = csrf.group(1)
        # POST the form
        r2 = session.post(
            "https://dnsdumpster.com/",
            data={
                "csrfmiddlewaretoken": csrf_token,
                "targetip": target,
                "user": "free",
            },
            headers={"Referer": "https://dnsdumpster.com/"},
            timeout=30,
        )
        if r2.ok:
            # Extract subdomains from response
            for match in re.findall(
                r'([a-zA-Z0-9._-]+\.' + re.escape(target) + r')',
                r2.text
            ):
                c = _clean(match, target)
                if c:
                    subs.add(c)
    except Exception:
        pass
    return subs


def _wayback_subdomains(target: str) -> Set[str]:
    """Query Wayback Machine CDX API for subdomains."""
    subs = set()
    try:
        r = requests.get(
            "http://web.archive.org/cdx/search/cdx",
            params={
                "url"       : f"*.{target}",
                "output"    : "text",
                "fl"        : "original",
                "collapse"  : "urlkey",
                "limit"     : "10000",
            },
            timeout=30, headers={"User-Agent": UA}
        )
        if r.ok:
            from urllib.parse import urlparse
            for line in r.text.splitlines():
                parsed = urlparse(line.strip())
                c = _clean(parsed.netloc, target)
                if c:
                    subs.add(c)
    except Exception:
        pass
    return subs


def _shodan(target: str) -> Set[str]:
    """Query Shodan for subdomains (requires API key)."""
    subs = set()
    if not SHODAN_API_KEY:
        return subs
    try:
        r = requests.get(
            f"https://api.shodan.io/dns/domain/{target}",
            params={"key": SHODAN_API_KEY},
            timeout=20, headers={"User-Agent": UA}
        )
        if r.ok:
            data = r.json()
            for sub in data.get("subdomains", []):
                fqdn = f"{sub}.{target}"
                c    = _clean(fqdn, target)
                if c:
                    subs.add(c)
    except Exception:
        pass
    return subs


def _shodan_host_search(target: str) -> List[Dict]:
    """Search Shodan for hosts related to the target org."""
    hosts = []
    if not SHODAN_API_KEY:
        return hosts
    try:
        r = requests.get(
            "https://api.shodan.io/shodan/host/search",
            params={"key": SHODAN_API_KEY, "query": f"hostname:{target}", "page": 1},
            timeout=20, headers={"User-Agent": UA}
        )
        if r.ok:
            data = r.json()
            for match in data.get("matches", []):
                hosts.append({
                    "ip_str"  : match.get("ip_str", ""),
                    "org"     : match.get("org", ""),
                    "isp"     : match.get("isp", ""),
                    "country" : match.get("location", {}).get("country_name", ""),
                    "ports"   : [match.get("port", 0)],
                    "hostnames": match.get("hostnames", []),
                    "vulns"   : list(match.get("vulns", {}).keys()),
                })
    except Exception:
        pass
    return hosts


def _securitytrails(target: str) -> Set[str]:
    """Query SecurityTrails for subdomains (requires API key)."""
    subs = set()
    if not SECURITYTRAILS_KEY:
        return subs
    try:
        r = requests.get(
            f"https://api.securitytrails.com/v1/domain/{target}/subdomains",
            params={"children_only": "false", "include_inactive": "true"},
            headers={"APIKEY": SECURITYTRAILS_KEY, "User-Agent": UA},
            timeout=20,
        )
        if r.ok:
            data = r.json()
            for sub in data.get("subdomains", []):
                fqdn = f"{sub}.{target}"
                c    = _clean(fqdn, target)
                if c:
                    subs.add(c)
    except Exception:
        pass
    return subs
