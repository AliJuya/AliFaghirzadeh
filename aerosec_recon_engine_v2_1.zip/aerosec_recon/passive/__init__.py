"""Passive recon modules"""
