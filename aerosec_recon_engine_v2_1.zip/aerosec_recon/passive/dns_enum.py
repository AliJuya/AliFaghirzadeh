"""
AeroSecLab Recon Engine — Passive: DNS Enumeration
Tools: dig, dnsx, dnsrecon, massdns
Fetches all DNS records and resolves discovered subdomains.
"""

from __future__ import annotations

import json
import re
import socket
import tempfile
from pathlib import Path
from typing import Dict, List, Optional, Set, Tuple

from ..core.models import (
    ModuleReport, ReconReport, Subdomain, DNSRecord, Finding
)
from ..core.config import (
    get_tool, TOOL_TIMEOUT, DNS_TIMEOUT, EXCHANGE_SUBDOMAINS
)
from ..core.logger import log, progress
from ..core.http_utils import run_tool


MODULE_NAME = "dns_enum"

# DNS record types to query
RECORD_TYPES = ["A", "AAAA", "CNAME", "MX", "NS", "TXT", "SOA", "SRV"]

# Common DNS resolvers for massdns
PUBLIC_RESOLVERS = [
    "1.1.1.1", "1.0.0.1",           # Cloudflare
    "8.8.8.8", "8.8.4.4",           # Google
    "9.9.9.9", "149.112.112.112",   # Quad9
    "208.67.222.222", "208.67.220.220",  # OpenDNS
    "64.6.64.6", "64.6.65.6",       # Verisign
]


def run(
    target     : str,
    report     : ReconReport,
    mod_report : ModuleReport,
    output_dir : Path,
):
    log("INFO", target, "DNS Enumeration — starting")

    # ── 1. Fetch all DNS records for apex domain ──────────────────────
    dns_records = _fetch_all_records(target)
    report.dns_records = dns_records
    log("OK", target, f"  DNS records: {len(dns_records)} records fetched")

    # ── 2. Extract IPs from A records ────────────────────────────────
    a_records  = [r.value for r in dns_records if r.type == "A"]
    ns_records = [r.value for r in dns_records if r.type == "NS"]
    mx_records = [r.value for r in dns_records if r.type == "MX"]
    txt_records= [r.value for r in dns_records if r.type == "TXT"]

    log("OK", target, f"  A: {a_records}")
    log("OK", target, f"  NS: {ns_records}")

    # ── 3. Check for wildcard DNS ─────────────────────────────────────
    is_wildcard = _check_wildcard(target)
    if is_wildcard:
        log("WARN", target, "  Wildcard DNS detected — brute force results unreliable")
        mod_report.findings.append(Finding(
            severity    = "info",
            title       = "Wildcard DNS configured",
            url         = target,
            evidence    = f"*.{target} resolves to a valid IP",
            module      = MODULE_NAME,
            remediation = "Disable wildcard DNS to improve security posture",
        ))

    # ── 4. Resolve all known subdomains via dnsx ─────────────────────
    all_fqdns = list({s.fqdn for s in report.subdomains})
    if all_fqdns:
        resolved = _resolve_with_dnsx(all_fqdns, target, output_dir)
        # Update subdomains with resolved IPs
        resolved_map = {fqdn: ips for fqdn, ips in resolved.items()}
        for sub in report.subdomains:
            if sub.fqdn in resolved_map:
                sub.ips = resolved_map[sub.fqdn]
        log("OK", target, f"  Resolved {len(resolved)} subdomains")

    # ── 5. Zone transfer attempt ──────────────────────────────────────
    for ns in ns_records[:3]:
        ns_clean = ns.rstrip(".")
        zt_result = _attempt_zone_transfer(target, ns_clean)
        if zt_result:
            log("CRIT", target, f"  ZONE TRANSFER SUCCESSFUL via {ns_clean}!")
            mod_report.findings.append(Finding(
                severity    = "critical",
                title       = "DNS Zone Transfer Allowed",
                url         = f"dns://{ns_clean}",
                evidence    = zt_result[:500],
                module      = MODULE_NAME,
                cve         = "",
                remediation = "Restrict AXFR to authorized IPs only in DNS server config",
                tags        = ["dns", "zone-transfer", "information-disclosure"],
            ))
            # Parse zone transfer for additional subdomains
            zt_subs = _parse_zone_transfer(zt_result, target)
            existing = {s.fqdn for s in report.subdomains}
            for fqdn in zt_subs:
                if fqdn not in existing:
                    report.subdomains.append(Subdomain(
                        fqdn=fqdn, source="zone_transfer"
                    ))

    # ── 6. DNS security checks ────────────────────────────────────────
    _check_dns_security(target, txt_records, ns_records, mod_report)

    # ── 7. Reverse DNS on discovered IPs ─────────────────────────────
    all_ips = set(a_records)
    for sub in report.subdomains:
        all_ips.update(sub.ips)

    rdns_map = _reverse_dns(list(all_ips)[:50])
    if rdns_map:
        log("OK", target, f"  Reverse DNS: {len(rdns_map)} PTR records")

    # ── 8. dnsrecon ──────────────────────────────────────────────────
    if get_tool("dnsrecon"):
        dr_subs = _run_dnsrecon(target, output_dir)
        existing = {s.fqdn for s in report.subdomains}
        new_count = 0
        for fqdn in dr_subs:
            if fqdn not in existing:
                report.subdomains.append(Subdomain(fqdn=fqdn, source="dnsrecon"))
                existing.add(fqdn)
                new_count += 1
        log("OK", target, f"  dnsrecon: {new_count} new subdomains")

    # ── Summary ───────────────────────────────────────────────────────
    mod_report.summary = {
        "dns_records"      : len(dns_records),
        "a_records"        : a_records,
        "ns_records"       : ns_records,
        "mx_records"       : mx_records,
        "wildcard_detected": is_wildcard,
        "zone_transfer"    : any(
            f.title == "DNS Zone Transfer Allowed" for f in mod_report.findings
        ),
        "subdomains_resolved": len([s for s in report.subdomains if s.ips]),
    }
    mod_report.data = {
        "dns_records": [{"type": r.type, "value": r.value, "ttl": r.ttl}
                        for r in dns_records],
        "reverse_dns": rdns_map,
        "txt_records": txt_records,
    }
    log("OK", target, f"  DNS enumeration complete")


# ─────────────────────────────────────────────
# DNS RECORD FETCHING
# ─────────────────────────────────────────────

def _fetch_all_records(target: str) -> List[DNSRecord]:
    """Fetch all DNS record types for the target domain."""
    records = []
    dig     = get_tool("dig")
    if not dig:
        return _fallback_dns_resolve(target)

    for rtype in RECORD_TYPES:
        stdout, _, rc = run_tool(
            [dig, "+short", "+time=5", "+tries=2", rtype, target],
            timeout=15
        )
        if stdout:
            for line in stdout.splitlines():
                line = line.strip()
                if line and not line.startswith(";"):
                    # Parse TTL from full output if needed
                    records.append(DNSRecord(type=rtype, value=line))

    return records


def _fallback_dns_resolve(target: str) -> List[DNSRecord]:
    """Fallback DNS resolution using socket if dig is unavailable."""
    records = []
    try:
        ips = socket.getaddrinfo(target, None)
        for ip in ips:
            rtype = "A" if ip[0] == socket.AF_INET else "AAAA"
            records.append(DNSRecord(type=rtype, value=ip[4][0]))
    except Exception:
        pass
    return records


# ─────────────────────────────────────────────
# WILDCARD DETECTION
# ─────────────────────────────────────────────

def _check_wildcard(target: str) -> bool:
    """Check if wildcard DNS is configured."""
    import random, string
    random_sub = "".join(random.choices(string.ascii_lowercase, k=12))
    fqdn       = f"{random_sub}.{target}"
    try:
        socket.gethostbyname(fqdn)
        return True
    except socket.gaierror:
        return False


# ─────────────────────────────────────────────
# SUBDOMAIN RESOLUTION WITH DNSX
# ─────────────────────────────────────────────

def _resolve_with_dnsx(
    fqdns     : List[str],
    target    : str,
    output_dir: Path,
) -> Dict[str, List[str]]:
    """Resolve a list of FQDNs using dnsx."""
    resolved = {}
    dnsx     = get_tool("dnsx")
    if not dnsx:
        return _resolve_with_socket(fqdns)

    # Write FQDNs to temp file
    with tempfile.NamedTemporaryFile(mode="w", suffix=".txt", delete=False) as f:
        f.write("\n".join(fqdns))
        tmp_path = f.name

    out_file = str(output_dir / "dnsx_resolved.json")

    stdout, stderr, rc = run_tool(
        [
            dnsx,
            "-l", tmp_path,
            "-a", "-aaaa", "-cname",
            "-resp",
            "-json",
            "-o", out_file,
            "-t", "100",           # 100 concurrent
            "-retry", "2",
            "-timeout", str(DNS_TIMEOUT),
            "-silent",
        ],
        timeout=TOOL_TIMEOUT,
        target=target,
    )

    # Parse output
    out_path = Path(out_file)
    if out_path.exists():
        for line in out_path.read_text().splitlines():
            try:
                entry = json.loads(line)
                host  = entry.get("host", "")
                ips   = entry.get("a", []) + entry.get("aaaa", [])
                if host and ips:
                    resolved[host] = ips
            except Exception:
                pass

    import os
    try:
        os.unlink(tmp_path)
    except Exception:
        pass

    return resolved


def _resolve_with_socket(fqdns: List[str]) -> Dict[str, List[str]]:
    """Fallback: resolve using Python socket."""
    resolved = {}
    for fqdn in fqdns:
        try:
            ips = list({ai[4][0] for ai in socket.getaddrinfo(fqdn, None)})
            if ips:
                resolved[fqdn] = ips
        except Exception:
            pass
    return resolved


# ─────────────────────────────────────────────
# ZONE TRANSFER
# ─────────────────────────────────────────────

def _attempt_zone_transfer(domain: str, nameserver: str) -> str:
    """Attempt DNS zone transfer (AXFR) against a nameserver."""
    dig = get_tool("dig")
    if not dig:
        return ""
    stdout, _, rc = run_tool(
        [dig, "AXFR", domain, f"@{nameserver}", "+time=10"],
        timeout=20,
        target=domain,
    )
    # Zone transfer succeeded if we get actual records back
    if stdout and rc == 0 and "Transfer failed" not in stdout:
        # Check for actual DNS records (not just error messages)
        record_lines = [l for l in stdout.splitlines()
                       if l.strip() and not l.startswith(";") and "\t" in l]
        if len(record_lines) > 2:
            return stdout
    return ""


def _parse_zone_transfer(zt_output: str, target: str) -> List[str]:
    """Extract subdomains from zone transfer output."""
    subs = set()
    for line in zt_output.splitlines():
        line = line.strip()
        if not line or line.startswith(";"):
            continue
        parts = line.split()
        if len(parts) >= 4:
            fqdn = parts[0].rstrip(".").lower()
            if fqdn.endswith(f".{target}") or fqdn == target:
                subs.add(fqdn)
    return list(subs)


# ─────────────────────────────────────────────
# REVERSE DNS
# ─────────────────────────────────────────────

def _reverse_dns(ips: List[str]) -> Dict[str, str]:
    """Perform reverse DNS lookup on a list of IPs."""
    results = {}
    for ip in ips:
        try:
            hostname = socket.gethostbyaddr(ip)[0]
            results[ip] = hostname
        except Exception:
            pass
    return results


# ─────────────────────────────────────────────
# DNS SECURITY CHECKS
# ─────────────────────────────────────────────

def _check_dns_security(
    target    : str,
    txt_records: List[str],
    ns_records : List[str],
    mod_report: ModuleReport,
):
    """Check for DNS security misconfigurations."""
    txt_combined = " ".join(txt_records).lower()

    # SPF check
    has_spf = "v=spf1" in txt_combined
    if not has_spf:
        mod_report.findings.append(Finding(
            severity    = "medium",
            title       = "Missing SPF record",
            url         = target,
            evidence    = "No SPF TXT record found",
            module      = MODULE_NAME,
            remediation = "Add SPF record to prevent email spoofing",
            tags        = ["dns", "email-security", "spf"],
        ))

    # DMARC check
    dmarc = _fetch_txt_record(f"_dmarc.{target}")
    if not dmarc or "v=dmarc1" not in dmarc.lower():
        mod_report.findings.append(Finding(
            severity    = "medium",
            title       = "Missing DMARC record",
            url         = target,
            evidence    = "No DMARC policy found at _dmarc." + target,
            module      = MODULE_NAME,
            remediation = "Add DMARC record: v=DMARC1; p=reject; rua=mailto:...",
            tags        = ["dns", "email-security", "dmarc"],
        ))
    elif "p=none" in dmarc.lower():
        mod_report.findings.append(Finding(
            severity    = "low",
            title       = "DMARC policy set to none (monitoring only)",
            url         = target,
            evidence    = dmarc[:200],
            module      = MODULE_NAME,
            remediation = "Change DMARC policy to p=quarantine or p=reject",
            tags        = ["dns", "email-security", "dmarc"],
        ))

    # DNSSEC check
    ds_record = _fetch_txt_record(target, rtype="DS")
    if not ds_record:
        mod_report.findings.append(Finding(
            severity    = "low",
            title       = "DNSSEC not configured",
            url         = target,
            evidence    = "No DS record found",
            module      = MODULE_NAME,
            remediation = "Enable DNSSEC to prevent DNS spoofing attacks",
            tags        = ["dns", "dnssec"],
        ))

    # Check for dangling/misconfigured NS
    if len(ns_records) < 2:
        mod_report.findings.append(Finding(
            severity    = "low",
            title       = "Single nameserver configured",
            url         = target,
            evidence    = f"NS: {ns_records}",
            module      = MODULE_NAME,
            remediation = "Configure at least 2 nameservers for redundancy",
            tags        = ["dns", "availability"],
        ))

    # Check for subdomain takeover candidates via CNAME
    _check_cname_takeover(target, mod_report)


def _fetch_txt_record(domain: str, rtype: str = "TXT") -> str:
    dig = get_tool("dig")
    if not dig:
        return ""
    stdout, _, _ = run_tool(
        [dig, "+short", rtype, domain, "+time=5"],
        timeout=10,
    )
    return stdout.strip()


# ─────────────────────────────────────────────
# CNAME TAKEOVER DETECTION
# ─────────────────────────────────────────────

# Known vulnerable CNAME targets for subdomain takeover
TAKEOVER_FINGERPRINTS = {
    "amazonaws.com"          : "NoSuchBucket",
    "azurewebsites.net"      : "404 Web Site not found",
    "cloudapp.net"           : "404 Not Found",
    "github.io"              : "There isn't a GitHub Pages site here",
    "heroku.com"             : "No such app",
    "herokudns.com"          : "No such app",
    "wordpress.com"          : "Do you want to register",
    "pantheonsite.io"        : "The gods are wise",
    "shopify.com"            : "Sorry, this shop is currently unavailable",
    "fastly.net"             : "Fastly error: unknown domain",
    "ghost.io"               : "The thing you were looking for is no longer here",
    "surge.sh"               : "project not found",
    "readme.io"              : "Project doesnt exist",
    "statuspage.io"          : "Better luck next time",
    "uservoice.com"          : "This UserVoice subdomain is currently available",
    "zendesk.com"            : "Help Center Closed",
    "bitbucket.org"          : "Repository not found",
    "smartjob.io"            : "Job Board Is Unavailable",
    "unbounce.com"           : "The requested URL was not found",
    "tumblr.com"             : "Whatever you were looking for doesn't currently exist",
    "bigcartel.com"          : "Oops! We could not find your store",
    "desk.com"               : "Sorry, We Couldn't Find That Page",
    "feedpress.me"           : "The feed has not been found",
    "freshdesk.com"          : "There is no helpdesk here",
    "pingdom.com"            : "Sorry, couldn't find the status page",
    "tave.com"               : "Sorry, this page is not available",
    "teamwork.com"           : "Oops - We didn't find your site",
}


def _check_cname_takeover(target: str, mod_report: ModuleReport):
    """Check for subdomain takeover via dangling CNAME records."""
    import requests as req
    for sub in [f"www.{target}", f"dev.{target}", f"staging.{target}",
                f"beta.{target}", f"api.{target}"]:
        cname = _fetch_txt_record(sub, rtype="CNAME").strip().rstrip(".")
        if not cname:
            continue
        # Check if CNAME points to a known vulnerable service
        for service, fingerprint in TAKEOVER_FINGERPRINTS.items():
            if service in cname:
                try:
                    r = req.get(f"https://{sub}", timeout=8, verify=False,
                                headers={"User-Agent": "AeroSecLab/1.0"})
                    if fingerprint.lower() in r.text.lower():
                        mod_report.findings.append(Finding(
                            severity    = "critical",
                            title       = f"Subdomain Takeover Possible: {sub}",
                            url         = f"https://{sub}",
                            evidence    = f"CNAME → {cname} ({service}). Fingerprint: '{fingerprint}' found in response",
                            module      = MODULE_NAME,
                            remediation = f"Remove dangling CNAME record for {sub} or re-register the service",
                            tags        = ["subdomain-takeover", "cname", "critical"],
                        ))
                except Exception:
                    pass


# ─────────────────────────────────────────────
# DNSRECON
# ─────────────────────────────────────────────

def _run_dnsrecon(target: str, output_dir: Path) -> List[str]:
    """Run dnsrecon for additional DNS enumeration."""
    subs      = set()
    dnsrecon  = get_tool("dnsrecon")
    out_file  = str(output_dir / "dnsrecon.json")

    stdout, stderr, rc = run_tool(
        [dnsrecon, "-d", target, "-t", "std,brt,srv,axfr",
         "--lifetime", "5", "-j", out_file],
        timeout=120,
        target=target,
    )

    out_path = Path(out_file)
    if out_path.exists():
        try:
            data = json.loads(out_path.read_text())
            for entry in data:
                name = entry.get("name", "")
                if name and (name.endswith(f".{target}") or name == target):
                    subs.add(name.lower())
        except Exception:
            pass

    return list(subs)
