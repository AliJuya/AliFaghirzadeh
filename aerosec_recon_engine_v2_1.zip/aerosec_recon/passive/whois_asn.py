"""
AeroSecLab Recon Engine — Passive: WHOIS & ASN
Tools: whois, dig
Sources: ARIN, RIPE, APNIC RDAP, BGP.he.net, ipinfo.io
"""

from __future__ import annotations

import json
import re
import socket
from pathlib import Path
from typing import List, Optional, Set

import requests

from ..core.models import (
    ModuleReport, ReconReport, WhoisInfo, ASNInfo, Finding, Subdomain
)
from ..core.config import get_tool, REQUEST_TIMEOUT
from ..core.logger import log
from ..core.http_utils import run_tool


MODULE_NAME = "whois_asn"

UA = "AeroSecLab/1.0"


def run(
    target     : str,
    report     : ReconReport,
    mod_report : ModuleReport,
    output_dir : Path,
):
    log("INFO", target, "WHOIS & ASN — starting")

    # ── WHOIS ─────────────────────────────────────────────────────────
    whois_info = _get_whois(target)
    if whois_info:
        report.whois = whois_info
        log("OK", target, f"  Registrar: {whois_info.registrar}")
        log("OK", target, f"  Expires:   {whois_info.expires}")
        log("OK", target, f"  Emails:    {whois_info.emails}")

        # Check domain expiry
        _check_expiry(target, whois_info, mod_report)

    # ── Resolve apex IPs ──────────────────────────────────────────────
    apex_ips = _resolve_ips(target)
    log("OK", target, f"  Apex IPs: {apex_ips}")

    # ── ASN lookup for each IP ────────────────────────────────────────
    asn_info = None
    if apex_ips:
        asn_info = _get_asn_info(apex_ips[0])
        if asn_info:
            report.asn = asn_info
            log("OK", target, f"  ASN: {asn_info.asn} ({asn_info.org})")
            log("OK", target, f"  Prefixes: {asn_info.prefixes_v4[:5]}")

            # Find more IPs in the same ASN range
            asn_subs = _find_subs_in_asn(target, asn_info)
            if asn_subs:
                existing = {s.fqdn for s in report.subdomains}
                for fqdn in asn_subs:
                    if fqdn not in existing:
                        report.subdomains.append(
                            Subdomain(fqdn=fqdn, source="asn_range")
                        )
                log("OK", target, f"  ASN-range subdomains: {len(asn_subs)}")

    # ── Reverse WHOIS — find other domains by same registrant ─────────
    related_domains = []
    if whois_info and whois_info.emails:
        for email in whois_info.emails[:2]:
            rel = _reverse_whois_by_email(email, target)
            related_domains.extend(rel)
        if related_domains:
            log("OK", target, f"  Related domains (same registrant): {related_domains[:5]}")

    # ── Summary ───────────────────────────────────────────────────────
    mod_report.summary = {
        "registrar"       : whois_info.registrar if whois_info else "",
        "expires"         : whois_info.expires if whois_info else "",
        "registrant_org"  : whois_info.registrant_org if whois_info else "",
        "emails_found"    : whois_info.emails if whois_info else [],
        "asn"             : asn_info.asn if asn_info else "",
        "asn_org"         : asn_info.org if asn_info else "",
        "ip_prefixes"     : asn_info.prefixes_v4[:10] if asn_info else [],
        "related_domains" : related_domains[:10],
    }
    mod_report.data = {
        "whois_raw"       : whois_info.raw[:3000] if whois_info else "",
        "apex_ips"        : apex_ips,
        "asn_prefixes_v4" : asn_info.prefixes_v4 if asn_info else [],
        "asn_prefixes_v6" : asn_info.prefixes_v6 if asn_info else [],
        "asn_peers"       : asn_info.peers[:20] if asn_info else [],
        "related_domains" : related_domains,
    }
    log("OK", target, "WHOIS & ASN complete")


# ─────────────────────────────────────────────
# WHOIS
# ─────────────────────────────────────────────

def _get_whois(target: str) -> Optional[WhoisInfo]:
    """Get WHOIS information for the target domain."""
    raw = _whois_tool(target) or _whois_rdap(target)
    if not raw:
        return None
    return _parse_whois(raw)


def _whois_tool(target: str) -> str:
    whois = get_tool("whois")
    if not whois:
        return ""
    stdout, _, _ = run_tool([whois, "-H", target], timeout=30)
    return stdout


def _whois_rdap(target: str) -> str:
    """Fallback: RDAP protocol via IANA."""
    try:
        # Find RDAP server for TLD
        tld = target.split(".")[-1]
        r   = requests.get(
            f"https://rdap.org/domain/{target}",
            timeout=15, headers={"User-Agent": UA}
        )
        if r.ok:
            return json.dumps(r.json(), indent=2)
    except Exception:
        pass
    return ""


def _parse_whois(raw: str) -> WhoisInfo:
    """Parse raw WHOIS output into structured WhoisInfo."""
    info = WhoisInfo(raw=raw)

    patterns = {
        "registrar"          : [r'Registrar:\s*(.+)', r'registrar:\s*(.+)'],
        "registered"         : [r'Creation Date:\s*(.+)', r'created:\s*(.+)',
                                r'Registered on:\s*(.+)', r'Registration Date:\s*(.+)'],
        "updated"            : [r'Updated Date:\s*(.+)', r'last-modified:\s*(.+)',
                                r'Last Updated on:\s*(.+)'],
        "expires"            : [r'Registry Expiry Date:\s*(.+)', r'Expiry Date:\s*(.+)',
                                r'Expiration Date:\s*(.+)', r'expires:\s*(.+)'],
        "registrant_org"     : [r'Registrant Organization:\s*(.+)',
                                r'org-name:\s*(.+)', r'Organisation:\s*(.+)'],
        "registrant_country" : [r'Registrant Country:\s*(.+)', r'country:\s*(.+)'],
    }

    for field, pats in patterns.items():
        for pat in pats:
            m = re.search(pat, raw, re.I | re.M)
            if m:
                setattr(info, field, m.group(1).strip()[:200])
                break

    # Name servers
    info.name_servers = list(set(
        re.findall(r'Name Server:\s*([^\s]+)', raw, re.I)
    ))

    # Email addresses
    info.emails = list(set(
        re.findall(r'[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}', raw)
    ))

    return info


def _check_expiry(target: str, whois: WhoisInfo, mod_report: ModuleReport):
    """Check if domain is expiring soon."""
    if not whois.expires:
        return
    import datetime
    date_patterns = [
        "%Y-%m-%dT%H:%M:%SZ",
        "%Y-%m-%dT%H:%M:%S",
        "%Y-%m-%d",
        "%d-%b-%Y",
        "%B %d, %Y",
    ]
    for pat in date_patterns:
        try:
            exp = datetime.datetime.strptime(whois.expires.strip()[:25], pat)
            days_left = (exp - datetime.datetime.utcnow()).days
            if days_left < 0:
                mod_report.findings.append(Finding(
                    severity    = "critical",
                    title       = "Domain expired!",
                    url         = target,
                    evidence    = f"Expiry: {whois.expires} ({abs(days_left)} days ago)",
                    module      = MODULE_NAME,
                    remediation = "Renew domain immediately",
                    tags        = ["domain", "expiry"],
                ))
            elif days_left < 30:
                mod_report.findings.append(Finding(
                    severity    = "high",
                    title       = f"Domain expiring in {days_left} days",
                    url         = target,
                    evidence    = f"Expiry: {whois.expires}",
                    module      = MODULE_NAME,
                    remediation = "Renew domain before expiry",
                    tags        = ["domain", "expiry"],
                ))
            break
        except ValueError:
            continue


# ─────────────────────────────────────────────
# ASN
# ─────────────────────────────────────────────

def _resolve_ips(target: str) -> List[str]:
    try:
        return list({ai[4][0] for ai in socket.getaddrinfo(target, None)})
    except Exception:
        return []


def _get_asn_info(ip: str) -> Optional[ASNInfo]:
    """Get ASN information for an IP address."""
    info = ASNInfo()

    # Primary: ipinfo.io
    try:
        r = requests.get(
            f"https://ipinfo.io/{ip}/json",
            timeout=15, headers={"User-Agent": UA}
        )
        if r.ok:
            data = r.json()
            asn_raw = data.get("org", "")
            if " " in asn_raw:
                parts      = asn_raw.split(" ", 1)
                info.asn   = parts[0]
                info.org   = parts[1]
            info.country = data.get("country", "")
    except Exception:
        pass

    # Get prefix info from BGP.he.net / RIPE
    if info.asn:
        info.prefixes_v4, info.prefixes_v6, info.peers = _get_bgp_info(info.asn)

    return info if info.asn else None


def _get_bgp_info(asn: str) -> tuple:
    """Get BGP prefix and peer info for an ASN."""
    prefixes_v4 = []
    prefixes_v6 = []
    peers       = []

    # Clean ASN
    asn_num = asn.replace("AS", "").strip()

    try:
        r = requests.get(
            f"https://api.bgpview.io/asn/{asn_num}/prefixes",
            timeout=15, headers={"User-Agent": UA}
        )
        if r.ok:
            data = r.json()
            for prefix in data.get("data", {}).get("ipv4_prefixes", []):
                prefixes_v4.append(prefix.get("prefix", ""))
            for prefix in data.get("data", {}).get("ipv6_prefixes", []):
                prefixes_v6.append(prefix.get("prefix", ""))
    except Exception:
        pass

    try:
        r = requests.get(
            f"https://api.bgpview.io/asn/{asn_num}/peers",
            timeout=15, headers={"User-Agent": UA}
        )
        if r.ok:
            data = r.json()
            for peer in data.get("data", {}).get("ipv4_peers", []):
                peers.append(f"AS{peer.get('asn', '')} ({peer.get('name', '')})")
    except Exception:
        pass

    return prefixes_v4, prefixes_v6, peers[:30]


def _find_subs_in_asn(target: str, asn: ASNInfo) -> List[str]:
    """
    Find subdomains hosted in the same ASN range via reverse DNS.
    Useful for finding origin IPs behind CDN.
    """
    subs = set()
    if not asn.asn:
        return []

    asn_num = asn.asn.replace("AS", "").strip()

    # Query Shodan for hosts in this ASN (if no key, use BGPView)
    try:
        r = requests.get(
            f"https://api.bgpview.io/asn/{asn_num}/ips",
            timeout=15, headers={"User-Agent": UA}
        )
        if r.ok:
            data = r.json()
            for ip_entry in data.get("data", {}).get("ipv4_addresses", [])[:100]:
                ip = ip_entry.get("ip", "")
                try:
                    hostname = socket.gethostbyaddr(ip)[0].lower()
                    if hostname.endswith(f".{target}") or hostname == target:
                        subs.add(hostname)
                except Exception:
                    pass
    except Exception:
        pass

    return list(subs)


# ─────────────────────────────────────────────
# REVERSE WHOIS
# ─────────────────────────────────────────────

def _reverse_whois_by_email(email: str, target: str) -> List[str]:
    """Find other domains registered by the same email via ViewDNS."""
    domains = []
    try:
        r = requests.get(
            f"https://viewdns.info/reversewhois/?q={email}",
            timeout=20, headers={"User-Agent": "Mozilla/5.0"}
        )
        if r.ok:
            matches = re.findall(
                r'<td>([a-zA-Z0-9._-]+\.[a-zA-Z]{2,})</td>',
                r.text
            )
            for m in matches:
                if m.lower() != target.lower():
                    domains.append(m.lower())
    except Exception:
        pass
    return list(set(domains))[:20]
