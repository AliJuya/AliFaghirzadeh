"""
AeroSecLab Recon Engine — Passive: Certificate Transparency
Sources: crt.sh, certspotter, tlsx
Finds subdomains via SSL/TLS certificate records.
"""

from __future__ import annotations

import json
import re
import subprocess
from pathlib import Path
from typing import Set

import requests

from ..core.models import ModuleReport, ReconReport, Subdomain, DNSRecord, Finding
from ..core.config import get_tool, REQUEST_TIMEOUT
from ..core.logger import log
from ..core.http_utils import run_tool


MODULE_NAME = "cert_transparency"


def run(
    target     : str,
    report     : ReconReport,
    mod_report : ModuleReport,
    output_dir : Path,
):
    log("INFO", target, "Certificate Transparency — starting")
    found: Set[str] = set()

    # ── crt.sh ───────────────────────────────
    crtsh_subs = _query_crtsh(target)
    found |= crtsh_subs
    log("OK", target, f"  crt.sh → {len(crtsh_subs)} names")

    # ── certspotter ──────────────────────────
    spot_subs = _query_certspotter(target)
    found |= spot_subs
    log("OK", target, f"  certspotter → {len(spot_subs)} names")

    # ── alienvault OTX ───────────────────────
    otx_subs = _query_otx(target)
    found |= otx_subs
    log("OK", target, f"  AlienVault OTX → {len(otx_subs)} names")

    # ── RapidDNS ─────────────────────────────
    rapid_subs = _query_rapiddns(target)
    found |= rapid_subs
    log("OK", target, f"  RapidDNS → {len(rapid_subs)} names")

    # ── tlsx (if available) ──────────────────
    if get_tool("tlsx"):
        tlsx_subs = _run_tlsx(target)
        found |= tlsx_subs
        log("OK", target, f"  tlsx → {len(tlsx_subs)} names")

    # ── Merge into report ────────────────────
    existing_fqdns = {s.fqdn for s in report.subdomains}
    new_count = 0
    for fqdn in sorted(found):
        if fqdn not in existing_fqdns:
            report.subdomains.append(Subdomain(fqdn=fqdn, source=MODULE_NAME))
            existing_fqdns.add(fqdn)
            new_count += 1

    mod_report.summary = {
        "total_found"      : len(found),
        "new_subdomains"   : new_count,
        "sources"          : ["crt.sh", "certspotter", "alienvault_otx", "rapiddns", "tlsx"],
    }
    mod_report.data = {
        "subdomains": sorted(found),
    }

    # Save raw output
    out_file = output_dir / f"{MODULE_NAME}_raw.txt"
    out_file.write_text("\n".join(sorted(found)))
    log("OK", target, f"  Total CT subdomains: {len(found)} ({new_count} new)")


# ─────────────────────────────────────────────
# SOURCES
# ─────────────────────────────────────────────

def _clean_sub(name: str, target: str) -> str:
    """Normalize and validate a subdomain."""
    name = name.strip().lower().lstrip("*.")
    if name.endswith(f".{target}") or name == target:
        return name
    return ""


def _query_crtsh(target: str) -> Set[str]:
    """Query crt.sh certificate transparency log."""
    subs = set()
    urls = [
        f"https://crt.sh/?q=%.{target}&output=json",
        f"https://crt.sh/?q={target}&output=json",
    ]
    for url in urls:
        try:
            r = requests.get(url, timeout=30,
                             headers={"User-Agent": "AeroSecLab/1.0"})
            if r.ok:
                for entry in r.json():
                    for name in entry.get("name_value", "").split("\n"):
                        clean = _clean_sub(name, target)
                        if clean:
                            subs.add(clean)
        except Exception:
            pass
    return subs


def _query_certspotter(target: str) -> Set[str]:
    """Query Sslmate CertSpotter API."""
    subs = set()
    try:
        url = f"https://api.certspotter.com/v1/issuances?domain={target}&include_subdomains=true&expand=dns_names"
        r   = requests.get(url, timeout=20,
                           headers={"User-Agent": "AeroSecLab/1.0"})
        if r.ok:
            for entry in r.json():
                for name in entry.get("dns_names", []):
                    clean = _clean_sub(name, target)
                    if clean:
                        subs.add(clean)
    except Exception:
        pass
    return subs


def _query_otx(target: str) -> Set[str]:
    """Query AlienVault OTX for subdomains."""
    subs  = set()
    page  = 1
    while True:
        try:
            url = f"https://otx.alienvault.com/api/v1/indicators/domain/{target}/passive_dns?page={page}"
            r   = requests.get(url, timeout=20,
                               headers={"User-Agent": "AeroSecLab/1.0"})
            if not r.ok:
                break
            data     = r.json()
            passive  = data.get("passive_dns", [])
            if not passive:
                break
            for entry in passive:
                hostname = entry.get("hostname", "")
                clean    = _clean_sub(hostname, target)
                if clean:
                    subs.add(clean)
            if not data.get("has_next"):
                break
            page += 1
        except Exception:
            break
    return subs


def _query_rapiddns(target: str) -> Set[str]:
    """Query RapidDNS for subdomains."""
    subs = set()
    try:
        url = f"https://rapiddns.io/subdomain/{target}?full=1#result"
        r   = requests.get(url, timeout=20,
                           headers={"User-Agent": "Mozilla/5.0"})
        if r.ok:
            # Parse table rows
            matches = re.findall(
                r'<td>([a-zA-Z0-9._-]+\.' + re.escape(target) + r')</td>',
                r.text
            )
            for m in matches:
                clean = _clean_sub(m, target)
                if clean:
                    subs.add(clean)
    except Exception:
        pass
    return subs


def _run_tlsx(target: str) -> Set[str]:
    """Use tlsx to find subdomains via TLS certificate scanning."""
    subs    = set()
    tlsx    = get_tool("tlsx")
    if not tlsx:
        return subs

    stdout, stderr, rc = run_tool(
        [tlsx, "-san", "-cn", "-silent", "-json", "-host", target],
        timeout=60,
        target=target,
    )
    if not stdout:
        return subs

    for line in stdout.splitlines():
        try:
            data = json.loads(line)
            for name in data.get("san", []) + [data.get("cn", "")]:
                clean = _clean_sub(name, target)
                if clean:
                    subs.add(clean)
        except Exception:
            pass
    return subs
