# Changelog

## [2.1.0] — Team Merge

Merged 4 high-value features after reviewing the team's `judge_safe_plus` build.

### ✨ New Modules

- **`active/service_exposure`** — Port-aware HTTP validation for high-signal local services. Maps detected ports (Elasticsearch:9200, Kibana:5601, Prometheus:9090, Grafana:3000, RabbitMQ:15672, Redis:6379, MongoDB:27017, Kubelet:10250, Docker API:2375, Consul:8500, etcd:2379, Vault:8200, ActiveMQ:8161, Neo4j:7474, +more) to canonical validation paths and probes them read-only. Complements `cms_probes` by being port-driven instead of fingerprint-driven.
- **`analysis/local_exposure`** — Sweeps the full `SENSITIVE_PATHS` list (120+ paths) against every live host. Catches the long tail of misconfigurations: `.env` files, backup artifacts, `/server-status`, `/phpinfo`, `/.well-known/`, JSON responses with secret-keywords, WebDAV verbs via OPTIONS, TRACE method enabled. Includes SPA-fallback detection so that catch-all SPAs returning 200 for every path don't generate false positives.
- **`analysis/tech_cve`** — Cross-correlates detected technology versions with (a) a curated table of high-confidence version→CVE mappings (Apache 2.4.49/.50, Spring 5.3.17, Log4j 2.14.1, Confluence 7.13.0, GitLab 13.10.3, Drupal 7.58, etc.), and (b) nuclei findings indexed by host origin. Each tech inventory entry shows how many nuclei findings exist on the same host. Runs LAST in the analysis phase so it can consume upstream module output.

### ✨ New Core Feature

- **Diff system** (`core/risk_engine.diff_reports` + `Reporter._load_previous_report`) — Re-running against the same output directory now compares against the previous `report.json` and writes both:
  - A `## 🔄 Changes Since Previous Run` section in `report.md` showing risk-score delta, grade change, new/resolved findings, and host inventory deltas
  - A `report_diff.json` sidecar with the structured diff for programmatic consumption

  Findings match by `(severity, title, url)` so the diff is deterministic across re-runs. Useful for re-scans of the same target after remediation.

### Metrics

- **v2.0:** 20 modules, 11,254 LOC
- **v2.1:** 23 modules, ~12,750 LOC, diff-aware reporting

---

## [2.0.0] — AeroSecLab Recon Engine v2

### 🐛 Bugs Fixed

- **WAF detection hang** (`active/web_probe.py::_run_wafw00f`) — rewrote from sequential single-threaded `-a` probes (each 30–60s) to parallel execution with 8 workers, 25s hard per-call timeout, per-URL output files (was overwriting), and JSON output parsing.
- **Duplicate HTTP fetch per host** (`active/web_probe.py::_fingerprint_host`) — now reuses headers from httpx where available, falls back to short-timeout probe.
- **Amass killed mid-run** (`active/subdomain_brute.py::_run_amass`) — `-timeout 10` was 10 MINUTES (amass convention), TOOL_TIMEOUT (300s) killed it. Now `-timeout 4` + `-nolocaldb`.
- **Wildcard DNS pollution** (`active/subdomain_brute.py`) — detection was separate from result filtering. Now: wildcard IPs captured with 3-probe heuristic pre-brute, brute results validated against wildcard set, passive-source results exempted.
- **Orchestrator race condition** (`core/orchestrator.py`) — all active modules ran in parallel, but `port_scan` and `web_probe` depend on `subdomain_brute` output. Now uses staged execution with explicit dependency graph per phase.
- **F5 cookie decoder** (`core/http_utils.py::decode_f5_cookie`) — fixed-offset hex slicing failed on variable-prefix cookies. Now handles both plain-decimal and hex-encoded formats with regex search and IP validation heuristics.
- **`None` added to JS URL set** (`analysis/js_intel.py::_discover_js_urls`) — `_resolve_url` could return `None`, crashing downstream.
- **Duplicate findings from multi-module attribution** (`core/models.py::all_findings`) — now dedupes by (title, url, module) tuple.
- **Report markdown pipes in URLs break tables** (`export/report.py`) — added `_escape_md` and `_safe_url` helpers.
- **`all_findings` crash on non-ModuleReport attrs** (`core/models.py`) — now uses `isinstance` guard.

### ✨ New Active Modules

- **`nuclei_scan`** — ProjectDiscovery nuclei integration with strict detection-only tag policy (`cve,exposure,misconfig,tech` included; `intrusive,dos,fuzz,bruteforce,default-login` excluded). Auto-updates templates, parses JSONL, maps CVE IDs / CWE IDs / CVSS scores into Finding objects.
- **`takeover`** — Subdomain takeover detection against a 25-vendor curated fingerprint database (AWS S3/CloudFront/EB, Azure App/Blob/TrafficManager, GCP, GitHub Pages, Heroku, Shopify, Fastly, Pantheon, Netlify, Vercel, Surge, Tumblr, Zendesk, Statuspage, Readme.io, Unbounce, Webflow, Bitbucket). Includes dangling-CNAME-with-NXDOMAIN detection.
- **`screenshots`** — gowitness integration (v2/v3 syntax auto-detected) with screenshot paths referenced from report.md for visual evidence.
- **`cms_probes`** — Unauthenticated detection probes for: Strapi (admin/init, open registration, /api/users), Spring Boot Actuator (17 endpoints including heapdump/env/httptrace), Jenkins (api/json, version, script console detection), GitLab (version, public projects, sign-up), WordPress (REST user enum, xmlrpc, wp-config backup, readme), Drupal, Joomla, phpMyAdmin/Adminer, Elasticsearch/Kibana, Grafana (health + datasources), Sonatype Nexus, JFrog Artifactory, Apache Solr, Apache Druid.

### ✨ New Analysis Modules

- **`graphql_intel`** — Probes 14 common GraphQL paths, sends introspection query, extracts schema (types/queries/mutations/subscriptions), flags sensitive fields (credentials/admin/financial) and dangerous mutations (delete/transfer/grant verbs). Saves full schemas to disk.
- **`swagger_intel`** — Discovers Swagger/OpenAPI specs across 25+ paths, parses v2 and v3 (JSON + YAML), builds complete endpoint inventory, flags sensitive endpoints, detects auth-scheme absence, populates global Parameter inventory.
- **`git_secrets`** — Detects exposed `.git`, `.svn`, `.hg`, `.bzr`, CVS repositories with content validation (binary magic bytes for `.git/index`, HEAD format regex, `[core]/[remote]` config markers, credential extraction from remote URLs). Critical finding when ≥3 files exposed.
- **`favicon_hash`** — Downloads favicons, computes mmh3 (Shodan-style) hash, matches against curated 50-entry fingerprint database (admin panels, CMSs, frameworks, monitoring, infrastructure).
- **`cloud_assets`** — Generates candidate bucket names from WHOIS registrant org, ASN org, apex, and JS-discovered buckets. Cross-permutes with 30 common suffixes, probes AWS S3, GCS, Azure Blob for existence + public listing.

### ✨ New Core Infrastructure

- **`core/risk_engine.py`** — Weighted scoring engine:
  - Base points per severity (critical=40, high=15, medium=5, low=1, info=0.2)
  - CVE multiplier (×1.5), high-value tag multipliers (credentials/auth-bypass/takeover ×1.2–1.4), low-value tag dampeners (version-disclosure ×0.6)
  - Per-asset exposure multipliers (no-WAF ×1.4, WAF ×0.85, admin/dev tool ×1.35, sensitive FQDN ×1.05–1.3)
  - Normalized 0–100 target score + letter grade (A/B/C/D/F) with hex color
  - Auto-generated executive-summary bullets

### 🎨 Report Rewrite

Complete rewrite of `export/report.py` for executive-quality output:
- Hero card with 5 shields.io badges
- Auto-generated executive summary bullets
- Mermaid pie chart for severity distribution
- Module-contribution bar visualization
- Top 5 assets by risk score
- Top 10 findings with reproduction context (evidence + tags + CVE + reasons)
- Per-asset inventory cards with scoring notes
- Collapsible `<details>` blocks for each severity tier
- Attack-surface analysis (tech + port distributions)
- JS intelligence highlights (8 categorized sections)
- CDN/WAF coverage matrix with unprotected-host callouts
- Methodology description
- Schema-versioned JSON (v2.0) with stable finding IDs (SHA-256 based)

### 📊 Metrics

- **Before:** 11 modules, 6,757 LOC, flat MD report
- **After:**  20 modules, ~12,000 LOC, executive MD + schema-versioned JSON
