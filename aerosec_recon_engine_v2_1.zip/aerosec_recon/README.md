# AeroSecLab Recon Engine v2.1

**A comprehensive, modular reconnaissance framework for Kali Linux.**

Executes a staged pipeline of 23 detection-only modules across passive intelligence gathering, active service discovery, and deep analysis — producing executive-quality Markdown and machine-readable JSON reports with weighted risk scoring and re-run diff comparison.

---

## 🎯 Design Philosophy

**Detection-only, no exploitation.** Every module is bounded to information gathering: DNS enumeration, certificate transparency, service fingerprinting, version detection, misconfiguration discovery, and JavaScript mining. No credential brute-force, no RCE payloads, no data exfiltration, no destructive tests.

**Coverage density matters more than raw volume.** The engine cross-references signals from multiple sources (passive DNS, active probes, JS mining, CT logs, favicon hashing) to produce findings with high confidence and low false-positive rate.

**Reports that an executive can read and an engineer can act on.** Every finding carries a risk score, reproduction context, and concrete remediation. A weighted overall grade (A–F) tells you in 5 seconds whether the target is in trouble.

---

## 📦 What's Inside

### 20 Modules Across 3 Phases

**Passive** (no traffic to target)
- `cert_transparency` — crt.sh, Censys CT, Facebook CT
- `dns_enum` — dig/dnsx/massdns, zone transfer attempt, reverse DNS
- `osint` — Shodan, SecurityTrails, Wayback, Hunter.io, BGP
- `whois_asn` — WHOIS parsing, ASN prefix enumeration

**Active** (controlled probes)
- `subdomain_brute` — subfinder, amass, assetfinder, findomain, ffuf DNS vhost fuzz, exchange-specific wordlist, permutation brute
- `port_scan` — masscan → nmap service detection → naabu fallback
- `web_probe` — httpx bulk fingerprinting, deep tech detection, CDN/WAF identification, TLS cert parsing, security-header analysis, F5 cookie decoding
- `cdn_bypass` — historical DNS, SPF/MX IP extraction, Shodan cert search, origin confirmation with Host header injection
- `nuclei_scan` — community templates filtered to detection-only tags (`cve`, `exposure`, `misconfig`, `tech`) with `intrusive`/`dos`/`fuzz`/`bruteforce` excluded
- `takeover` — CNAME fingerprint matching against curated DB of 25+ cloud services
- `screenshots` — gowitness headless-browser captures for visual evidence
- `cms_probes` — unauthenticated detection probes for Strapi, Spring Boot Actuator, Jenkins, GitLab, WordPress, Drupal, Joomla, phpMyAdmin/Adminer, Kibana/Elasticsearch, Grafana, Nexus/Artifactory, Apache Solr/Druid
- **`service_exposure`** *(v2.1)* — Port-aware HTTP validation for Elasticsearch, Kibana, Prometheus, Grafana, RabbitMQ, Redis, MongoDB, Kubelet, Docker API, Consul, etcd, Vault, ActiveMQ, Neo4j, Splunk

**Analysis**
- `link_crawler` — katana, gau, waybackurls, hakrawler with fallback BFS
- `js_intel` — bundle discovery → secret mining (API keys, JWTs, Firebase, S3, private IPs, WebSockets, STOMP channels, financial endpoints)
- `param_extractor` — arjun, paramspider, manual extraction
- `graphql_intel` — introspection queries against 14 common paths, schema extraction, sensitive-field and dangerous-mutation detection
- `swagger_intel` — OpenAPI/Swagger spec discovery from 25+ paths, endpoint inventory, sensitive-endpoint flagging, auth-scheme audit
- `git_secrets` — .git/.svn/.hg/.bzr/CVS exposure detection with content-validation
- `favicon_hash` — mmh3 Shodan-style hashing against curated 50+ entry fingerprint DB
- `cloud_assets` — permutation-based S3/GCS/Azure bucket discovery using WHOIS + ASN + apex data as seeds
- **`local_exposure`** *(v2.1)* — Sweep of 120+ sensitive paths against every live host with content-aware classification (catches `.env`, backup artifacts, `/server-status`, JSON-with-secret-keywords, WebDAV verbs)
- **`tech_cve`** *(v2.1)* — Cross-correlates detected tech versions with curated CVE table (Apache 2.4.49/.50, Spring4Shell, Log4Shell, Confluence OGNL, etc.) AND nuclei findings indexed by host. Runs LAST in the pipeline to consume upstream module output.

### Risk Scoring Engine

Each finding receives a weighted score based on severity, CVE status, tag boosters (credentials / auth-bypass / takeover / full-repo), and per-asset multipliers (exposure factor, sensitivity keywords in FQDN, admin/dev-tool detection). Scores aggregate into:
- Per-finding score (0–150+)
- Per-asset score
- Target score (normalized 0–100)
- Letter grade (A: clean → F: critical posture)

### Diff Comparison (v2.1)

Re-running against the same output directory automatically compares against the previous `report.json` and surfaces:
- Risk-score delta and grade change
- New findings (sorted by severity)
- Resolved findings
- New / removed live hosts

The diff appears as a `## 🔄 Changes Since Previous Run` section near the top of `report.md`, plus a `report_diff.json` sidecar for programmatic consumption. Findings match by `(severity, title, url)` so the diff is deterministic across re-runs.

### Executive-Quality Reports

**`report.md`** includes:
- Hero card with shields.io badges for grade/score/findings
- Executive summary with auto-generated bullet points
- Risk dashboard with Mermaid pie charts
- Top 10 findings with reproduction context
- Asset inventory sorted by risk score, one card per host
- Collapsible per-severity finding details
- Attack-surface analysis (tech distribution, port distribution)
- JS intelligence highlights (transfer paths, secrets, WebSockets)
- CDN/WAF coverage matrix with unprotected-host callouts
- Subdomain table
- Organization intelligence (WHOIS/ASN/DNS)
- Methodology + executed-modules status table
- Raw counts appendix

**`report.json`** — schema-versioned (v2.0), stable finding IDs, risk scores, per-asset breakdown, full evidence preserved.

---

## 🚀 Quick Start

```bash
# 1. Install dependencies
cd aerosec_recon
sudo python3 installer.py

# 2. Verify tool installation
python3 run.py --verify-tools

# 3. Run full recon
python3 run.py --target example.com

# 4. Scoped runs
python3 run.py --target example.com --phases passive analysis
python3 run.py --target example.com --modules nuclei_scan takeover cms_probes

# 5. Multi-target
echo -e "target1.com\ntarget2.com" > clients.txt
python3 run.py --list clients.txt --threads 3
```

Reports land in `/home/aero/lab/results/<target>/` by default (override with `--output`).

---

## 🔒 Scope Adherence

This engine is built for recon-only contexts (bug bounty, challenge, internal assessment). It **does not**:

- Send credential brute-force (no default-login templates, no dictionary auth)
- Execute mutations in GraphQL (only reads schema via introspection)
- Attempt RCE (only detects exposed management endpoints)
- Upload or write to cloud buckets (only HEAD/GET)
- Register user accounts (only detects *whether* registration is open)
- Execute any nuclei template tagged `intrusive`, `dos`, `fuzz`, `bruteforce`, or `default-login`

All findings are derived from: GET requests, controlled POST of read-only queries (GraphQL introspection, Swagger spec fetch), DNS queries, TCP connect scans, and subprocess invocation of standard security tools.

---

## 🏗️  Architecture

```
aerosec_recon/
├── run.py                        # CLI entry point
├── installer.py                  # Tool/dependency installer
├── core/
│   ├── config.py                 # Paths, timeouts, wordlists, fingerprints
│   ├── models.py                 # Dataclass models (Finding, LiveHost, ReconReport…)
│   ├── http_utils.py             # Session pooling, UA rotation, subprocess runner
│   ├── logger.py                 # Colored structured logging
│   ├── orchestrator.py           # Staged execution with dependency ordering
│   └── risk_engine.py            # Weighted scoring per finding/asset/target
├── passive/                      # 4 modules
├── active/                       # 8 modules (4 new in v2)
├── analysis/                     # 8 modules (5 new in v2)
└── export/
    └── report.py                 # MD + JSON writers with Mermaid, badges
```

### Execution Ordering (Active Phase)

```
Stage 1: subdomain_brute                 # must finish first — populates report.subdomains
Stage 2: web_probe, port_scan            # parallel — both read subdomains
Stage 3: takeover, screenshots           # need live_hosts from web_probe
Stage 4: nuclei_scan, cms_probes,        # need live_hosts + tech detection + ports
         service_exposure
Stage 5: cdn_bypass                      # uses live_hosts.cdn flags
```

### Execution Ordering (Analysis Phase)

```
Stage 1: link_crawler                    # populates crawled_links
Stage 2: js_intel                        # discovers JS from live_hosts
Stage 3: param_extractor, graphql_intel, # parallel — independent
         swagger_intel, git_secrets,
         favicon_hash, cloud_assets,
         local_exposure
Stage 4: tech_cve                        # last — correlates upstream nuclei + tech inventory
```

---

## 🛠️  Dependencies

**Python:** `requests urllib3 mmh3 PyYAML dnspython wafw00f arjun paramspider`

**Go tools** (via `go install`): `subfinder httpx dnsx katana naabu nuclei tlsx assetfinder waybackurls gau hakrawler gowitness findomain amass`

**System tools** (via `apt`): `nmap masscan dig whois curl ffuf gobuster whatweb dnsrecon massdns`

All auto-installed by `installer.py`.

---

## 📊 Sample Output Reference

A clean target with only security-header gaps typically scores **B (15–25)**.
A target with one exposed admin panel typically scores **C (30–40)**.
A target with exposed `.git`, open actuator, and takeover candidates typically scores **F (70–100)**.

---

*AeroSecLab Recon Engine v2.0.0 — comprehensive detection-only recon for Kali Linux.*
