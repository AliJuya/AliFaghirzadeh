"""
AeroSecLab Recon Engine — Active: Service Exposure

Maps high-signal service ports detected by port_scan to their canonical
HTTP validation paths and probes them read-only. Complements `cms_probes`
(which is application-fingerprint-driven) by being port-driven — catches
exposed dashboards even when no live web host was previously confirmed
on that port.

Coverage:
  - Elasticsearch (9200) - / (cluster info), /_cat/indices
  - Kibana (5601) - /login, /api/status
  - Prometheus (9090) - /-/ready, /api/v1/status/config
  - Grafana (3000) - /login, /api/health
  - RabbitMQ Management (15672) - / (UI)
  - Memcached (11211) - port-only signal (binary protocol)
  - MongoDB (27017, 28017) - port-only / HTTP UI on 28017
  - Kubelet API (10250) - /pods (information disclosure)
  - Docker remote API (2375, 2376) - /version (RCE-grade if open)
  - Jenkins agent (50000)
  - Consul (8500) - /v1/status/leader
  - etcd (2379) - /version
  - Cassandra HTTP (8080 mgmt) — port signal
  - Vault UI (8200) — /v1/sys/health (with no auth)
  - Portainer (9000)
  - Splunk (8000, 8089)

Detection-only: GET to validation paths, no auth attempts, no writes.
"""

from __future__ import annotations

import concurrent.futures
import json
from pathlib import Path
from typing import Dict, List, Optional, Set, Tuple
from urllib.parse import urlparse

from ..core.http_utils import safe_get
from ..core.logger import log
from ..core.models import ModuleReport, ReconReport, Finding, LiveHost


MODULE_NAME = "service_exposure"


# (severity, title, remediation, validation_path, scheme_hint)
# scheme_hint: "http", "https", or None (try both)
PORT_RULES: Dict[int, Tuple[str, str, str, Optional[str], Optional[str]]] = {
    9200:  ("critical", "Elasticsearch HTTP API reachable",
            "Enable xpack.security.enabled and authentication. Restrict to internal network.",
            "/", "http"),
    9300:  ("medium",   "Elasticsearch transport port reachable",
            "Restrict transport port to trusted local components only.",
            None, None),
    5601:  ("high",     "Kibana service reachable",
            "Enable Kibana authentication and restrict access.",
            "/api/status", "http"),
    9090:  ("medium",   "Prometheus service reachable",
            "Restrict Prometheus UI/API access via reverse proxy with auth.",
            "/-/ready", "http"),
    3000:  ("medium",   "Grafana-style dashboard reachable",
            "Restrict dashboard access; disable anonymous access.",
            "/api/health", "http"),
    15672: ("high",     "RabbitMQ Management interface reachable",
            "Restrict the management interface; remove `guest:guest` default.",
            "/", "http"),
    11211: ("high",     "Memcached port reachable",
            "Bind Memcached to localhost only; never expose publicly.",
            None, None),
    27017: ("critical", "MongoDB port reachable",
            "Enable MongoDB authentication; bind to localhost or restrict via firewall.",
            None, None),
    28017: ("high",     "MongoDB HTTP status interface reachable",
            "Disable the HTTP interface in mongod.conf (--nohttpinterface).",
            "/", "http"),
    10250: ("high",     "Kubelet API port reachable",
            "Restrict Kubelet to internal network. Enable authentication and authorization.",
            "/pods", "https"),
    2375:  ("critical", "Docker remote API exposed without TLS",
            "Never expose Docker API without TLS + auth. This permits arbitrary container creation.",
            "/version", "http"),
    2376:  ("high",     "Docker TLS API reachable",
            "Restrict Docker TLS API to explicit trusted client certificates only.",
            "/version", "https"),
    50000: ("medium",   "Jenkins agent/web port reachable",
            "Restrict Jenkins-related services and enforce authentication.",
            "/login", "http"),
    8500:  ("high",     "Consul HTTP API reachable",
            "Enable Consul ACLs; restrict the HTTP API to internal network.",
            "/v1/status/leader", "http"),
    2379:  ("critical", "etcd client API reachable",
            "Enable etcd authentication and TLS client cert auth.",
            "/version", "http"),
    8200:  ("high",     "HashiCorp Vault UI reachable",
            "Restrict Vault UI; verify no anonymous policies are bound.",
            "/v1/sys/health", "http"),
    9000:  ("medium",   "Portainer / SonarQube-style UI reachable",
            "Restrict the management UI; enforce strong authentication.",
            "/", "http"),
    8089:  ("medium",   "Splunk management port reachable",
            "Restrict Splunk management port; enforce authentication.",
            "/services/server/info", "https"),
    6379:  ("critical", "Redis port reachable",
            "Enable `requirepass` and bind to localhost. Never expose Redis publicly.",
            None, None),
    9042:  ("high",     "Cassandra CQL port reachable",
            "Restrict CQL port to internal network; enable authentication.",
            None, None),
    7474:  ("high",     "Neo4j HTTP API reachable",
            "Enable Neo4j authentication; restrict access.",
            "/db/data/", "http"),
    8161:  ("high",     "ActiveMQ admin reachable",
            "Restrict ActiveMQ admin to internal network. Change default `admin:admin` credentials.",
            "/admin/", "http"),
}


def run(
    target     : str,
    report     : ReconReport,
    mod_report : ModuleReport,
    output_dir : Path,
):
    log("INFO", target, "Service Exposure — starting")

    if not report.live_hosts:
        log("WARN", target, "  No live hosts to inspect")
        mod_report.summary = {"skipped": "no live hosts"}
        return

    # Build (host, port) probe set from all detected open ports
    probes: List[Tuple[LiveHost, int]] = []
    seen: Set[Tuple[str, int]] = set()
    for host in report.live_hosts:
        for p in host.ports:
            key = (host.fqdn, p.port)
            if key in seen:
                continue
            if p.port not in PORT_RULES:
                continue
            seen.add(key)
            probes.append((host, p.port))

    if not probes:
        log("INFO", target, "  No high-signal service ports observed in port_scan output")
        mod_report.summary = {"probes_attempted": 0, "findings": 0}
        return

    log("INFO", target, f"  Probing {len(probes)} high-signal service ports")

    findings: List[Finding] = []
    hits: List[Dict] = []

    with concurrent.futures.ThreadPoolExecutor(max_workers=12) as ex:
        futures = {
            ex.submit(_probe_service, host, port): (host, port)
            for host, port in probes
        }
        for fut in concurrent.futures.as_completed(futures):
            try:
                f, hit = fut.result()
                if f:
                    findings.append(f)
                if hit:
                    hits.append(hit)
            except Exception:
                pass

    raw_dir = output_dir / MODULE_NAME
    raw_dir.mkdir(exist_ok=True)
    (raw_dir / "service_hits.json").write_text(json.dumps(hits, indent=2))

    mod_report.findings.extend(findings)
    mod_report.summary = {
        "probes_attempted": len(probes),
        "findings"        : len(findings),
        "validated_hits"  : len(hits),
        "critical"        : sum(1 for f in findings if f.severity == "critical"),
        "high"            : sum(1 for f in findings if f.severity == "high"),
    }
    mod_report.data = {"hits": hits}

    log("OK", target,
        f"  Service Exposure complete: {len(probes)} probes → "
        f"{len(hits)} validated hits, {len(findings)} findings")


def _probe_service(host: LiveHost, port: int) -> Tuple[Optional[Finding], Optional[Dict]]:
    """Probe one (host, port) and return (Finding, hit-record). Either may be None."""
    severity, title, remediation, val_path, scheme_hint = PORT_RULES[port]

    # Build target URL — use explicit port (the host.url likely lacks it)
    # Prefer fqdn over IP for SNI / vhost matching
    hostname = host.fqdn or urlparse(host.url).hostname or host.ip
    if not hostname:
        return None, None

    # If no validation path defined, the port itself is the only signal — emit a
    # lower-confidence finding without HTTP validation.
    if not val_path:
        finding = Finding(
            severity    = severity,
            title       = f"{title} on {hostname}:{port}",
            url         = f"tcp://{hostname}:{port}",
            evidence    = f"Port {port}/tcp open (no HTTP validation possible — non-HTTP service)",
            module      = MODULE_NAME,
            remediation = remediation,
            tags        = ["service-exposure", str(port)],
        )
        return finding, {"host": hostname, "port": port,
                          "validated": False, "reason": "non-http"}

    # Try the validation path
    schemes = [scheme_hint] if scheme_hint else ["http", "https"]
    for scheme in schemes:
        if scheme is None:
            continue
        url = f"{scheme}://{hostname}:{port}{val_path}"
        r = safe_get(url, timeout=6, allow_redirects=False)
        if r is None:
            continue

        # Build hit record
        body_excerpt = (r.text or "")[:300]
        hit = {
            "host":      hostname,
            "port":      port,
            "url":       url,
            "scheme":    scheme,
            "status":    r.status_code,
            "content_type": r.headers.get("content-type", ""),
            "validated": True,
            "body_excerpt": body_excerpt[:200],
        }

        # Be more confident if the response status is healthy (2xx/3xx)
        # — auth-required (401/403) still counts as "service is reachable"
        if r.status_code < 500:
            evidence = (f"GET {url} → HTTP {r.status_code} "
                        f"({r.headers.get('content-type','')[:40]}). "
                        f"Body: {body_excerpt[:150]!r}")[:400]
            finding = Finding(
                severity    = severity,
                title       = f"{title}: {hostname}:{port}",
                url         = url,
                evidence    = evidence,
                module      = MODULE_NAME,
                remediation = remediation,
                tags        = ["service-exposure", str(port)],
            )
            return finding, hit

    # Probe failed entirely — port is open per port_scan but HTTP didn't respond.
    # Still emit a lower-confidence finding because the port is open.
    finding = Finding(
        severity    = "low",
        title       = f"Service port {port} open on {hostname} (no HTTP response)",
        url         = f"tcp://{hostname}:{port}",
        evidence    = "Port open per port_scan but HTTP validation probe did not respond",
        module      = MODULE_NAME,
        remediation = remediation,
        tags        = ["service-exposure", str(port), "unvalidated"],
    )
    return finding, {"host": hostname, "port": port, "validated": False,
                      "reason": "no-response"}
