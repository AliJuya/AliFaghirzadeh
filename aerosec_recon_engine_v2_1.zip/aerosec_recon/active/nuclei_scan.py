"""
AeroSecLab Recon Engine — Active: Nuclei Scanner
Tool: nuclei (ProjectDiscovery)

Runs nuclei community templates filtered to DETECTION-ONLY tags:
  cve, exposure, misconfig, tech, osint, default-logins (passive only)

Excluded: intrusive, dos, fuzz, bruteforce, takeover (we have our own takeover module).
This keeps the engine within "recon + vuln scan, no exploitation" rules.

Each nuclei finding becomes a structured Finding with severity, CVE ID,
template name, matched-at URL, and reference links.
"""

from __future__ import annotations

import json
import os
import tempfile
from pathlib import Path
from typing import Dict, List, Set

from ..core.models import ModuleReport, ReconReport, Finding
from ..core.config import get_tool, TOOL_TIMEOUT
from ..core.logger import log
from ..core.http_utils import run_tool


MODULE_NAME = "nuclei_scan"

# Map nuclei severity strings to our severity scale
SEVERITY_MAP = {
    "critical": "critical",
    "high":     "high",
    "medium":   "medium",
    "low":      "low",
    "info":     "info",
    "unknown":  "info",
}

# Tag policy: include detection-focused, exclude active exploitation
INCLUDE_TAGS = "cve,exposure,misconfig,tech,osint,exposed-panel,exposed-tokens,config,backup-files,debug,sqli-detect"
EXCLUDE_TAGS = "intrusive,dos,fuzz,bruteforce,takeover,default-login,creds-stuffing,iot"


def run(
    target     : str,
    report     : ReconReport,
    mod_report : ModuleReport,
    output_dir : Path,
):
    log("INFO", target, "Nuclei Scan — starting")

    nuclei = get_tool("nuclei")
    if not nuclei:
        log("WARN", target, "  nuclei not found — skipping. Run: go install -v github.com/projectdiscovery/nuclei/v3/cmd/nuclei@latest")
        mod_report.summary = {"skipped": "nuclei not installed"}
        return

    # Build target URL list from live hosts
    if not report.live_hosts:
        log("WARN", target, "  No live hosts to scan")
        mod_report.summary = {"skipped": "no live hosts"}
        return

    urls = sorted({h.url for h in report.live_hosts})
    if not urls:
        log("WARN", target, "  No URLs to scan")
        return

    log("INFO", target, f"  Scanning {len(urls)} live URLs with nuclei")

    # Update templates (best-effort; don't fail if offline)
    _update_templates(nuclei, target)

    # Write target list to temp file
    with tempfile.NamedTemporaryFile(mode="w", suffix=".txt", delete=False) as f:
        f.write("\n".join(urls))
        target_file = f.name

    out_file = str(output_dir / "nuclei.jsonl")

    # Run nuclei with strict detection-only configuration
    cmd = [
        nuclei,
        "-list", target_file,
        "-jsonl",
        "-output", out_file,
        # Severity gate
        "-severity", "critical,high,medium,low",
        # Tag policy
        "-tags", INCLUDE_TAGS,
        "-exclude-tags", EXCLUDE_TAGS,
        # Performance
        "-c", "25",                     # template concurrency
        "-bulk-size", "25",             # hosts per template batch
        "-rate-limit", "150",           # global RPS
        "-timeout", "10",
        "-retries", "1",
        "-max-host-error", "30",
        # Hygiene
        "-disable-update-check",
        "-no-color",
        "-silent",
        # Skip uninteresting/spammy template categories that often false-positive
        "-exclude-id", "weak-cipher-suites,ssl-issuer,ssl-dns-names,deprecated-tls,tls-version",
    ]

    log("INFO", target, f"  Running: nuclei -severity {','.join(['crit','high','med','low'])} "
        f"-tags {INCLUDE_TAGS[:40]}...")

    stdout, stderr, rc = run_tool(cmd, timeout=TOOL_TIMEOUT * 2, target=target)

    # Cleanup temp file
    try:
        os.unlink(target_file)
    except Exception:
        pass

    # Parse JSONL output
    findings: List[Finding] = []
    out_path = Path(out_file)
    if not out_path.exists() or out_path.stat().st_size == 0:
        log("WARN", target, f"  nuclei produced no output (rc={rc}). stderr: {stderr[:200]}")
        mod_report.summary = {
            "scanned_urls": len(urls),
            "findings": 0,
            "stderr_excerpt": stderr[:200],
        }
        return

    seen_keys: Set[str] = set()
    severity_counts: Dict[str, int] = {}
    template_counts: Dict[str, int] = {}

    for line in out_path.read_text().splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            entry = json.loads(line)
        except Exception:
            continue

        info       = entry.get("info", {}) or {}
        template_id= entry.get("template-id", "") or entry.get("templateID", "")
        name       = info.get("name", template_id)
        severity   = SEVERITY_MAP.get(info.get("severity", "info").lower(), "info")
        matched_at = entry.get("matched-at", "") or entry.get("matched", "") or entry.get("host", "")
        description= info.get("description", "")
        tags       = info.get("tags", [])
        if isinstance(tags, str):
            tags = [t.strip() for t in tags.split(",")]
        references = info.get("reference", []) or []
        if isinstance(references, str):
            references = [references]
        classification = info.get("classification", {}) or {}
        cve_ids    = classification.get("cve-id", []) or []
        if isinstance(cve_ids, str):
            cve_ids = [cve_ids]
        cwe_ids    = classification.get("cwe-id", []) or []
        if isinstance(cwe_ids, str):
            cwe_ids = [cwe_ids]
        cvss       = classification.get("cvss-score", "")

        # Dedupe: same template+host shouldn't repeat
        key = f"{template_id}|{matched_at}"
        if key in seen_keys:
            continue
        seen_keys.add(key)

        # Build evidence (prefer extracted-results, fall back to matcher-name + matched_at)
        extracted = entry.get("extracted-results", []) or []
        if isinstance(extracted, str):
            extracted = [extracted]
        matcher_name = entry.get("matcher-name", "")
        request_url  = entry.get("request", "")[:300] if entry.get("request") else ""

        evidence_parts = [f"Template: {template_id}", f"Matched: {matched_at}"]
        if matcher_name:
            evidence_parts.append(f"Matcher: {matcher_name}")
        if extracted:
            evidence_parts.append(f"Extracted: {', '.join(str(x)[:80] for x in extracted[:3])}")
        if cvss:
            evidence_parts.append(f"CVSS: {cvss}")
        evidence = " | ".join(evidence_parts)

        # Remediation - generic fallback if not provided
        remediation = info.get("remediation", "")
        if not remediation:
            if "cve" in tags:
                remediation = "Apply vendor patches; upgrade to a non-vulnerable version."
            elif "exposure" in tags:
                remediation = "Restrict access to this resource via authentication or IP allowlist."
            elif "misconfig" in tags:
                remediation = "Review configuration; harden per vendor security baseline."
            else:
                remediation = "Review finding and remediate per references."

        # Build a richer title with CVE if present
        title = name
        if cve_ids:
            title = f"{cve_ids[0]}: {name}"

        finding = Finding(
            severity    = severity,
            title       = title,
            url         = matched_at,
            evidence    = evidence,
            module      = MODULE_NAME,
            cve         = ", ".join(cve_ids) if cve_ids else "",
            remediation = remediation,
            tags        = ["nuclei"] + list(tags) + (["cve"] if cve_ids else []),
        )
        # Stash references and CWE in tags for the report
        if references:
            finding.tags.append(f"refs:{len(references)}")
        if cwe_ids:
            finding.tags.append(",".join(cwe_ids))

        findings.append(finding)
        severity_counts[severity] = severity_counts.get(severity, 0) + 1
        template_counts[template_id] = template_counts.get(template_id, 0) + 1

    mod_report.findings.extend(findings)

    # Summary
    mod_report.summary = {
        "scanned_urls"     : len(urls),
        "findings"         : len(findings),
        "by_severity"      : severity_counts,
        "unique_templates" : len(template_counts),
        "top_templates"    : dict(sorted(template_counts.items(),
                                         key=lambda x: x[1], reverse=True)[:15]),
        "tags_included"    : INCLUDE_TAGS.split(","),
        "tags_excluded"    : EXCLUDE_TAGS.split(","),
    }
    mod_report.data = {
        "raw_jsonl_path": str(out_path),
        "findings_preview": [
            {"sev": f.severity, "title": f.title, "url": f.url, "cve": f.cve}
            for f in findings[:50]
        ],
    }

    log("OK", target, f"  Nuclei complete: {len(findings)} findings "
        f"(critical={severity_counts.get('critical',0)} "
        f"high={severity_counts.get('high',0)} "
        f"medium={severity_counts.get('medium',0)})")


def _update_templates(nuclei_path: str, target: str):
    """Update nuclei templates (best-effort, 60s timeout)."""
    try:
        run_tool(
            [nuclei_path, "-update-templates", "-silent", "-disable-update-check"],
            timeout=60,
            target=target,
        )
        log("INFO", target, "  nuclei templates updated")
    except Exception:
        log("WARN", target, "  template update failed (continuing with cached)")
