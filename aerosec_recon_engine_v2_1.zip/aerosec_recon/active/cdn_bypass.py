"""
AeroSecLab Recon Engine — Active: CDN Bypass
Attempts to discover origin IPs behind Cloudflare, ArvanCloud, CloudFront.
Techniques: historical DNS, SPF records, email headers, direct IP probing,
subdomain enumeration for non-CDN hosts, Shodan/Censys queries.
"""

from __future__ import annotations

import re
import socket
from pathlib import Path
from typing import Dict, List, Optional, Set, Tuple

import requests

from ..core.models import (
    ModuleReport, ReconReport, Subdomain, LiveHost, Finding
)
from ..core.config import get_tool, REQUEST_TIMEOUT, SHODAN_API_KEY
from ..core.logger import log
from ..core.http_utils import safe_get, safe_request, run_tool


MODULE_NAME = "cdn_bypass"

UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"

# CDN IP ranges to identify non-origin IPs
CLOUDFLARE_RANGES = [
    "104.16.", "104.17.", "104.18.", "104.19.", "104.20.", "104.21.",
    "172.64.", "172.65.", "172.66.", "172.67.", "198.41.", "190.93.",
    "103.21.", "103.22.", "103.31.", "141.101.", "108.162.", "162.158.",
    "188.114.", "188.165.", "197.234.", "198.41.",
]

CLOUDFRONT_RANGES = [
    "13.224.", "13.225.", "13.226.", "13.227.", "13.228.", "13.229.",
    "13.32.", "13.33.", "13.34.", "13.35.", "52.84.", "52.85.",
    "52.222.", "52.223.", "54.182.", "54.192.", "54.230.", "54.239.",
    "64.252.", "70.132.", "99.84.", "99.86.",
]

ARVANCLOUD_RANGES = [
    "216.198.", "185.143.", "185.185.", "5.250.",
]


def run(
    target     : str,
    report     : ReconReport,
    mod_report : ModuleReport,
    output_dir : Path,
):
    log("INFO", target, "CDN Bypass — starting")

    origin_candidates: Dict[str, List[str]] = {}  # ip -> [techniques]

    # ── 1. Historical DNS via SecurityTrails / ViewDNS ────────────────
    historical = _historical_dns(target)
    for ip in historical:
        if not _is_cdn_ip(ip):
            origin_candidates.setdefault(ip, [])
            origin_candidates[ip].append("historical_dns")
    log("OK", target, f"  Historical DNS: {len(historical)} IPs, "
        f"{len([i for i in historical if not _is_cdn_ip(i)])} non-CDN")

    # ── 2. SPF record IP extraction ───────────────────────────────────
    spf_ips = _extract_spf_ips(target)
    for ip in spf_ips:
        if not _is_cdn_ip(ip):
            origin_candidates.setdefault(ip, [])
            origin_candidates[ip].append("spf_record")
    log("OK", target, f"  SPF IPs: {spf_ips}")

    # ── 3. MX record IP extraction ────────────────────────────────────
    mx_ips = _extract_mx_ips(target)
    for ip in mx_ips:
        if not _is_cdn_ip(ip):
            origin_candidates.setdefault(ip, [])
            origin_candidates[ip].append("mx_record")

    # ── 4. Non-CDN subdomains already discovered ──────────────────────
    for sub in report.subdomains:
        if sub.live_host and not sub.live_host.cdn:
            for ip in sub.ips:
                if not _is_cdn_ip(ip):
                    origin_candidates.setdefault(ip, [])
                    origin_candidates[ip].append(f"non-cdn subdomain: {sub.fqdn}")

    # ── 5. Shodan origin search ───────────────────────────────────────
    if SHODAN_API_KEY:
        shodan_ips = _shodan_origin_search(target)
        for ip in shodan_ips:
            if not _is_cdn_ip(ip):
                origin_candidates.setdefault(ip, [])
                origin_candidates[ip].append("shodan")
        log("OK", target, f"  Shodan: {len(shodan_ips)} candidates")

    # ── 6. Censys search ─────────────────────────────────────────────
    censys_ips = _censys_search(target)
    for ip in censys_ips:
        if not _is_cdn_ip(ip):
            origin_candidates.setdefault(ip, [])
            origin_candidates[ip].append("censys")

    # ── 7. ViewDNS reverse IP lookup ─────────────────────────────────
    for sub in report.subdomains:
        for ip in sub.ips:
            if not _is_cdn_ip(ip):
                related = _viewdns_reverse_ip(ip)
                for domain in related:
                    if domain != target and target.split(".")[-2] in domain:
                        origin_candidates.setdefault(ip, [])
                        if "viewdns_reverse" not in origin_candidates[ip]:
                            origin_candidates[ip].append("viewdns_reverse")

    # ── 8. Probe each candidate IP directly ──────────────────────────
    confirmed_origins: List[Dict] = []
    for ip, techniques in origin_candidates.items():
        result = _probe_origin(ip, target)
        if result:
            result["techniques"] = techniques
            confirmed_origins.append(result)
            log("CRIT", target,
                f"  Origin IP found: {ip} via {techniques} → "
                f"HTTP {result.get('status')}")

            mod_report.findings.append(Finding(
                severity    = "high",
                title       = f"CDN Origin IP Discovered: {ip}",
                url         = f"http://{ip}",
                evidence    = (f"IP {ip} responds to Host: {target} with "
                              f"HTTP {result.get('status')}. "
                              f"Discovered via: {', '.join(techniques)}"),
                module      = MODULE_NAME,
                remediation = (
                    "Restrict origin server to only accept connections from "
                    "CDN IP ranges. Block direct IP access in firewall rules."
                ),
                tags        = ["cdn-bypass", "origin-ip", "firewall"],
            ))

    # ── 9. Try common paths on origin IP directly ─────────────────────
    for origin in confirmed_origins[:3]:
        ip         = origin["ip"]
        bypass_findings = _probe_origin_paths(ip, target)
        mod_report.findings.extend(bypass_findings)

    # ── Summary ───────────────────────────────────────────────────────
    mod_report.summary = {
        "cdn_protected_hosts"   : sum(1 for s in report.subdomains
                                     if s.live_host and s.live_host.cdn),
        "origin_candidates"     : len(origin_candidates),
        "confirmed_origins"     : len(confirmed_origins),
        "techniques_used"       : [
            "historical_dns", "spf_records", "mx_records",
            "shodan", "censys", "viewdns_reverse",
        ],
    }
    mod_report.data = {
        "origin_candidates"  : {ip: techs for ip, techs in origin_candidates.items()},
        "confirmed_origins"  : confirmed_origins,
        "historical_dns_ips" : historical,
        "spf_ips"            : spf_ips,
        "mx_ips"             : mx_ips,
    }
    log("OK", target, f"  CDN bypass complete: {len(confirmed_origins)} origins confirmed")


# ─────────────────────────────────────────────
# TECHNIQUES
# ─────────────────────────────────────────────

def _is_cdn_ip(ip: str) -> bool:
    """Return True if IP belongs to a known CDN."""
    all_ranges = CLOUDFLARE_RANGES + CLOUDFRONT_RANGES + ARVANCLOUD_RANGES
    return any(ip.startswith(r) for r in all_ranges)


def _historical_dns(target: str) -> List[str]:
    """Query historical DNS records via ViewDNS and SecurityTrails."""
    ips = set()

    # ViewDNS.info
    try:
        r = requests.get(
            f"https://viewdns.info/iphistory/?domain={target}",
            timeout=20, headers={"User-Agent": UA}
        )
        if r.ok:
            matches = re.findall(r'\b(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})\b', r.text)
            for ip in matches:
                # Basic validation
                parts = ip.split(".")
                if all(0 <= int(p) <= 255 for p in parts):
                    ips.add(ip)
    except Exception:
        pass

    # HackerTarget passive DNS
    try:
        r = requests.get(
            f"https://api.hackertarget.com/reverseiplookup/?q={target}",
            timeout=20, headers={"User-Agent": UA}
        )
        if r.ok:
            for line in r.text.splitlines():
                ip_m = re.search(r'\b(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})\b', line)
                if ip_m:
                    ips.add(ip_m.group(1))
    except Exception:
        pass

    # Netcraft
    try:
        r = requests.get(
            f"https://toolbar.netcraft.com/site_report?url={target}",
            timeout=20, headers={"User-Agent": UA}
        )
        if r.ok:
            matches = re.findall(r'\b(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})\b', r.text)
            ips.update(matches)
    except Exception:
        pass

    return list(ips)


def _extract_spf_ips(target: str) -> List[str]:
    """Extract IP ranges from SPF TXT record."""
    ips = []
    dig = get_tool("dig")
    if not dig:
        return ips

    stdout, _, _ = run_tool(
        [dig, "+short", "TXT", target],
        timeout=15,
    )

    for line in stdout.splitlines():
        if "v=spf1" in line.lower():
            # Extract ip4: entries
            for match in re.findall(r'ip4:(\S+)', line):
                ip = match.split("/")[0]
                ips.append(ip)
            # Resolve include: entries
            for include in re.findall(r'include:(\S+)', line):
                stdout2, _, _ = run_tool(
                    [dig, "+short", "TXT", include],
                    timeout=10,
                )
                for m in re.findall(r'ip4:(\S+)', stdout2):
                    ips.append(m.split("/")[0])

    return list(set(ips))


def _extract_mx_ips(target: str) -> List[str]:
    """Resolve MX record hostnames to IPs."""
    ips = []
    dig = get_tool("dig")
    if not dig:
        return ips

    stdout, _, _ = run_tool(
        [dig, "+short", "MX", target],
        timeout=15,
    )

    for line in stdout.splitlines():
        parts = line.strip().split()
        if len(parts) >= 2:
            mx_host = parts[-1].rstrip(".")
            try:
                ip = socket.gethostbyname(mx_host)
                if ip:
                    ips.append(ip)
            except Exception:
                pass

    return list(set(ips))


def _viewdns_reverse_ip(ip: str) -> List[str]:
    """Find other domains hosted on the same IP via ViewDNS."""
    domains = []
    try:
        r = requests.get(
            f"https://api.hackertarget.com/reverseiplookup/?q={ip}",
            timeout=20, headers={"User-Agent": UA}
        )
        if r.ok and "API count exceeded" not in r.text:
            for line in r.text.splitlines():
                line = line.strip()
                if line and "." in line and not line.startswith("ERROR"):
                    domains.append(line.lower())
    except Exception:
        pass
    return domains[:50]


def _shodan_origin_search(target: str) -> List[str]:
    """Search Shodan for hosts with the target domain in their SSL cert."""
    ips = []
    try:
        queries = [
            f"ssl:{target}",
            f"hostname:{target}",
            f"http.host:{target}",
        ]
        for query in queries:
            r = requests.get(
                "https://api.shodan.io/shodan/host/search",
                params={"key": SHODAN_API_KEY, "query": query},
                timeout=20, headers={"User-Agent": UA}
            )
            if r.ok:
                for match in r.json().get("matches", []):
                    ip = match.get("ip_str", "")
                    if ip:
                        ips.append(ip)
    except Exception:
        pass
    return list(set(ips))


def _censys_search(target: str) -> List[str]:
    """Search Censys for hosts related to the target (no auth needed for basic)."""
    ips = []
    try:
        r = requests.get(
            "https://search.censys.io/api/v1/search/ipv4",
            json={
                "query": f"parsed.names:{target}",
                "page" : 1,
                "fields": ["ip"],
            },
            timeout=20, headers={"User-Agent": UA}
        )
        if r.ok:
            for result in r.json().get("results", []):
                ip = result.get("ip", "")
                if ip:
                    ips.append(ip)
    except Exception:
        pass
    return ips


def _probe_origin(ip: str, target: str) -> Optional[Dict]:
    """Probe an IP directly using Host header injection to confirm origin."""
    for scheme in ["https", "http"]:
        for port in ([443, 80] if scheme == "https" else [80, 8080, 8443]):
            url = f"{scheme}://{ip}:{port}" if port not in (80, 443) else f"{scheme}://{ip}"
            try:
                r = safe_get(
                    url,
                    extra_headers={"Host": target},
                    allow_redirects=True,
                    timeout=8,
                )
                if r and r.status_code not in (0, None):
                    return {
                        "ip"     : ip,
                        "port"   : port,
                        "scheme" : scheme,
                        "status" : r.status_code,
                        "server" : r.headers.get("server", ""),
                        "title"  : _extract_title_quick(r.text),
                    }
            except Exception:
                pass
    return None


def _probe_origin_paths(ip: str, target: str) -> List[Finding]:
    """Check if origin bypasses WAF for sensitive paths."""
    findings = []
    sensitive = [
        "/.env", "/.git/HEAD", "/admin", "/admin/init",
        "/actuator/env", "/api/users",
    ]
    for path in sensitive:
        for scheme in ["https", "http"]:
            url = f"{scheme}://{ip}{path}"
            r   = safe_get(url, extra_headers={"Host": target})
            if r and r.status_code == 200:
                ct = r.headers.get("content-type", "").lower()
                if "text/html" not in ct or path in ("/.env", "/.git/HEAD"):
                    findings.append(Finding(
                        severity    = "high",
                        title       = f"Sensitive path accessible via origin bypass: {path}",
                        url         = url,
                        evidence    = f"Direct IP {ip} returns {r.status_code} for {path} (WAF bypassed)",
                        module      = MODULE_NAME,
                        remediation = "Implement firewall rules to block direct IP access to origin",
                        tags        = ["cdn-bypass", "waf-bypass", "origin"],
                    ))
    return findings


def _extract_title_quick(html: str) -> str:
    m = re.search(r'<title[^>]*>(.*?)</title>', html, re.I | re.S)
    return re.sub(r'\s+', ' ', m.group(1)).strip()[:80] if m else ""
