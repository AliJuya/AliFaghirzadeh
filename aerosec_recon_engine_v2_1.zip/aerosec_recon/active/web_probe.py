"""
AeroSecLab Recon Engine — Active: Web Probe
Tools: httpx, whatweb, wafw00f
Probes all subdomains for live web services, fingerprints tech stack,
detects CDN/WAF, extracts headers, SSL info, and security misconfigs.
"""

from __future__ import annotations

import concurrent.futures
import json
import re
import struct
import socket
import time
from pathlib import Path
from typing import Dict, List, Optional, Set, Tuple

from ..core.models import (
    ModuleReport, ReconReport, Subdomain, LiveHost, TechStack,
    Finding, Certificate
)
from ..core.config import (
    get_tool, TOOL_TIMEOUT, MAX_THREADS_SUBDOMAIN_PROBE,
    EXCHANGE_SUBDOMAINS, REQUEST_TIMEOUT, USER_AGENTS,
)
from ..core.logger import log, progress
from ..core.http_utils import (
    safe_get, safe_request, extract_title, snippet,
    get_cookies_list, detect_cdn, detect_waf, is_spa,
    get_certificate, decode_f5_cookie, run_tool, make_session,
)


MODULE_NAME = "web_probe"


def run(
    target     : str,
    report     : ReconReport,
    mod_report : ModuleReport,
    output_dir : Path,
):
    log("INFO", target, "Web Probe — starting")

    all_fqdns = list({s.fqdn for s in report.subdomains})
    # Also add exchange-specific prefixes not yet discovered
    for prefix in EXCHANGE_SUBDOMAINS:
        fqdn = f"{prefix}.{target}"
        if fqdn not in all_fqdns:
            all_fqdns.append(fqdn)
    all_fqdns.append(target)
    all_fqdns.append(f"www.{target}")
    all_fqdns = list(set(all_fqdns))

    log("INFO", target, f"  Probing {len(all_fqdns)} FQDNs...")

    # ── httpx for fast bulk probing ───────────────────────────────────
    if get_tool("httpx"):
        live_hosts = _run_httpx(all_fqdns, target, output_dir)
    else:
        live_hosts = _probe_with_requests(all_fqdns, target)

    log("OK", target, f"  {len(live_hosts)} live web hosts found")

    # ── Deep fingerprinting on each live host ─────────────────────────
    with concurrent.futures.ThreadPoolExecutor(max_workers=20) as ex:
        futures = {ex.submit(_fingerprint_host, host, target): host
                   for host in live_hosts}
        done = 0
        for f in concurrent.futures.as_completed(futures):
            done += 1
            host = futures[f]
            try:
                enriched = f.result()
                if enriched:
                    # Replace with enriched version
                    for i, h in enumerate(live_hosts):
                        if h.fqdn == enriched.fqdn:
                            live_hosts[i] = enriched
                            break
            except Exception:
                pass
            if done % 5 == 0:
                progress(done, len(live_hosts), "fingerprinting")

    # ── whatweb for additional tech detection ─────────────────────────
    if get_tool("whatweb"):
        whatweb_results = _run_whatweb(
            [h.url for h in live_hosts[:30]], output_dir, target
        )
        _merge_whatweb(live_hosts, whatweb_results)

    # ── wafw00f for WAF detection ──────────────────────────────────────
    if get_tool("wafw00f"):
        waf_results = _run_wafw00f(
            [h.url for h in live_hosts[:20]], output_dir, target
        )
        for host in live_hosts:
            if host.url in waf_results:
                host.waf = waf_results[host.url]

    # ── Generate security findings for each host ──────────────────────
    all_findings = []
    for host in live_hosts:
        host_findings = _security_checks(host, target)
        all_findings.extend(host_findings)

    mod_report.findings.extend(all_findings)

    # ── Attach live hosts to report and subdomains ────────────────────
    report.live_hosts = live_hosts

    # Attach to corresponding subdomain objects
    live_map = {h.fqdn: h for h in live_hosts}
    for sub in report.subdomains:
        if sub.fqdn in live_map:
            sub.live_host = live_map[sub.fqdn]

    # ── Summary ───────────────────────────────────────────────────────
    tech_freq: Dict[str, int] = {}
    for host in live_hosts:
        for tech in host.tech:
            tech_freq[tech.name] = tech_freq.get(tech.name, 0) + 1

    mod_report.summary = {
        "total_probed"  : len(all_fqdns),
        "live_hosts"    : len(live_hosts),
        "status_codes"  : _count_status_codes(live_hosts),
        "cdn_breakdown" : _count_cdn(live_hosts),
        "waf_breakdown" : _count_waf(live_hosts),
        "top_tech"      : dict(sorted(tech_freq.items(),
                                      key=lambda x: x[1], reverse=True)[:15]),
        "spa_hosts"     : sum(1 for h in live_hosts if h.is_spa),
        "findings"      : len(all_findings),
    }
    mod_report.data = {
        "live_hosts": [
            {
                "fqdn"      : h.fqdn,
                "url"       : h.url,
                "status"    : h.status,
                "title"     : h.title,
                "server"    : h.server,
                "cdn"       : h.cdn,
                "waf"       : h.waf,
                "tech"      : [t.name for t in h.tech],
                "is_spa"    : h.is_spa,
                "ports"     : [{"port": p.port, "service": p.service}
                               for p in h.ports],
            }
            for h in sorted(live_hosts, key=lambda x: x.fqdn)
        ]
    }
    log("OK", target, f"  Web probe complete: {len(live_hosts)} live, {len(all_findings)} findings")


# ─────────────────────────────────────────────
# HTTPX
# ─────────────────────────────────────────────

def _run_httpx(
    fqdns     : List[str],
    target    : str,
    output_dir: Path,
) -> List[LiveHost]:
    live     = []
    httpx    = get_tool("httpx")
    out_file = str(output_dir / "httpx.json")

    import tempfile
    with tempfile.NamedTemporaryFile(mode="w", suffix=".txt", delete=False) as f:
        f.write("\n".join(fqdns))
        input_file = f.name

    stdout, stderr, rc = run_tool(
        [
            httpx,
            "-l", input_file,
            "-json",
            "-o", out_file,
            "-title",
            "-server",
            "-status-code",
            "-tech-detect",
            "-cdn",
            "-ip",
            "-cname",
            "-location",
            "-follow-redirects",
            "-max-redirects", "5",
            "-threads", "100",
            "-timeout", str(REQUEST_TIMEOUT),
            "-retries", "2",
            "-silent",
            "-favicon",
            "-hash", "md5",
        ],
        timeout=TOOL_TIMEOUT,
        target=target,
    )

    out_path = Path(out_file)
    if out_path.exists():
        for line in out_path.read_text().splitlines():
            try:
                entry = json.loads(line)
                host  = _httpx_entry_to_livehost(entry)
                if host:
                    live.append(host)
            except Exception:
                pass

    import os
    try:
        os.unlink(input_file)
    except Exception:
        pass

    return live


def _httpx_entry_to_livehost(entry: dict) -> Optional[LiveHost]:
    url    = entry.get("url", "") or entry.get("input", "")
    status = entry.get("status_code", 0)
    if not url or not status:
        return None

    from urllib.parse import urlparse
    parsed = urlparse(url)
    fqdn   = parsed.netloc.split(":")[0]

    # Tech stack from httpx
    tech_list = []
    for tech_name in entry.get("technologies", []):
        tech_list.append(TechStack(name=tech_name))

    return LiveHost(
        fqdn         = fqdn,
        url          = url,
        final_url    = entry.get("final_url", url),
        ip           = entry.get("host", ""),
        status       = status,
        server       = entry.get("webserver", ""),
        powered_by   = "",
        cdn          = "cloudflare" if entry.get("cdn", False) else "",
        title        = entry.get("title", ""),
        scheme       = parsed.scheme,
        tech         = tech_list,
        redirect_chain= entry.get("chain_status_codes", []),
    )


# ─────────────────────────────────────────────
# REQUESTS FALLBACK PROBING
# ─────────────────────────────────────────────

def _probe_with_requests(fqdns: List[str], target: str) -> List[LiveHost]:
    live = []
    done = 0

    def probe(fqdn: str) -> Optional[LiveHost]:
        for scheme in ["https", "http"]:
            url = f"{scheme}://{fqdn}"
            r   = safe_get(url, allow_redirects=True, timeout=REQUEST_TIMEOUT)
            if r is None:
                continue

            server  = r.headers.get("server", "")
            powered = r.headers.get("x-powered-by", "")
            cdn     = detect_cdn(r)

            # Resolve IP
            try:
                ip = socket.gethostbyname(fqdn)
            except Exception:
                ip = ""

            return LiveHost(
                fqdn      = fqdn,
                url       = url,
                final_url = r.url,
                ip        = ip,
                status    = r.status_code,
                server    = server,
                powered_by= powered,
                cdn       = cdn,
                title     = extract_title(r.text),
                scheme    = scheme,
                headers   = dict(r.headers),
                cookies   = get_cookies_list(r),
            )
        return None

    with concurrent.futures.ThreadPoolExecutor(
        max_workers=MAX_THREADS_SUBDOMAIN_PROBE
    ) as ex:
        futures = {ex.submit(probe, fqdn): fqdn for fqdn in fqdns}
        for f in concurrent.futures.as_completed(futures):
            done += 1
            if done % 10 == 0:
                progress(done, len(fqdns), "probing")
            result = f.result()
            if result:
                live.append(result)

    return live


# ─────────────────────────────────────────────
# DEEP FINGERPRINTING
# ─────────────────────────────────────────────

def _fingerprint_host(host: LiveHost, target: str) -> LiveHost:
    """Deep fingerprint a live host — tech stack, SSL, SPA detection."""
    # Skip duplicate fetch if httpx already populated headers AND we have body indicators
    # We still need a body for tech detection, so always fetch but with a short timeout
    r = safe_get(host.url, allow_redirects=True, timeout=8)
    if r is None:
        # We may have headers from httpx already; use them with empty body
        if not host.headers:
            return host
        host.waf = host.waf or _waf_from_headers(host.headers)
        return host

    body      = r.text[:100000]
    h_str     = json.dumps(dict(r.headers)).lower()
    # Merge headers (don't overwrite if httpx already set them)
    if not host.headers:
        host.headers = dict(r.headers)
    host.cookies = get_cookies_list(r)

    # Update CDN and WAF
    if not host.cdn:
        host.cdn = detect_cdn(r)
    if not host.waf:
        host.waf = detect_waf(r, body)

    # SPA detection
    host.is_spa = is_spa(host.url)

    # Tech detection
    host.tech = _detect_tech(body, h_str, host, r)

    # SSL certificate
    if host.scheme == "https":
        from urllib.parse import urlparse
        parsed   = urlparse(host.url)
        hostname = parsed.netloc.split(":")[0]
        port     = parsed.port or 443
        cert     = get_certificate(hostname, port)
        if cert:
            host.cert = cert

    return host


def _waf_from_headers(headers: Dict[str, str]) -> str:
    """Quick WAF guess from headers when no body is available."""
    h_str = json.dumps(dict(headers)).lower()
    from ..core.config import WAF_FINGERPRINTS
    for waf_name, markers in WAF_FINGERPRINTS.items():
        if any(m.lower() in h_str for m in markers):
            return waf_name
    return ""


def _detect_tech(
    body  : str,
    h_str : str,
    host  : LiveHost,
    r,
) -> List[TechStack]:
    tech   = list(host.tech)  # Preserve existing tech from httpx
    body_l = body.lower()
    added  = {t.name for t in tech}

    def add(name: str, version: str = "", category: str = "", conf: int = 80):
        if name not in added:
            tech.append(TechStack(name=name, version=version,
                                  category=category, confidence=conf))
            added.add(name)

    # ── CMS ──
    if "strapi" in h_str or "strapi" in body_l:
        ver = ""
        r2  = safe_get(f"{host.url}/admin/init")
        if r2 and r2.ok:
            try:
                d = r2.json()
                add("Strapi CMS", category="cms")
                has_admin = d.get("data", {}).get("hasAdmin", False)
                uuid      = d.get("data", {}).get("uuid", "")
                add(f"Strapi Admin Panel (hasAdmin:{has_admin})", category="finding")
            except Exception:
                add("Strapi CMS", category="cms")

    if "wp-content" in body or "wp-json" in body or "wordpress" in body_l:
        # Get WP version
        ver = ""
        vm  = re.search(r'<meta name="generator" content="WordPress ([^"]+)"', body)
        if vm:
            ver = vm.group(1)
        add("WordPress", version=ver, category="cms")

        # User enumeration check
        r_users = safe_get(f"{host.url}/wp-json/wp/v2/users")
        if r_users and r_users.ok:
            try:
                users = r_users.json()
                if isinstance(users, list) and users:
                    names = [u.get("slug", "") for u in users[:5]]
                    add(f"WordPress Users Exposed: {names}", category="finding")
            except Exception:
                pass

    if "gitlab" in body_l or "gitlab" in host.title.lower():
        add("GitLab", category="devops")
    if "jenkins" in body_l:
        add("Jenkins", category="devops")
    if "grafana" in body_l:
        add("Grafana", category="monitoring")
    if "kibana" in body_l:
        add("Kibana", category="monitoring")
    if "jira" in body_l:
        add("Jira", category="project-management")

    # ── Backend ──
    if "express" in h_str or "node" in h_str:
        add("Node.js/Express", category="backend")
    if "php" in h_str or ".php" in body:
        add("PHP", category="backend")
    if "django" in h_str or "csrfmiddlewaretoken" in body:
        add("Django", category="backend")
    if "ci_session" in h_str or "codeigniter" in body_l:
        add("CodeIgniter", category="backend")
    if "laravel" in body_l or "laravel_session" in h_str:
        add("Laravel", category="backend")
    if "ruby on rails" in body_l or "x-powered-by" in h_str and "rails" in h_str:
        add("Ruby on Rails", category="backend")
    if "spring" in h_str or ("x-xss-protection" in h_str and "pragma" in h_str):
        add("Spring Boot", category="backend")
    if "aspnet" in h_str or "asp.net" in h_str or "__viewstate" in body_l:
        add("ASP.NET", category="backend")
    if "nginx" in h_str:
        ver_m = re.search(r'nginx/([0-9.]+)', h_str)
        add("nginx", version=ver_m.group(1) if ver_m else "", category="server")
    if "apache" in h_str:
        ver_m = re.search(r'apache/([0-9.]+)', h_str)
        add("Apache", version=ver_m.group(1) if ver_m else "", category="server")

    # ── Frontend ──
    for fw, pattern in [
        ("React",      r'react|__NEXT_DATA__|_app\.js|reactdom'),
        ("Angular",    r'ng-version=|angular\.js|angular\.min\.js'),
        ("Vue.js",     r'vue\.js|vue\.min\.js|__vue__'),
        ("Next.js",    r'__NEXT_DATA__|_next/static'),
        ("Nuxt.js",    r'__nuxt|nuxt\.js|_nuxt/'),
        ("Svelte",     r'svelte|__svelte'),
        ("jQuery",     r'jquery[.-][0-9]'),
        ("Bootstrap",  r'bootstrap[.-][0-9]|bootstrap\.min'),
    ]:
        if re.search(pattern, body, re.I):
            add(fw, category="frontend")

    # ── Database/Search ──
    if "elasticsearch" in body_l or '"hits"' in body:
        add("Elasticsearch", category="database")
    if "mongodb" in body_l:
        add("MongoDB", category="database")

    # ── CDN/WAF ──
    if host.cdn:
        add(f"{host.cdn.title()} CDN", category="cdn")
    if host.waf:
        add(f"{host.waf.title()} WAF", category="waf")

    # ── Missing security headers (as tech findings) ──
    missing = [h for h in [
        "content-security-policy", "x-frame-options",
        "strict-transport-security", "x-content-type-options",
        "referrer-policy", "permissions-policy"
    ] if h not in h_str]
    if missing:
        add(f"Missing headers: {', '.join(missing)}", category="security", conf=100)

    return tech


# ─────────────────────────────────────────────
# WHATWEB
# ─────────────────────────────────────────────

def _run_whatweb(
    urls      : List[str],
    output_dir: Path,
    target    : str,
) -> Dict[str, List[str]]:
    results  = {}
    whatweb  = get_tool("whatweb")
    out_file = str(output_dir / "whatweb.json")

    stdout, _, _ = run_tool(
        [whatweb, "--log-json", out_file, "-a", "3", "--no-errors"] + urls[:20],
        timeout=120,
        target=target,
    )

    out_path = Path(out_file)
    if out_path.exists():
        for line in out_path.read_text().splitlines():
            try:
                entry = json.loads(line)
                url   = entry.get("target", "")
                techs = [p.get("name", "") for p in entry.get("plugins", {}).values()
                        if isinstance(p, dict)]
                if url:
                    results[url] = techs
            except Exception:
                pass
    return results


def _merge_whatweb(live_hosts: List[LiveHost], whatweb_results: Dict[str, List[str]]):
    for host in live_hosts:
        techs = whatweb_results.get(host.url, [])
        existing = {t.name for t in host.tech}
        for tech_name in techs:
            if tech_name and tech_name not in existing:
                host.tech.append(TechStack(name=tech_name, category="whatweb"))
                existing.add(tech_name)


# ─────────────────────────────────────────────
# WAFW00F
# ─────────────────────────────────────────────

def _run_wafw00f(
    urls      : List[str],
    output_dir: Path,
    target    : str,
) -> Dict[str, str]:
    """
    Parallel wafw00f probing. Each URL gets its own output file (no overwrite).
    Hard per-URL timeout of 25s. Skips URLs we already detected via headers.
    """
    results  = {}
    wafw00f  = get_tool("wafw00f")
    if not wafw00f:
        return results

    waf_dir = output_dir / "wafw00f"
    waf_dir.mkdir(exist_ok=True)

    def _probe_one(url: str) -> Tuple[str, str]:
        # sanitize url for filename
        safe = re.sub(r'[^a-zA-Z0-9]+', '_', url)[:80]
        out_file = str(waf_dir / f"{safe}.json")
        # -i 1: only one attempt, much faster than default
        # -f json: machine-readable output
        stdout, stderr, rc = run_tool(
            [wafw00f, "-f", "json", "-o", out_file, url],
            timeout=25,
            target=target,
        )
        # Try to parse JSON output first (most reliable)
        try:
            from pathlib import Path as _P
            p = _P(out_file)
            if p.exists() and p.stat().st_size > 0:
                data = json.loads(p.read_text())
                if isinstance(data, list) and data:
                    entry = data[0]
                    if entry.get("detected"):
                        firewall = entry.get("firewall", "")
                        manuf    = entry.get("manufacturer", "")
                        if firewall:
                            return url, f"{firewall} ({manuf})" if manuf else firewall
        except Exception:
            pass
        # Fallback: parse stdout
        if "is behind" in stdout.lower():
            m = re.search(r'is behind\s+(.+?)(?:\s+WAF|\s+\(|$)', stdout, re.I)
            if m:
                return url, m.group(1).strip()
        return url, ""

    with concurrent.futures.ThreadPoolExecutor(max_workers=8) as ex:
        futures = {ex.submit(_probe_one, u): u for u in urls[:15]}
        for f in concurrent.futures.as_completed(futures, timeout=300):
            try:
                url, waf = f.result(timeout=30)
                if waf:
                    results[url] = waf
            except Exception:
                pass
    return results


# ─────────────────────────────────────────────
# SECURITY CHECKS
# ─────────────────────────────────────────────

def _security_checks(host: LiveHost, target: str) -> List[Finding]:
    findings = []
    h        = host.headers
    h_str    = json.dumps(h).lower()

    # ── Security headers ──────────────────────────────────────────────
    if "text/html" in h.get("Content-Type", h.get("content-type", "")).lower():
        for hdr, sev, msg in [
            ("Content-Security-Policy",  "low",    "CSP header missing"),
            ("X-Frame-Options",          "low",    "X-Frame-Options missing — clickjacking risk"),
        ]:
            if hdr not in h and hdr.lower() not in h_str:
                findings.append(Finding(
                    severity    = sev, title=msg, url=host.url,
                    evidence    = f"{hdr} not present in response headers",
                    module      = MODULE_NAME,
                    remediation = f"Add {hdr} header to all HTML responses",
                    tags        = ["headers", "missing-header"],
                ))

    for hdr, sev, msg in [
        ("X-Content-Type-Options", "low",  "X-Content-Type-Options missing"),
        ("Referrer-Policy",        "low",  "Referrer-Policy missing"),
    ]:
        if hdr not in h and hdr.lower() not in h_str:
            findings.append(Finding(
                severity    = sev, title=msg, url=host.url,
                evidence    = f"{hdr} not present",
                module      = MODULE_NAME,
                remediation = f"Add {hdr} header",
                tags        = ["headers"],
            ))

    if host.scheme == "https" and "strict-transport-security" not in h_str:
        findings.append(Finding(
            severity    = "low",
            title       = "HSTS not configured",
            url         = host.url,
            evidence    = "Strict-Transport-Security header missing on HTTPS",
            module      = MODULE_NAME,
            remediation = "Add: Strict-Transport-Security: max-age=31536000; includeSubDomains; preload",
            tags        = ["headers", "hsts"],
        ))

    # ── Server version disclosure ─────────────────────────────────────
    server = h.get("Server", h.get("server", ""))
    if server and re.search(r'[0-9]', server):
        findings.append(Finding(
            severity    = "info",
            title       = "Server version disclosed",
            url         = host.url,
            evidence    = f"Server: {server}",
            module      = MODULE_NAME,
            remediation = "Remove version info from Server header",
            tags        = ["info-disclosure", "server"],
        ))

    powered = h.get("X-Powered-By", h.get("x-powered-by", ""))
    if powered:
        findings.append(Finding(
            severity    = "info",
            title       = "X-Powered-By leaks technology",
            url         = host.url,
            evidence    = f"X-Powered-By: {powered}",
            module      = MODULE_NAME,
            remediation = "Remove X-Powered-By header",
            tags        = ["info-disclosure"],
        ))

    # ── Cookie security ───────────────────────────────────────────────
    for cookie in host.cookies:
        if not cookie:
            continue
        lower = cookie.lower()
        name  = cookie.split("=", 1)[0].strip()

        if "httponly" not in lower:
            findings.append(Finding(
                severity    = "medium",
                title       = f"Cookie '{name}' missing HttpOnly flag",
                url         = host.url,
                evidence    = cookie[:150],
                module      = MODULE_NAME,
                remediation = "Add HttpOnly flag to prevent XSS cookie theft",
                tags        = ["cookie", "httponly"],
            ))
        if host.scheme == "https" and "secure" not in lower:
            findings.append(Finding(
                severity    = "medium",
                title       = f"Cookie '{name}' missing Secure flag",
                url         = host.url,
                evidence    = cookie[:150],
                module      = MODULE_NAME,
                remediation = "Add Secure flag to prevent transmission over HTTP",
                tags        = ["cookie", "secure"],
            ))
        if "samesite" not in lower:
            findings.append(Finding(
                severity    = "low",
                title       = f"Cookie '{name}' missing SameSite attribute",
                url         = host.url,
                evidence    = cookie[:150],
                module      = MODULE_NAME,
                remediation = "Add SameSite=Strict or Lax to prevent CSRF",
                tags        = ["cookie", "csrf"],
            ))

        # F5 BIG-IP persistence cookie decode
        if re.match(r'^TS[0-9a-f]{8}$', name, re.I):
            val = cookie.split("=", 1)[1].split(";")[0].strip() if "=" in cookie else ""
            if val and len(val) > 14:
                decoded = decode_f5_cookie(val)
                if decoded:
                    ip, port = decoded
                    findings.append(Finding(
                        severity    = "medium",
                        title       = "F5 BIG-IP cookie reveals internal server IP",
                        url         = host.url,
                        evidence    = f"Cookie {name} decodes to internal origin: {ip}:{port}",
                        module      = MODULE_NAME,
                        remediation = "Configure F5 to use encrypted or hash-based cookie persistence",
                        tags        = ["f5", "info-disclosure", "internal-ip"],
                    ))

        # CodeIgniter session
        if "ci_session" in name.lower():
            findings.append(Finding(
                severity    = "medium",
                title       = "CodeIgniter session cookie detected",
                url         = host.url,
                evidence    = f"ci_session: {cookie[:80]}",
                module      = MODULE_NAME,
                remediation = "Verify CI encryption key strength; test for deserialization vulnerabilities",
                tags        = ["codeigniter", "session"],
            ))

    # ── CORS check ────────────────────────────────────────────────────
    r_cors, _ = safe_request(
        "GET", f"{host.url}/",
        extra_headers={"Origin": "https://evil.aeroseclab.com"}
    )
    if r_cors:
        acao = r_cors.headers.get("Access-Control-Allow-Origin", "")
        acac = r_cors.headers.get("Access-Control-Allow-Credentials", "").lower()

        if acao == "*" and acac == "true":
            findings.append(Finding(
                severity    = "high",
                title       = "CORS: wildcard origin + credentials allowed",
                url         = host.url,
                evidence    = "ACAO: * with ACAC: true",
                module      = MODULE_NAME,
                remediation = "Never use wildcard ACAO with credentials — specify explicit origins",
                tags        = ["cors", "credentials"],
            ))
        elif acao == "https://evil.aeroseclab.com" and acac == "true":
            findings.append(Finding(
                severity    = "high",
                title       = "CORS: arbitrary origin reflected with credentials",
                url         = host.url,
                evidence    = f"Reflected origin: {acao}, ACAC: true",
                module      = MODULE_NAME,
                remediation = "Validate Origin against allowlist before reflecting",
                tags        = ["cors", "credentials", "origin-reflection"],
            ))
        elif acao == "*":
            findings.append(Finding(
                severity    = "medium",
                title       = "CORS: wildcard origin policy",
                url         = host.url,
                evidence    = "Access-Control-Allow-Origin: *",
                module      = MODULE_NAME,
                remediation = "Restrict CORS to known trusted origins",
                tags        = ["cors"],
            ))
        elif acao == "https://evil.aeroseclab.com":
            findings.append(Finding(
                severity    = "medium",
                title       = "CORS: arbitrary origin reflected (no credentials)",
                url         = host.url,
                evidence    = f"Reflected: {acao}",
                module      = MODULE_NAME,
                tags        = ["cors"],
            ))

    # ── HTTP TRACE ────────────────────────────────────────────────────
    r_trace, _ = safe_request("TRACE", f"{host.url}/")
    if r_trace and r_trace.status_code not in {400, 403, 405, 501}:
        findings.append(Finding(
            severity    = "medium",
            title       = "HTTP TRACE method enabled",
            url         = host.url,
            evidence    = f"TRACE returned HTTP {r_trace.status_code}",
            module      = MODULE_NAME,
            remediation = "Disable TRACE method in web server configuration",
            tags        = ["http-method", "trace"],
        ))

    # ── SSL certificate findings ──────────────────────────────────────
    if host.cert:
        if host.cert.expired:
            findings.append(Finding(
                severity    = "high",
                title       = "SSL certificate expired",
                url         = host.url,
                evidence    = f"Valid to: {host.cert.valid_to}",
                module      = MODULE_NAME,
                remediation = "Renew SSL certificate immediately",
                tags        = ["ssl", "expired"],
            ))
        if host.cert.self_signed:
            findings.append(Finding(
                severity    = "medium",
                title       = "Self-signed SSL certificate",
                url         = host.url,
                evidence    = f"Subject == Issuer: {host.cert.subject}",
                module      = MODULE_NAME,
                remediation = "Replace with a certificate signed by a trusted CA",
                tags        = ["ssl", "self-signed"],
            ))

    return findings


# ─────────────────────────────────────────────
# STATS HELPERS
# ─────────────────────────────────────────────

def _count_status_codes(hosts: List[LiveHost]) -> Dict[str, int]:
    counts: Dict[str, int] = {}
    for h in hosts:
        key = str(h.status)
        counts[key] = counts.get(key, 0) + 1
    return counts


def _count_cdn(hosts: List[LiveHost]) -> Dict[str, int]:
    counts: Dict[str, int] = {}
    for h in hosts:
        key = h.cdn or "none"
        counts[key] = counts.get(key, 0) + 1
    return counts


def _count_waf(hosts: List[LiveHost]) -> Dict[str, int]:
    counts: Dict[str, int] = {}
    for h in hosts:
        key = h.waf or "none"
        counts[key] = counts.get(key, 0) + 1
    return counts
