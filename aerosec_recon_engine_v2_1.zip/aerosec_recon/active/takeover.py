"""
AeroSecLab Recon Engine — Active: Subdomain Takeover Detection

Checks CNAMEs of discovered subdomains against a curated fingerprint database
to detect dangling DNS records pointing to abandoned cloud services.

Detection-only — does NOT attempt to claim/register any resource. Findings
report the vulnerability so the asset owner can fix it.

Fingerprint database is a maintained subset of github.com/EdOverflow/can-i-take-over-xyz
plus current Microsoft Azure / AWS / GCP service patterns.
"""

from __future__ import annotations

import re
import socket
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from ..core.models import ModuleReport, ReconReport, Finding
from ..core.config import REQUEST_TIMEOUT
from ..core.logger import log
from ..core.http_utils import safe_get, run_tool
from ..core.config import get_tool


MODULE_NAME = "takeover"


# Each entry: (vendor, cname_pattern_regex, response_fingerprint_regex_or_None,
#              status_code_or_None, severity, notes)
# If response_fingerprint is None, just the dangling CNAME is enough to flag.
FINGERPRINTS: List[Dict] = [
    # AWS
    {
        "vendor": "AWS S3",
        "cname": r"\.s3([.-][a-z0-9-]+)?\.amazonaws\.com$",
        "body":  r"NoSuchBucket|The specified bucket does not exist|BucketAlreadyExists",
        "status": None,
        "severity": "high",
        "notes": "S3 bucket may be claimable. Verify the bucket is unowned before flagging as critical.",
    },
    {
        "vendor": "AWS CloudFront",
        "cname": r"\.cloudfront\.net$",
        "body":  r"Bad request\.|ERROR: The request could not be satisfied",
        "status": 403,
        "severity": "medium",
        "notes": "CloudFront distribution may be misconfigured or removed.",
    },
    {
        "vendor": "AWS Elastic Beanstalk",
        "cname": r"\.elasticbeanstalk\.com$",
        "body":  None,
        "status": None,
        "severity": "high",
        "notes": "Verify EB environment exists; if not, name may be claimable.",
    },
    # Azure
    {
        "vendor": "Azure App Service",
        "cname": r"\.azurewebsites\.net$",
        "body":  r"404 Web Site not found|Error 404 - Web app not found",
        "status": 404,
        "severity": "high",
        "notes": "Azure App Service may be claimable.",
    },
    {
        "vendor": "Azure Cloud App",
        "cname": r"\.cloudapp\.net$|\.cloudapp\.azure\.com$",
        "body":  None,
        "status": None,
        "severity": "high",
        "notes": "Verify Azure cloud service exists.",
    },
    {
        "vendor": "Azure CDN",
        "cname": r"\.azureedge\.net$",
        "body":  None,
        "status": None,
        "severity": "medium",
        "notes": "Azure CDN endpoint check required.",
    },
    {
        "vendor": "Azure TrafficManager",
        "cname": r"\.trafficmanager\.net$",
        "body":  None,
        "status": None,
        "severity": "high",
        "notes": "Traffic Manager profile may be deleted; profile name is claimable.",
    },
    {
        "vendor": "Azure Blob Storage",
        "cname": r"\.blob\.core\.windows\.net$",
        "body":  r"BlobNotFound|ResourceNotFound",
        "status": 404,
        "severity": "high",
        "notes": "Storage account may not exist; account name is claimable.",
    },
    # GCP
    {
        "vendor": "Google Cloud Storage",
        "cname": r"^c\.storage\.googleapis\.com$|\.storage\.googleapis\.com$",
        "body":  r"NoSuchBucket|The specified bucket does not exist",
        "status": 404,
        "severity": "high",
        "notes": "GCS bucket may be claimable.",
    },
    # GitHub Pages
    {
        "vendor": "GitHub Pages",
        "cname": r"\.github\.io$",
        "body":  r"There isn't a GitHub Pages site here\.|For root URLs",
        "status": 404,
        "severity": "high",
        "notes": "GitHub Pages site can be claimed by registering the username/repo.",
    },
    # Heroku
    {
        "vendor": "Heroku",
        "cname": r"\.herokuapp\.com$|\.herokudns\.com$",
        "body":  r"No such app|herokucdn\.com/error-pages/no-such-app",
        "status": 404,
        "severity": "high",
        "notes": "Heroku app name may be claimable.",
    },
    # Shopify
    {
        "vendor": "Shopify",
        "cname": r"\.myshopify\.com$",
        "body":  r"Sorry, this shop is currently unavailable",
        "status": None,
        "severity": "medium",
        "notes": "Shopify store may be removed.",
    },
    # Fastly
    {
        "vendor": "Fastly",
        "cname": r"\.fastly\.net$",
        "body":  r"Fastly error: unknown domain",
        "status": None,
        "severity": "medium",
        "notes": "Fastly service may be misconfigured.",
    },
    # Tumblr
    {
        "vendor": "Tumblr",
        "cname": r"\.tumblr\.com$|domains\.tumblr\.com",
        "body":  r"Whatever you were looking for doesn't currently exist at this address",
        "status": None,
        "severity": "medium",
        "notes": "Tumblr blog name may be claimable.",
    },
    # Pantheon
    {
        "vendor": "Pantheon",
        "cname": r"\.pantheonsite\.io$",
        "body":  r"The gods are wise|404 error unknown site",
        "status": 404,
        "severity": "high",
        "notes": "Pantheon site may be claimable.",
    },
    # Netlify
    {
        "vendor": "Netlify",
        "cname": r"\.netlify\.app$|\.netlify\.com$",
        "body":  r"Not Found - Request ID|page not found",
        "status": 404,
        "severity": "medium",
        "notes": "Netlify app may be claimable.",
    },
    # Vercel
    {
        "vendor": "Vercel",
        "cname": r"\.vercel\.app$|\.now\.sh$",
        "body":  r"The deployment could not be found",
        "status": 404,
        "severity": "medium",
        "notes": "Vercel deployment may be unclaimed.",
    },
    # Surge
    {
        "vendor": "Surge.sh",
        "cname": r"\.surge\.sh$",
        "body":  r"project not found",
        "status": None,
        "severity": "medium",
        "notes": "Surge project may be claimable.",
    },
    # WordPress.com
    {
        "vendor": "WordPress.com",
        "cname": r"\.wordpress\.com$",
        "body":  r"Do you want to register",
        "status": None,
        "severity": "medium",
        "notes": "WordPress.com blog may be claimable.",
    },
    # Bitbucket
    {
        "vendor": "Bitbucket",
        "cname": r"\.bitbucket\.io$",
        "body":  r"Repository not found",
        "status": 404,
        "severity": "high",
        "notes": "Bitbucket Pages repo may be claimable.",
    },
    # Helpjuice / Zendesk / Statuspage
    {
        "vendor": "Zendesk",
        "cname": r"\.zendesk\.com$",
        "body":  r"Help Center Closed",
        "status": None,
        "severity": "medium",
        "notes": "Zendesk help center may be removed.",
    },
    {
        "vendor": "Statuspage",
        "cname": r"\.statuspage\.io$",
        "body":  r"You are being redirected",
        "status": None,
        "severity": "medium",
        "notes": "Statuspage page may be unclaimed.",
    },
    # Readme.io
    {
        "vendor": "Readme.io",
        "cname": r"\.readme\.io$",
        "body":  r"Project doesnt exist|The page you were looking for",
        "status": None,
        "severity": "medium",
        "notes": "Readme.io project may be claimable.",
    },
    # Tilda
    {
        "vendor": "Tilda",
        "cname": r"\.tilda\.ws$",
        "body":  r"Please renew your subscription",
        "status": None,
        "severity": "low",
        "notes": "Tilda site subscription expired.",
    },
    # Unbounce
    {
        "vendor": "Unbounce",
        "cname": r"\.unbouncepages\.com$",
        "body":  r"The requested URL was not found on this server",
        "status": None,
        "severity": "medium",
        "notes": "Unbounce landing page may be removed.",
    },
    # Webflow
    {
        "vendor": "Webflow",
        "cname": r"\.webflow\.io$|proxy-ssl\.webflow\.com$",
        "body":  r"The page you are looking for doesn't exist",
        "status": 404,
        "severity": "medium",
        "notes": "Webflow site may be claimable.",
    },
]


def run(
    target     : str,
    report     : ReconReport,
    mod_report : ModuleReport,
    output_dir : Path,
):
    log("INFO", target, "Subdomain Takeover Detection — starting")

    findings:    List[Finding] = []
    candidates:  List[Dict] = []
    checked = 0

    for sub in report.subdomains:
        cname = _get_cname(sub.fqdn)
        if not cname:
            continue
        checked += 1
        for fp in FINGERPRINTS:
            if not re.search(fp["cname"], cname, re.I):
                continue

            # CNAME matches a takeover-prone vendor
            verdict = _verify_takeover(sub.fqdn, fp)
            candidates.append({
                "fqdn": sub.fqdn,
                "cname": cname,
                "vendor": fp["vendor"],
                "verdict": verdict["verdict"],
                "status": verdict.get("status"),
            })

            if verdict["verdict"] == "vulnerable":
                findings.append(Finding(
                    severity    = fp["severity"],
                    title       = f"Subdomain Takeover: {fp['vendor']} ({sub.fqdn})",
                    url         = f"https://{sub.fqdn}",
                    evidence    = (f"FQDN {sub.fqdn} CNAMEs to {cname} "
                                   f"({fp['vendor']}). HTTP {verdict.get('status')} "
                                   f"matches takeover fingerprint. "
                                   f"Body excerpt: {verdict.get('body_excerpt','')[:150]}"),
                    module      = MODULE_NAME,
                    remediation = (f"Either remove the dangling CNAME from DNS, or "
                                   f"reclaim the resource at {fp['vendor']}. {fp['notes']}"),
                    tags        = ["takeover", "dns", fp["vendor"].lower().replace(" ", "-")],
                ))
            elif verdict["verdict"] == "suspicious":
                findings.append(Finding(
                    severity    = "info",
                    title       = f"Potential takeover candidate: {fp['vendor']} ({sub.fqdn})",
                    url         = f"https://{sub.fqdn}",
                    evidence    = (f"FQDN {sub.fqdn} → {cname} ({fp['vendor']}). "
                                   f"Manual verification required. "
                                   f"Status: {verdict.get('status')}, "
                                   f"Reason: {verdict.get('reason','no fingerprint match')}"),
                    module      = MODULE_NAME,
                    remediation = f"Manually verify if {fp['vendor']} resource is claimable.",
                    tags        = ["takeover-candidate", "dns",
                                   fp["vendor"].lower().replace(" ", "-")],
                ))
            break  # don't double-match a CNAME against multiple fingerprints

    # Detect "NXDOMAIN at the apex of a CNAME chain" — strongest takeover signal
    for sub in report.subdomains:
        cname = _get_cname(sub.fqdn)
        if not cname:
            continue
        # If the FQDN has a CNAME but cannot be resolved to A, that's a dangling record
        try:
            socket.gethostbyname(sub.fqdn)
        except socket.gaierror:
            findings.append(Finding(
                severity    = "high",
                title       = f"Dangling CNAME (NXDOMAIN): {sub.fqdn}",
                url         = f"https://{sub.fqdn}",
                evidence    = (f"FQDN {sub.fqdn} has CNAME {cname} but resolution fails "
                               f"with NXDOMAIN. The target may be claimable."),
                module      = MODULE_NAME,
                remediation = "Remove the dangling CNAME from DNS, or recreate the target resource.",
                tags        = ["takeover", "dangling-cname", "nxdomain"],
            ))

    mod_report.findings.extend(findings)
    mod_report.summary = {
        "subdomains_checked": checked,
        "candidates_found"  : len(candidates),
        "vulnerabilities"   : len([f for f in findings if f.severity in ("critical","high")]),
        "by_vendor"         : _group_by_vendor(candidates),
    }
    mod_report.data = {"candidates": candidates}
    log("OK", target, f"  Takeover scan complete: {len(findings)} findings "
        f"({len([f for f in findings if f.severity == 'high'])} high)")


# ─────────────────────────────────────────────
# HELPERS
# ─────────────────────────────────────────────

def _get_cname(fqdn: str) -> str:
    """Return the CNAME target for fqdn, or empty string."""
    dig = get_tool("dig")
    if dig:
        stdout, _, _ = run_tool([dig, "+short", "CNAME", fqdn], timeout=8)
        line = stdout.strip().splitlines()
        if line:
            return line[0].rstrip(".").lower()
    # Fallback: use socket - but socket can't easily get CNAME, try gethostbyname_ex
    try:
        _, aliases, _ = socket.gethostbyname_ex(fqdn)
        # gethostbyname_ex returns intermediate hostnames; the original fqdn is canonicalized
        # If the canonical name differs from fqdn, that's a CNAME chain
        # aliases is a list of intermediate names
        if aliases:
            return aliases[-1].lower()
    except Exception:
        pass
    return ""


def _verify_takeover(fqdn: str, fingerprint: Dict) -> Dict:
    """
    Probe the FQDN to confirm takeover. Returns dict:
      verdict: 'vulnerable' | 'suspicious' | 'safe'
      status: HTTP status
      body_excerpt: snippet of response body
      reason: explanation
    """
    for scheme in ["https", "http"]:
        url = f"{scheme}://{fqdn}"
        r   = safe_get(url, allow_redirects=False, timeout=8)
        if r is None:
            continue
        body = r.text[:5000] if r.text else ""

        # Match status code if specified
        status_match = (fingerprint.get("status") is None or
                        r.status_code == fingerprint.get("status"))
        # Match body fingerprint if specified
        body_pattern = fingerprint.get("body")
        body_match = True
        if body_pattern:
            body_match = bool(re.search(body_pattern, body, re.I))

        if status_match and body_match and body_pattern:
            return {
                "verdict": "vulnerable",
                "status": r.status_code,
                "body_excerpt": body[:300],
                "reason": "fingerprint matched",
            }
        elif body_pattern is None and status_match:
            # No body pattern means this vendor needs manual verification
            return {
                "verdict": "suspicious",
                "status": r.status_code,
                "body_excerpt": body[:300],
                "reason": "vendor requires manual verification",
            }

    return {"verdict": "safe", "status": 0, "body_excerpt": "", "reason": "no probe matched"}


def _group_by_vendor(candidates: List[Dict]) -> Dict[str, int]:
    counts: Dict[str, int] = {}
    for c in candidates:
        v = c["vendor"]
        counts[v] = counts.get(v, 0) + 1
    return dict(sorted(counts.items(), key=lambda x: x[1], reverse=True))
