"""
AeroSecLab Recon Engine — Active: CMS / Dev-Tool Probes

Unauthenticated DETECTION-ONLY probes for common CMS, dev tools, and platforms:
  - Strapi (admin init, open registration, version)
  - Spring Boot Actuator (env, health, heapdump, httptrace, mappings)
  - Jenkins (api/json, asynchPeople, login)
  - GitLab (version, public projects, sign-in)
  - WordPress (wp-json users, xmlrpc, readme)
  - Drupal (CHANGELOG.txt, install.php, user/login)
  - Joomla (administrator, manifest)
  - Atlassian Confluence/Jira (rest/api/2/dashboard, etc.)
  - Magento (RELEASE_NOTES.txt)
  - phpMyAdmin / Adminer
  - Kibana / Elasticsearch
  - Grafana
  - Kubernetes API
  - Docker Registry
  - Sonatype Nexus / JFrog Artifactory
  - Apache Solr / Druid

NO authentication attempts. NO POST bodies (except introspection-style read queries).
Only: GET requests, parse responses, fingerprint versions.
"""

from __future__ import annotations

import json
import re
import concurrent.futures
from pathlib import Path
from typing import Dict, List, Optional

from ..core.models import ModuleReport, ReconReport, Finding, LiveHost
from ..core.config import REQUEST_TIMEOUT
from ..core.logger import log
from ..core.http_utils import safe_get


MODULE_NAME = "cms_probes"


def run(
    target     : str,
    report     : ReconReport,
    mod_report : ModuleReport,
    output_dir : Path,
):
    log("INFO", target, "CMS / Dev-Tool Probes — starting")

    if not report.live_hosts:
        log("WARN", target, "  No live hosts to probe")
        mod_report.summary = {"skipped": "no live hosts"}
        return

    findings: List[Finding] = []
    probe_summary: Dict[str, int] = {}

    # Probe each live host in parallel
    with concurrent.futures.ThreadPoolExecutor(max_workers=15) as ex:
        futures = {ex.submit(_probe_host, host): host for host in report.live_hosts}
        for fut in concurrent.futures.as_completed(futures):
            try:
                host_findings, host_signals = fut.result()
                findings.extend(host_findings)
                for sig in host_signals:
                    probe_summary[sig] = probe_summary.get(sig, 0) + 1
            except Exception as e:
                log("ERR", target, f"  probe failed: {e}")

    mod_report.findings.extend(findings)
    mod_report.summary = {
        "hosts_probed"  : len(report.live_hosts),
        "findings"      : len(findings),
        "platforms_seen": probe_summary,
    }
    log("OK", target, f"  CMS probes complete: {len(findings)} findings across "
        f"{len(probe_summary)} platform types")


def _probe_host(host: LiveHost) -> tuple:
    """Probe a single host for known CMS/dev-tool exposures."""
    findings: List[Finding] = []
    signals : List[str] = []

    # Use tech detected during web_probe to prioritize relevant probes
    tech_names = {t.name.lower() for t in host.tech}
    title      = (host.title or "").lower()
    server     = (host.server or "").lower()

    # ─── Strapi ──────────────────────────────────────────────────
    if "strapi" in title or "strapi" in server or any("strapi" in t for t in tech_names):
        f = _probe_strapi(host)
        findings.extend(f)
        if f:
            signals.append("strapi")

    # ─── Spring Boot Actuator ────────────────────────────────────
    if any(t in tech_names for t in ["spring boot", "spring", "springframework"]):
        f = _probe_spring_actuator(host)
        findings.extend(f)
        if f:
            signals.append("spring-actuator")
    else:
        # Even without tech detection, check the most common actuator path
        r = safe_get(f"{host.url}/actuator", timeout=8)
        if r and r.status_code == 200 and "_links" in (r.text or ""):
            findings.extend(_probe_spring_actuator(host))
            signals.append("spring-actuator")

    # ─── Jenkins ─────────────────────────────────────────────────
    if "jenkins" in title or "jenkins" in tech_names:
        f = _probe_jenkins(host)
        findings.extend(f)
        if f:
            signals.append("jenkins")

    # ─── GitLab ──────────────────────────────────────────────────
    if "gitlab" in title or "gitlab" in tech_names:
        f = _probe_gitlab(host)
        findings.extend(f)
        if f:
            signals.append("gitlab")

    # ─── WordPress ───────────────────────────────────────────────
    if "wordpress" in tech_names or "wordpress" in title:
        f = _probe_wordpress(host)
        findings.extend(f)
        if f:
            signals.append("wordpress")

    # ─── Drupal ──────────────────────────────────────────────────
    if "drupal" in title or any("drupal" in t for t in tech_names):
        f = _probe_drupal(host)
        findings.extend(f)
        if f:
            signals.append("drupal")

    # ─── Joomla ──────────────────────────────────────────────────
    if "joomla" in title or "joomla" in tech_names:
        f = _probe_joomla(host)
        findings.extend(f)
        if f:
            signals.append("joomla")

    # ─── phpMyAdmin / Adminer ─────────────────────────────────────
    f = _probe_db_admin_panels(host)
    findings.extend(f)
    if f:
        signals.append("db-admin-panel")

    # ─── Kibana / Elasticsearch ───────────────────────────────────
    f = _probe_elastic_kibana(host)
    findings.extend(f)
    if f:
        signals.append("elastic-kibana")

    # ─── Grafana ─────────────────────────────────────────────────
    if "grafana" in title or "grafana" in tech_names:
        f = _probe_grafana(host)
        findings.extend(f)
        if f:
            signals.append("grafana")

    # ─── Sonatype Nexus / JFrog Artifactory ──────────────────────
    f = _probe_artifact_repos(host)
    findings.extend(f)
    if f:
        signals.append("artifact-repo")

    # ─── Apache Solr / Druid ─────────────────────────────────────
    f = _probe_solr_druid(host)
    findings.extend(f)
    if f:
        signals.append("solr-druid")

    return findings, signals


# ─────────────────────────────────────────────
# STRAPI
# ─────────────────────────────────────────────

def _probe_strapi(host: LiveHost) -> List[Finding]:
    findings = []
    base = host.url

    # /admin/init - reveals hasAdmin and version
    r = safe_get(f"{base}/admin/init", timeout=8)
    if r and r.status_code == 200:
        try:
            data = r.json()
            d = data.get("data", {})
            has_admin = d.get("hasAdmin", None)
            uuid      = d.get("uuid", "")
            version   = d.get("strapiVersion", "")
            findings.append(Finding(
                severity    = "info" if has_admin else "high",
                title       = (f"Strapi admin uninitialized (no admin user) at {host.fqdn}"
                               if has_admin is False else
                               f"Strapi admin panel exposed at {host.fqdn}"),
                url         = f"{base}/admin/init",
                evidence    = (f"hasAdmin={has_admin}, version={version or 'unknown'}, "
                               f"uuid={uuid[:30]}"),
                module      = MODULE_NAME,
                remediation = ("If hasAdmin=false, an attacker can register the first admin "
                               "and take over. Register the admin or restrict /admin to internal IPs."
                               if has_admin is False else
                               "Restrict /admin to internal/VPN IPs."),
                tags        = ["strapi", "cms", "admin-panel"] +
                              (["takeover-candidate"] if has_admin is False else []),
            ))
        except Exception:
            pass

    # /admin - if accessible, the panel is exposed
    r = safe_get(f"{base}/admin", timeout=8)
    if r and r.status_code == 200 and ("strapi" in (r.text or "").lower() or
                                       "<title>strapi" in (r.text or "").lower()):
        findings.append(Finding(
            severity    = "medium",
            title       = f"Strapi admin login page reachable: {host.fqdn}",
            url         = f"{base}/admin",
            evidence    = "Admin login page returns 200 with Strapi UI",
            module      = MODULE_NAME,
            remediation = "Restrict admin panel to internal IPs / VPN.",
            tags        = ["strapi", "admin-panel"],
        ))

    # /api/auth/local/register - check if open registration is enabled
    # Use OPTIONS to avoid actually attempting registration
    r = safe_get(f"{base}/api/auth/local/register", timeout=8)
    if r and r.status_code in (400, 405):
        # 400 = bad input (endpoint exists, accepts input)
        # 405 = method not allowed (endpoint exists)
        # If POST registration is enabled, they'll get 400 on GET
        if r.status_code == 400 or "errors" in (r.text or "").lower():
            findings.append(Finding(
                severity    = "high",
                title       = f"Strapi public registration may be enabled: {host.fqdn}",
                url         = f"{base}/api/auth/local/register",
                evidence    = (f"Registration endpoint reachable ({r.status_code}). "
                               f"Excerpt: {(r.text or '')[:150]}"),
                module      = MODULE_NAME,
                remediation = ("Disable public registration in Strapi: "
                               "Settings → Users & Permissions → Roles → Public → uncheck register"),
                tags        = ["strapi", "open-registration", "auth"],
            ))

    # /api/users - Public role can read users
    r = safe_get(f"{base}/api/users", timeout=8)
    if r and r.status_code == 200:
        try:
            users = r.json()
            if isinstance(users, list):
                findings.append(Finding(
                    severity    = "high",
                    title       = f"Strapi /api/users readable by Public role: {host.fqdn}",
                    url         = f"{base}/api/users",
                    evidence    = f"Returned {len(users)} user records publicly",
                    module      = MODULE_NAME,
                    remediation = "Disable Public role 'find' permission on User collection.",
                    tags        = ["strapi", "user-enumeration", "auth-bypass"],
                ))
        except Exception:
            pass

    return findings


# ─────────────────────────────────────────────
# SPRING BOOT ACTUATOR
# ─────────────────────────────────────────────

ACTUATOR_PATHS = {
    "/actuator/env":        ("critical", "Environment variables exposure (may contain secrets)"),
    "/actuator/heapdump":   ("critical", "Heap dump downloadable - all in-memory secrets exposed"),
    "/actuator/httptrace":  ("high",     "HTTP request trace exposed - may include auth tokens"),
    "/actuator/threaddump": ("medium",   "Thread dump exposed"),
    "/actuator/mappings":   ("medium",   "All endpoints disclosed"),
    "/actuator/beans":      ("low",      "Spring beans listing"),
    "/actuator/configprops":("medium",   "Configuration properties exposed"),
    "/actuator/loggers":    ("low",      "Logger config exposed"),
    "/actuator/health":     ("info",     "Health endpoint exposed (often acceptable)"),
    "/actuator/info":       ("info",     "Info endpoint exposed"),
    "/actuator/metrics":    ("low",      "Metrics endpoint exposed"),
    "/actuator/auditevents":("medium",   "Audit events accessible"),
    "/actuator/scheduledtasks": ("low",  "Scheduled tasks listing"),
    # Older Spring Boot 1.x paths
    "/env":          ("critical", "Spring Boot 1.x env endpoint"),
    "/heapdump":     ("critical", "Spring Boot 1.x heapdump"),
    "/trace":        ("high",     "Spring Boot 1.x trace"),
    "/dump":         ("medium",   "Spring Boot 1.x thread dump"),
    "/mappings":     ("medium",   "Spring Boot 1.x mappings"),
    "/beans":        ("low",      "Spring Boot 1.x beans"),
    "/configprops":  ("medium",   "Spring Boot 1.x configprops"),
}


def _probe_spring_actuator(host: LiveHost) -> List[Finding]:
    findings = []
    base = host.url

    for path, (severity, description) in ACTUATOR_PATHS.items():
        r = safe_get(f"{base}{path}", timeout=6)
        if not r or r.status_code != 200:
            continue

        # Confirm it's actually actuator data (JSON response)
        ct = r.headers.get("content-type", "").lower()
        body_preview = (r.text or "")[:200]
        if "application/json" not in ct and "{" not in body_preview[:50]:
            continue

        # /actuator/env - try to find secrets in the dump
        evidence = description
        if path.endswith("/env") or path == "/env":
            try:
                env_data = r.json()
                # Look for credential-like keys
                env_str = json.dumps(env_data)[:8000]
                secret_keys = re.findall(
                    r'"(.*(?:password|secret|key|token|credentials).*?)"',
                    env_str, re.I
                )
                if secret_keys:
                    evidence = f"{description}. Found {len(secret_keys)} secret-like keys."
            except Exception:
                pass

        findings.append(Finding(
            severity    = severity,
            title       = f"Spring Actuator endpoint exposed: {path} on {host.fqdn}",
            url         = f"{base}{path}",
            evidence    = f"{evidence} | Status: 200, CT: {ct[:50]}",
            module      = MODULE_NAME,
            remediation = (
                "Disable management endpoints in production "
                "(`management.endpoints.web.exposure.include=health`) "
                "or restrict via Spring Security."
            ),
            tags        = ["spring", "actuator", "info-disclosure"],
        ))

    return findings


# ─────────────────────────────────────────────
# JENKINS
# ─────────────────────────────────────────────

def _probe_jenkins(host: LiveHost) -> List[Finding]:
    findings = []
    base = host.url

    # /api/json - reveals version + jobs
    r = safe_get(f"{base}/api/json?pretty=true", timeout=8)
    if r and r.status_code == 200:
        try:
            data = r.json()
            jobs = data.get("jobs", [])
            findings.append(Finding(
                severity    = "high",
                title       = f"Jenkins API accessible without auth: {host.fqdn}",
                url         = f"{base}/api/json",
                evidence    = f"Listed {len(jobs)} jobs publicly. Mode: {data.get('mode','?')}",
                module      = MODULE_NAME,
                remediation = "Enable Jenkins authentication: Manage Jenkins → Configure Global Security.",
                tags        = ["jenkins", "auth-bypass", "info-disclosure"],
            ))
        except Exception:
            pass

    # /asynchPeople - user listing
    r = safe_get(f"{base}/asynchPeople/", timeout=8)
    if r and r.status_code == 200 and "people" in (r.text or "").lower():
        findings.append(Finding(
            severity    = "medium",
            title       = f"Jenkins user listing exposed: {host.fqdn}",
            url         = f"{base}/asynchPeople/",
            evidence    = "User directory accessible without auth",
            module      = MODULE_NAME,
            remediation = "Restrict /asynchPeople to authenticated admins.",
            tags        = ["jenkins", "user-enumeration"],
        ))

    # X-Jenkins header reveals version
    r = safe_get(base, timeout=6)
    if r:
        ver = r.headers.get("X-Jenkins") or r.headers.get("x-jenkins")
        if ver:
            findings.append(Finding(
                severity    = "info",
                title       = f"Jenkins version disclosed: {ver}",
                url         = base,
                evidence    = f"X-Jenkins header: {ver}",
                module      = MODULE_NAME,
                remediation = "Verify Jenkins is patched against known CVEs for this version.",
                tags        = ["jenkins", "version-disclosure"],
            ))

    # /script - if accessible WITHOUT authentication, that's RCE-grade
    # We only check if the endpoint exists; we never POST any script.
    r = safe_get(f"{base}/script", timeout=6)
    if r and r.status_code == 200 and "groovy" in (r.text or "").lower():
        findings.append(Finding(
            severity    = "critical",
            title       = f"Jenkins Groovy script console exposed (auth-bypass?): {host.fqdn}",
            url         = f"{base}/script",
            evidence    = "Groovy script console reachable without authentication",
            module      = MODULE_NAME,
            remediation = "Immediately restrict /script to admin-only. This permits arbitrary code execution.",
            tags        = ["jenkins", "rce-risk", "critical"],
        ))

    return findings


# ─────────────────────────────────────────────
# GITLAB
# ─────────────────────────────────────────────

def _probe_gitlab(host: LiveHost) -> List[Finding]:
    findings = []
    base = host.url

    # /api/v4/version - reveals version (no auth needed if public)
    r = safe_get(f"{base}/api/v4/version", timeout=8)
    if r and r.status_code == 200:
        try:
            data = r.json()
            version = data.get("version", "")
            revision = data.get("revision", "")
            if version:
                findings.append(Finding(
                    severity    = "low",
                    title       = f"GitLab version disclosed: {version}",
                    url         = f"{base}/api/v4/version",
                    evidence    = f"Version: {version}, Revision: {revision}",
                    module      = MODULE_NAME,
                    remediation = "Restrict /api/v4/version or upgrade to latest patched release.",
                    tags        = ["gitlab", "version-disclosure"],
                ))
        except Exception:
            pass

    # /api/v4/projects?visibility=public - public projects
    r = safe_get(f"{base}/api/v4/projects?visibility=public&per_page=10", timeout=8)
    if r and r.status_code == 200:
        try:
            projects = r.json()
            if isinstance(projects, list) and projects:
                names = [p.get("path_with_namespace", "?") for p in projects[:5]]
                findings.append(Finding(
                    severity    = "info",
                    title       = f"GitLab public projects discoverable: {host.fqdn}",
                    url         = f"{base}/api/v4/projects?visibility=public",
                    evidence    = f"Found {len(projects)} public projects: {', '.join(names)}",
                    module      = MODULE_NAME,
                    remediation = ("Audit public projects for accidentally-exposed code/secrets. "
                                   "If unintended, switch them to private."),
                    tags        = ["gitlab", "public-projects", "info-disclosure"],
                ))
        except Exception:
            pass

    # /-/users/sign_up - check if registration is open
    r = safe_get(f"{base}/users/sign_up", timeout=6)
    if r and r.status_code == 200 and "register" in (r.text or "").lower():
        findings.append(Finding(
            severity    = "medium",
            title       = f"GitLab open registration enabled: {host.fqdn}",
            url         = f"{base}/users/sign_up",
            evidence    = "Sign-up page reachable",
            module      = MODULE_NAME,
            remediation = "Disable sign-ups: Admin Area → Settings → General → Sign-up restrictions.",
            tags        = ["gitlab", "open-registration"],
        ))

    return findings


# ─────────────────────────────────────────────
# WORDPRESS
# ─────────────────────────────────────────────

def _probe_wordpress(host: LiveHost) -> List[Finding]:
    findings = []
    base = host.url

    # /wp-json/wp/v2/users - user enumeration
    r = safe_get(f"{base}/wp-json/wp/v2/users", timeout=8)
    if r and r.status_code == 200:
        try:
            users = r.json()
            if isinstance(users, list) and users:
                slugs = [u.get("slug", "") for u in users[:10] if u.get("slug")]
                findings.append(Finding(
                    severity    = "medium",
                    title       = f"WordPress user enumeration via REST API: {host.fqdn}",
                    url         = f"{base}/wp-json/wp/v2/users",
                    evidence    = f"Enumerated {len(users)} usernames: {', '.join(slugs[:5])}",
                    module      = MODULE_NAME,
                    remediation = "Block /wp-json/wp/v2/users in WAF or use plugin to disable user endpoint.",
                    tags        = ["wordpress", "user-enumeration"],
                ))
        except Exception:
            pass

    # /xmlrpc.php
    r = safe_get(f"{base}/xmlrpc.php", timeout=6)
    if r and r.status_code in (200, 405):
        findings.append(Finding(
            severity    = "medium",
            title       = f"WordPress XML-RPC enabled: {host.fqdn}",
            url         = f"{base}/xmlrpc.php",
            evidence    = f"xmlrpc.php returns {r.status_code} (commonly used for credential brute force / pingback DDoS)",
            module      = MODULE_NAME,
            remediation = "Disable xmlrpc.php or restrict to specific IPs.",
            tags        = ["wordpress", "xmlrpc"],
        ))

    # /wp-config.php.bak / .swp / etc
    for ext in [".bak", ".old", ".swp", ".save", "~"]:
        r = safe_get(f"{base}/wp-config.php{ext}", timeout=6)
        if r and r.status_code == 200 and "DB_PASSWORD" in (r.text or ""):
            findings.append(Finding(
                severity    = "critical",
                title       = f"WordPress wp-config backup exposed: {host.fqdn}",
                url         = f"{base}/wp-config.php{ext}",
                evidence    = f"wp-config.php{ext} accessible — DB credentials exposed",
                module      = MODULE_NAME,
                remediation = "Remove backup file from web root immediately. Rotate DB credentials.",
                tags        = ["wordpress", "credential-exposure", "critical"],
            ))
            break

    # /readme.html - reveals version
    r = safe_get(f"{base}/readme.html", timeout=6)
    if r and r.status_code == 200:
        m = re.search(r'Version\s+([0-9.]+)', r.text or "")
        if m:
            findings.append(Finding(
                severity    = "info",
                title       = f"WordPress version disclosed: {m.group(1)}",
                url         = f"{base}/readme.html",
                evidence    = f"WordPress {m.group(1)} via /readme.html",
                module      = MODULE_NAME,
                remediation = "Remove /readme.html or block its access.",
                tags        = ["wordpress", "version-disclosure"],
            ))

    return findings


# ─────────────────────────────────────────────
# DRUPAL
# ─────────────────────────────────────────────

def _probe_drupal(host: LiveHost) -> List[Finding]:
    findings = []
    base = host.url

    r = safe_get(f"{base}/CHANGELOG.txt", timeout=6)
    if r and r.status_code == 200 and "drupal" in (r.text or "").lower()[:200]:
        m = re.search(r'Drupal\s+([0-9.]+)', r.text)
        ver = m.group(1) if m else "unknown"
        findings.append(Finding(
            severity    = "info",
            title       = f"Drupal version disclosed: {ver}",
            url         = f"{base}/CHANGELOG.txt",
            evidence    = f"Drupal {ver} via CHANGELOG.txt",
            module      = MODULE_NAME,
            remediation = "Remove CHANGELOG.txt from web root.",
            tags        = ["drupal", "version-disclosure"],
        ))

    return findings


# ─────────────────────────────────────────────
# JOOMLA
# ─────────────────────────────────────────────

def _probe_joomla(host: LiveHost) -> List[Finding]:
    findings = []
    base = host.url

    r = safe_get(f"{base}/administrator/manifests/files/joomla.xml", timeout=6)
    if r and r.status_code == 200 and "<version>" in (r.text or ""):
        m = re.search(r'<version>([0-9.]+)</version>', r.text)
        ver = m.group(1) if m else "unknown"
        findings.append(Finding(
            severity    = "low",
            title       = f"Joomla version disclosed: {ver}",
            url         = f"{base}/administrator/manifests/files/joomla.xml",
            evidence    = f"Joomla {ver} via manifest",
            module      = MODULE_NAME,
            remediation = "Restrict access to /administrator/manifests/.",
            tags        = ["joomla", "version-disclosure"],
        ))

    return findings


# ─────────────────────────────────────────────
# DB ADMIN PANELS
# ─────────────────────────────────────────────

def _probe_db_admin_panels(host: LiveHost) -> List[Finding]:
    findings = []
    base = host.url
    # phpMyAdmin
    for path in ["/phpmyadmin/", "/pma/", "/myadmin/", "/dbadmin/"]:
        r = safe_get(f"{base}{path}", timeout=6)
        if r and r.status_code == 200 and ("phpmyadmin" in (r.text or "").lower() or
                                           "log in to phpmyadmin" in (r.text or "").lower()):
            findings.append(Finding(
                severity    = "high",
                title       = f"phpMyAdmin login panel exposed: {host.fqdn}{path}",
                url         = f"{base}{path}",
                evidence    = "phpMyAdmin login page accessible without restriction",
                module      = MODULE_NAME,
                remediation = "Restrict phpMyAdmin to internal IPs / VPN. Enable IP allowlisting.",
                tags        = ["phpmyadmin", "admin-panel", "db"],
            ))
            break
    # Adminer
    for path in ["/adminer.php", "/adminer/", "/db/adminer.php"]:
        r = safe_get(f"{base}{path}", timeout=6)
        if r and r.status_code == 200 and "adminer" in (r.text or "").lower():
            findings.append(Finding(
                severity    = "high",
                title       = f"Adminer panel exposed: {host.fqdn}{path}",
                url         = f"{base}{path}",
                evidence    = "Adminer DB management panel accessible",
                module      = MODULE_NAME,
                remediation = "Restrict Adminer to internal IPs / VPN, or remove from web root.",
                tags        = ["adminer", "admin-panel", "db"],
            ))
            break
    return findings


# ─────────────────────────────────────────────
# KIBANA / ELASTICSEARCH
# ─────────────────────────────────────────────

def _probe_elastic_kibana(host: LiveHost) -> List[Finding]:
    findings = []
    base = host.url

    # Elasticsearch root
    r = safe_get(base, timeout=6)
    if r and r.status_code == 200:
        try:
            data = r.json()
            if "version" in data and "lucene_version" in data.get("version", {}):
                findings.append(Finding(
                    severity    = "critical",
                    title       = f"Elasticsearch exposed unauthenticated: {host.fqdn}",
                    url         = base,
                    evidence    = (f"ES version {data.get('version',{}).get('number','?')}, "
                                   f"cluster: {data.get('cluster_name','?')}"),
                    module      = MODULE_NAME,
                    remediation = ("Enable Elasticsearch security (xpack.security.enabled=true), "
                                   "configure authentication, restrict to internal network."),
                    tags        = ["elasticsearch", "no-auth", "critical"],
                ))
        except Exception:
            pass

    # Kibana
    r = safe_get(f"{base}/app/kibana", timeout=6)
    if r and r.status_code == 200 and "kibana" in (r.text or "").lower():
        findings.append(Finding(
            severity    = "high",
            title       = f"Kibana UI exposed: {host.fqdn}",
            url         = f"{base}/app/kibana",
            evidence    = "Kibana web UI accessible (may permit data browsing)",
            module      = MODULE_NAME,
            remediation = "Enable Kibana authentication and restrict access via reverse proxy.",
            tags        = ["kibana", "admin-panel"],
        ))

    return findings


# ─────────────────────────────────────────────
# GRAFANA
# ─────────────────────────────────────────────

def _probe_grafana(host: LiveHost) -> List[Finding]:
    findings = []
    base = host.url

    # /api/health - version disclosure
    r = safe_get(f"{base}/api/health", timeout=6)
    if r and r.status_code == 200:
        try:
            data = r.json()
            version = data.get("version", "")
            db      = data.get("database", "")
            if version:
                findings.append(Finding(
                    severity    = "info",
                    title       = f"Grafana version disclosed: {version}",
                    url         = f"{base}/api/health",
                    evidence    = f"Grafana {version}, db: {db}",
                    module      = MODULE_NAME,
                    remediation = "If version is old, upgrade. Otherwise restrict /api/health.",
                    tags        = ["grafana", "version-disclosure"],
                ))
        except Exception:
            pass

    # /api/datasources - if accessible, datasources are leaked
    r = safe_get(f"{base}/api/datasources", timeout=6)
    if r and r.status_code == 200:
        try:
            ds = r.json()
            if isinstance(ds, list):
                findings.append(Finding(
                    severity    = "high",
                    title       = f"Grafana datasources exposed: {host.fqdn}",
                    url         = f"{base}/api/datasources",
                    evidence    = f"{len(ds)} datasources listed without auth",
                    module      = MODULE_NAME,
                    remediation = "Enforce authentication on /api/* endpoints.",
                    tags        = ["grafana", "info-disclosure"],
                ))
        except Exception:
            pass

    return findings


# ─────────────────────────────────────────────
# SONATYPE NEXUS / JFROG ARTIFACTORY
# ─────────────────────────────────────────────

def _probe_artifact_repos(host: LiveHost) -> List[Finding]:
    findings = []
    base = host.url

    # Nexus
    r = safe_get(f"{base}/service/rest/v1/repositories", timeout=8)
    if r and r.status_code == 200:
        try:
            repos = r.json()
            if isinstance(repos, list) and repos:
                findings.append(Finding(
                    severity    = "high",
                    title       = f"Sonatype Nexus repositories exposed: {host.fqdn}",
                    url         = f"{base}/service/rest/v1/repositories",
                    evidence    = f"Listed {len(repos)} repositories without auth",
                    module      = MODULE_NAME,
                    remediation = "Enforce auth on Nexus REST API. Audit repo visibility.",
                    tags        = ["nexus", "artifact-repo", "info-disclosure"],
                ))
        except Exception:
            pass

    # JFrog Artifactory
    r = safe_get(f"{base}/artifactory/api/repositories", timeout=8)
    if r and r.status_code == 200:
        try:
            repos = r.json()
            if isinstance(repos, list):
                findings.append(Finding(
                    severity    = "high",
                    title       = f"JFrog Artifactory repos exposed: {host.fqdn}",
                    url         = f"{base}/artifactory/api/repositories",
                    evidence    = f"Listed {len(repos)} repositories without auth",
                    module      = MODULE_NAME,
                    remediation = "Enforce auth on Artifactory API.",
                    tags        = ["artifactory", "artifact-repo"],
                ))
        except Exception:
            pass

    return findings


# ─────────────────────────────────────────────
# APACHE SOLR / DRUID
# ─────────────────────────────────────────────

def _probe_solr_druid(host: LiveHost) -> List[Finding]:
    findings = []
    base = host.url

    # Solr
    r = safe_get(f"{base}/solr/admin/info/system?wt=json", timeout=6)
    if r and r.status_code == 200 and "solr" in (r.text or "").lower():
        try:
            data = r.json()
            version = data.get("lucene", {}).get("solr-spec-version", "")
            findings.append(Finding(
                severity    = "high",
                title       = f"Apache Solr admin exposed: {host.fqdn}",
                url         = f"{base}/solr/",
                evidence    = f"Solr {version} admin accessible without auth",
                module      = MODULE_NAME,
                remediation = "Enable Solr authentication, restrict to internal network.",
                tags        = ["solr", "admin-panel"],
            ))
        except Exception:
            pass

    # Druid
    r = safe_get(f"{base}/druid/coordinator/v1/status", timeout=6)
    if r and r.status_code == 200 and "druid" in (r.text or "").lower():
        try:
            data = r.json()
            findings.append(Finding(
                severity    = "high",
                title       = f"Apache Druid coordinator exposed: {host.fqdn}",
                url         = f"{base}/druid/coordinator/",
                evidence    = f"Druid version {data.get('version','?')} exposed",
                module      = MODULE_NAME,
                remediation = "Enable Druid authentication, restrict to internal network.",
                tags        = ["druid", "admin-panel"],
            ))
        except Exception:
            pass

    return findings
