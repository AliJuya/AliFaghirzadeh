"""
AeroSecLab Recon Engine — Active: Visual Reconnaissance
Tool: gowitness (preferred) / aquatone (fallback)

Captures full-page screenshots of all live hosts. Output is referenced
by the markdown report so reviewers see visual evidence per asset.
"""

from __future__ import annotations

import json
import os
import tempfile
from pathlib import Path
from typing import Dict, List

from ..core.models import ModuleReport, ReconReport, Finding
from ..core.config import get_tool, TOOL_TIMEOUT
from ..core.logger import log
from ..core.http_utils import run_tool


MODULE_NAME = "screenshots"


def run(
    target     : str,
    report     : ReconReport,
    mod_report : ModuleReport,
    output_dir : Path,
):
    log("INFO", target, "Screenshots — starting")

    if not report.live_hosts:
        log("WARN", target, "  No live hosts to capture")
        mod_report.summary = {"skipped": "no live hosts"}
        return

    screenshots_dir = output_dir / "screenshots"
    screenshots_dir.mkdir(exist_ok=True)

    urls = sorted({h.url for h in report.live_hosts})
    log("INFO", target, f"  Capturing {len(urls)} URLs")

    captured: Dict[str, str] = {}

    gowitness = get_tool("gowitness")
    if gowitness:
        captured = _run_gowitness(urls, screenshots_dir, target, gowitness)
    else:
        log("WARN", target, "  gowitness not found — install: go install github.com/sensepost/gowitness@latest")
        mod_report.summary = {"skipped": "gowitness not installed"}
        return

    # Map screenshots back to live_hosts via URL
    for host in report.live_hosts:
        if host.url in captured:
            # Stash relative path in headers dict for the report to find
            host.headers["_screenshot_path"] = captured[host.url]

    mod_report.summary = {
        "captured" : len(captured),
        "attempted": len(urls),
        "tool"     : "gowitness",
        "directory": str(screenshots_dir),
    }
    mod_report.data = {
        "screenshots": captured,
    }
    log("OK", target, f"  Captured {len(captured)}/{len(urls)} screenshots")


def _run_gowitness(
    urls            : List[str],
    screenshots_dir : Path,
    target          : str,
    gowitness_path  : str,
) -> Dict[str, str]:
    """Run gowitness against a list of URLs. Returns {url: filepath}."""
    captured: Dict[str, str] = {}

    # Write URL list to temp file
    with tempfile.NamedTemporaryFile(mode="w", suffix=".txt", delete=False) as f:
        f.write("\n".join(urls))
        url_file = f.name

    db_path = screenshots_dir / "gowitness.sqlite3"

    # gowitness v3 syntax: scan file -f <file> --screenshot-path ...
    # Try v3 syntax first, fall back to v2
    cmd_v3 = [
        gowitness_path, "scan", "file",
        "-f", url_file,
        "--screenshot-path", str(screenshots_dir),
        "--write-db", "--db-uri", f"sqlite://{db_path}",
        "--threads", "8",
        "--timeout", "20",
        "--disable-logging",
    ]
    stdout, stderr, rc = run_tool(cmd_v3, timeout=TOOL_TIMEOUT, target=target)

    if rc != 0:
        # Fallback to v2 syntax
        cmd_v2 = [
            gowitness_path, "file",
            "-f", url_file,
            "-P", str(screenshots_dir),
            "--threads", "8",
            "--timeout", "20",
            "--disable-db",
        ]
        stdout, stderr, rc = run_tool(cmd_v2, timeout=TOOL_TIMEOUT, target=target)

    # Map URLs to screenshot files based on naming convention
    # gowitness names files like: https-example-com-443.png
    for url in urls:
        sanitized = (url.replace("://", "-")
                        .replace("/", "-")
                        .replace(":", "-"))
        # Try both common naming patterns
        for candidate in [
            screenshots_dir / f"{sanitized}.png",
            screenshots_dir / f"{sanitized.rstrip('-')}.png",
            screenshots_dir / f"{sanitized}.jpeg",
        ]:
            if candidate.exists():
                captured[url] = str(candidate.relative_to(screenshots_dir.parent))
                break

    # Also scan the directory for any PNG and try to match
    if len(captured) < len(urls) // 2:
        # Heuristic match by FQDN substring
        all_pngs = list(screenshots_dir.glob("*.png"))
        for url in urls:
            if url in captured:
                continue
            from urllib.parse import urlparse
            host = urlparse(url).netloc
            for png in all_pngs:
                if host.replace(".", "-") in png.stem or host in png.stem:
                    captured[url] = str(png.relative_to(screenshots_dir.parent))
                    break

    try:
        os.unlink(url_file)
    except Exception:
        pass

    return captured
