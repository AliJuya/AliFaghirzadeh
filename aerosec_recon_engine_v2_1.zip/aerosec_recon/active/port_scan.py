"""
AeroSecLab Recon Engine — Active: Port Scanning
Tools: masscan, nmap, naabu
Strategy: masscan for fast discovery → nmap for service detection
"""

from __future__ import annotations

import concurrent.futures
import json
import re
import tempfile
from pathlib import Path
from typing import Dict, List, Set, Tuple

from ..core.models import (
    ModuleReport, ReconReport, PortResult, Subdomain, Finding
)
from ..core.config import (
    get_tool, TOOL_TIMEOUT, MASSCAN_RATE, WEB_PORTS, ALL_PORTS_RANGE
)
from ..core.logger import log
from ..core.http_utils import run_tool


MODULE_NAME = "port_scan"

# Interesting non-web ports that indicate attack surface
INTERESTING_PORTS = {
    21   : "FTP",
    22   : "SSH",
    23   : "Telnet",
    25   : "SMTP",
    53   : "DNS",
    110  : "POP3",
    111  : "RPC",
    135  : "MSRPC",
    139  : "NetBIOS",
    143  : "IMAP",
    389  : "LDAP",
    445  : "SMB",
    512  : "rexec",
    513  : "rlogin",
    514  : "rsh",
    587  : "SMTP Submission",
    636  : "LDAPS",
    873  : "rsync",
    1433 : "MSSQL",
    1521 : "Oracle DB",
    2049 : "NFS",
    2181 : "ZooKeeper",
    2375 : "Docker (unauth)",
    2376 : "Docker TLS",
    3306 : "MySQL",
    3389 : "RDP",
    4369 : "RabbitMQ",
    5432 : "PostgreSQL",
    5601 : "Kibana",
    5672 : "AMQP/RabbitMQ",
    5900 : "VNC",
    6379 : "Redis",
    6443 : "Kubernetes API",
    7001 : "WebLogic",
    8161 : "ActiveMQ",
    8500 : "Consul",
    9000 : "SonarQube/Portainer",
    9092 : "Kafka",
    9200 : "Elasticsearch",
    9300 : "Elasticsearch cluster",
    10250: "Kubelet",
    11211: "Memcached",
    15672: "RabbitMQ Management",
    27017: "MongoDB",
    27018: "MongoDB",
    28017: "MongoDB HTTP",
}


def run(
    target     : str,
    report     : ReconReport,
    mod_report : ModuleReport,
    output_dir : Path,
):
    log("INFO", target, "Port Scanning — starting")

    # Collect all unique IPs from discovered subdomains + apex
    all_ips: Set[str] = set()
    for sub in report.subdomains:
        all_ips.update(sub.ips)
    # Also add apex domain IPs
    import socket
    try:
        apex_ips = {ai[4][0] for ai in socket.getaddrinfo(target, None)}
        all_ips.update(apex_ips)
    except Exception:
        pass

    # Filter out CDN IPs (Cloudflare, CloudFront ranges) — they all look the same
    all_ips = _filter_cdn_ips(all_ips)

    if not all_ips:
        log("WARN", target, "  No unique IPs to scan")
        mod_report.summary = {"error": "no_ips"}
        return

    log("INFO", target, f"  Scanning {len(all_ips)} unique IPs")

    all_open_ports: Dict[str, List[PortResult]] = {}

    # ── Phase 1: masscan for fast port discovery ──────────────────────
    if get_tool("masscan"):
        masscan_results = _run_masscan(list(all_ips), output_dir, target)
        for ip, ports in masscan_results.items():
            all_open_ports.setdefault(ip, [])
            all_open_ports[ip].extend(ports)
        total_ports = sum(len(p) for p in masscan_results.values())
        log("OK", target, f"  masscan → {total_ports} open ports across {len(masscan_results)} IPs")

    # ── Phase 2: nmap service detection on discovered open ports ──────
    if get_tool("nmap") and all_open_ports:
        nmap_results = _run_nmap_on_open_ports(all_open_ports, output_dir, target)
        # Merge nmap service info into existing results
        for ip, ports in nmap_results.items():
            all_open_ports[ip] = ports
        log("OK", target, f"  nmap service detection complete")
    elif get_tool("nmap"):
        # No masscan — use nmap directly for top ports
        nmap_results = _run_nmap_top_ports(list(all_ips), output_dir, target)
        for ip, ports in nmap_results.items():
            all_open_ports[ip] = ports
        log("OK", target, f"  nmap top-1000 → {sum(len(p) for p in nmap_results.values())} ports")

    # ── naabu as fallback/supplement ─────────────────────────────────
    if get_tool("naabu") and not all_open_ports:
        naabu_results = _run_naabu(list(all_ips), output_dir, target)
        for ip, ports in naabu_results.items():
            all_open_ports.setdefault(ip, [])
            all_open_ports[ip].extend(ports)
        log("OK", target, f"  naabu → {sum(len(p) for p in naabu_results.values())} ports")

    # ── Attach ports to subdomains ────────────────────────────────────
    for sub in report.subdomains:
        for ip in sub.ips:
            if ip in all_open_ports and sub.live_host:
                sub.live_host.ports = all_open_ports[ip]

    # ── Generate findings for dangerous exposed ports ──────────────────
    findings = _generate_port_findings(all_open_ports, target)
    mod_report.findings.extend(findings)

    # ── Summary ───────────────────────────────────────────────────────
    total_open = sum(len(p) for p in all_open_ports.values())
    port_summary = {}
    for ip, ports in all_open_ports.items():
        for p in ports:
            key = f"{p.port}/{p.protocol}"
            port_summary[key] = port_summary.get(key, 0) + 1

    mod_report.summary = {
        "ips_scanned"  : len(all_ips),
        "ips_with_open": len(all_open_ports),
        "total_open_ports": total_open,
        "port_frequency": dict(sorted(port_summary.items(),
                                      key=lambda x: x[1], reverse=True)[:20]),
    }
    mod_report.data = {
        "results": {
            ip: [{"port": p.port, "protocol": p.protocol,
                  "service": p.service, "version": p.version,
                  "banner": p.banner[:200]}
                 for p in ports]
            for ip, ports in all_open_ports.items()
        }
    }
    log("OK", target, f"  Port scan complete: {total_open} open ports on {len(all_open_ports)} hosts")


# ─────────────────────────────────────────────
# MASSCAN
# ─────────────────────────────────────────────

def _run_masscan(
    ips       : List[str],
    output_dir: Path,
    target    : str,
) -> Dict[str, List[PortResult]]:
    results  = {}
    masscan  = get_tool("masscan")
    out_file = str(output_dir / "masscan.json")

    # Write IP list
    with tempfile.NamedTemporaryFile(mode="w", suffix=".txt", delete=False) as f:
        f.write("\n".join(ips))
        ip_file = f.name

    # Build port list
    ports = ",".join(str(p) for p in WEB_PORTS) + "," + ",".join(
        str(p) for p in INTERESTING_PORTS.keys()
    )

    stdout, stderr, rc = run_tool(
        [
            masscan,
            "-iL", ip_file,
            "-p", ports,
            "--rate", str(MASSCAN_RATE),
            "-oJ", out_file,
            "--wait", "3",
        ],
        timeout=TOOL_TIMEOUT,
        target=target,
    )

    out_path = Path(out_file)
    if out_path.exists():
        try:
            content = out_path.read_text().strip()
            if content.endswith(","):
                content = content[:-1]
            if not content.startswith("["):
                content = f"[{content}]"
            data = json.loads(content)
            for entry in data:
                ip    = entry.get("ip", "")
                ports = entry.get("ports", [])
                if ip and ports:
                    results.setdefault(ip, [])
                    for p in ports:
                        results[ip].append(PortResult(
                            port     = p.get("port", 0),
                            state    = p.get("status", "open"),
                            protocol = p.get("proto", "tcp"),
                        ))
        except Exception as e:
            pass

    import os
    try:
        os.unlink(ip_file)
    except Exception:
        pass

    return results


# ─────────────────────────────────────────────
# NMAP
# ─────────────────────────────────────────────

def _run_nmap_on_open_ports(
    open_ports : Dict[str, List[PortResult]],
    output_dir : Path,
    target     : str,
) -> Dict[str, List[PortResult]]:
    """Run nmap service/version detection on masscan-discovered open ports."""
    results = {}
    nmap    = get_tool("nmap")

    def scan_host(ip: str, ports: List[PortResult]):
        port_str = ",".join(str(p.port) for p in ports)
        out_file = str(output_dir / f"nmap_{ip.replace('.', '_')}.xml")
        stdout, _, _ = run_tool(
            [
                nmap,
                "-sV", "-sC",
                "-O",               # OS detection
                "--script",
                "banner,http-title,ssl-cert,http-server-header,ssh-hostkey",
                "-p", port_str,
                "-T4",
                "--open",
                "-oX", out_file,
                "--host-timeout", "120s",
                ip,
            ],
            timeout=180,
            target=target,
        )
        return ip, _parse_nmap_xml(out_file)

    with concurrent.futures.ThreadPoolExecutor(max_workers=10) as ex:
        futures = {ex.submit(scan_host, ip, ports): ip
                   for ip, ports in open_ports.items()}
        for f in concurrent.futures.as_completed(futures):
            ip, host_results = f.result()
            if host_results:
                results[ip] = host_results

    return results


def _run_nmap_top_ports(
    ips       : List[str],
    output_dir: Path,
    target    : str,
) -> Dict[str, List[PortResult]]:
    """Run nmap top-1000 scan on all IPs when masscan is unavailable."""
    results  = {}
    nmap     = get_tool("nmap")
    out_file = str(output_dir / "nmap_top1000.xml")

    stdout, _, _ = run_tool(
        [
            nmap,
            "-sV", "-sC",
            "--top-ports", "1000",
            "-T4",
            "--open",
            "-oX", out_file,
        ] + ips,
        timeout=TOOL_TIMEOUT,
        target=target,
    )

    for ip, ports in _parse_nmap_xml(out_file).items():
        results[ip] = ports
    return results


def _parse_nmap_xml(xml_file: str) -> Dict[str, List[PortResult]]:
    """Parse nmap XML output into PortResult objects."""
    results = {}
    try:
        import xml.etree.ElementTree as ET
        tree = ET.parse(xml_file)
        root = tree.getroot()

        for host in root.findall("host"):
            addr_elem = host.find("address[@addrtype='ipv4']")
            if addr_elem is None:
                continue
            ip = addr_elem.get("addr", "")
            if not ip:
                continue

            ports_list = []
            ports_elem = host.find("ports")
            if ports_elem is None:
                continue

            for port_elem in ports_elem.findall("port"):
                state_elem = port_elem.find("state")
                if state_elem is None or state_elem.get("state") != "open":
                    continue

                port_num  = int(port_elem.get("portid", 0))
                protocol  = port_elem.get("protocol", "tcp")
                service_e = port_elem.find("service")

                service = ""
                version = ""
                cpe     = ""
                if service_e is not None:
                    service = service_e.get("name", "")
                    product = service_e.get("product", "")
                    ver     = service_e.get("version", "")
                    extra   = service_e.get("extrainfo", "")
                    version = " ".join(filter(None, [product, ver, extra]))
                    cpe_e   = service_e.find("cpe")
                    if cpe_e is not None:
                        cpe = cpe_e.text or ""

                # Extract banner from script output
                banner = ""
                for script in port_elem.findall("script"):
                    if script.get("id") in ("banner", "http-title",
                                             "http-server-header"):
                        banner = script.get("output", "")[:200]
                        break

                ports_list.append(PortResult(
                    port     = port_num,
                    state    = "open",
                    protocol = protocol,
                    service  = service,
                    version  = version,
                    banner   = banner,
                    cpe      = cpe,
                ))

            if ports_list:
                results[ip] = ports_list

    except Exception:
        pass
    return results


# ─────────────────────────────────────────────
# NAABU
# ─────────────────────────────────────────────

def _run_naabu(
    ips       : List[str],
    output_dir: Path,
    target    : str,
) -> Dict[str, List[PortResult]]:
    results  = {}
    naabu    = get_tool("naabu")
    out_file = str(output_dir / "naabu.json")

    with tempfile.NamedTemporaryFile(mode="w", suffix=".txt", delete=False) as f:
        f.write("\n".join(ips))
        ip_file = f.name

    ports = ",".join(str(p) for p in WEB_PORTS)

    stdout, _, _ = run_tool(
        [
            naabu,
            "-l", ip_file,
            "-p", ports,
            "-rate", "10000",
            "-c", "50",
            "-json",
            "-o", out_file,
            "-silent",
        ],
        timeout=TOOL_TIMEOUT,
        target=target,
    )

    out_path = Path(out_file)
    if out_path.exists():
        for line in out_path.read_text().splitlines():
            try:
                entry = json.loads(line)
                ip    = entry.get("ip", "")
                port  = entry.get("port", 0)
                if ip and port:
                    results.setdefault(ip, [])
                    results[ip].append(PortResult(port=port, state="open"))
            except Exception:
                pass

    import os
    try:
        os.unlink(ip_file)
    except Exception:
        pass

    return results


# ─────────────────────────────────────────────
# CDN IP FILTERING
# ─────────────────────────────────────────────

# Known CDN IP ranges (approximate) — scanning these wastes time
CDN_RANGES = [
    "104.16.", "104.17.", "104.18.", "104.19.", "104.20.", "104.21.",  # Cloudflare
    "172.64.", "172.65.", "172.66.", "172.67.",                         # Cloudflare
    "198.41.", "190.93.",                                               # Cloudflare
    "2606:4700",                                                        # Cloudflare IPv6
    "13.224.", "13.225.", "13.226.", "13.227.", "13.228.", "13.229.",  # CloudFront
    "13.32.", "13.33.", "13.34.", "13.35.",                            # CloudFront
    "52.84.", "52.85.", "52.222.", "52.223.",                          # CloudFront
    "54.182.", "54.192.", "54.230.", "54.239.",                        # CloudFront
    "64.252.", "70.132.", "99.84.", "99.86.",                          # CloudFront
    "216.198.",                                                         # ArvanCloud
    "185.143.",                                                         # ArvanCloud
]


def _filter_cdn_ips(ips: Set[str]) -> Set[str]:
    """Remove known CDN IPs from scan targets."""
    filtered = set()
    for ip in ips:
        if not any(ip.startswith(prefix) for prefix in CDN_RANGES):
            filtered.add(ip)
    return filtered


# ─────────────────────────────────────────────
# FINDINGS GENERATION
# ─────────────────────────────────────────────

def _generate_port_findings(
    results: Dict[str, List[PortResult]],
    target : str,
) -> List[Finding]:
    findings = []
    for ip, ports in results.items():
        for port in ports:
            if port.port in INTERESTING_PORTS:
                service_name = INTERESTING_PORTS[port.port]
                sev = _port_severity(port.port, port.service)
                findings.append(Finding(
                    severity    = sev,
                    title       = f"{service_name} exposed on {ip}:{port.port}",
                    url         = f"{ip}:{port.port}",
                    evidence    = f"Port {port.port}/tcp open — {port.service} {port.version}",
                    module      = MODULE_NAME,
                    remediation = _port_remediation(port.port),
                    tags        = ["port-scan", service_name.lower().replace(" ", "-")],
                ))
    return findings


def _port_severity(port: int, service: str) -> str:
    critical_ports = {2375, 2376, 6379, 9200, 27017, 11211, 5601, 9092, 2181}
    high_ports     = {21, 23, 3306, 5432, 1521, 1433, 5900, 3389, 873, 512, 513}
    if port in critical_ports:
        return "critical"
    if port in high_ports:
        return "high"
    return "medium"


def _port_remediation(port: int) -> str:
    remediations = {
        2375  : "Docker API exposed without TLS — restrict to localhost or use TLS + authentication",
        6379  : "Redis exposed without authentication — add requirepass and bind to localhost",
        9200  : "Elasticsearch exposed — add authentication and restrict access",
        27017 : "MongoDB exposed without auth — enable authentication and bind to localhost",
        11211 : "Memcached exposed — bind to localhost, never expose publicly",
        5601  : "Kibana exposed — add authentication, restrict to VPN",
        3306  : "MySQL exposed — restrict access to application servers only",
        5432  : "PostgreSQL exposed — restrict access to application servers only",
        3389  : "RDP exposed — restrict to VPN, enable NLA",
        5900  : "VNC exposed — restrict to VPN, use strong password",
        21    : "FTP exposed — migrate to SFTP, restrict access",
        23    : "Telnet exposed — disable immediately, use SSH",
    }
    return remediations.get(port, "Restrict access to this port via firewall rules")
