"""
AeroSecLab Recon Engine — HTTP Utilities
Shared HTTP helpers used across all modules.
"""

from __future__ import annotations

import random
import re
import socket
import subprocess
from typing import Dict, List, Optional, Tuple
from urllib.parse import urljoin, urlparse

try:
    import requests
    import urllib3
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
except ImportError:
    raise SystemExit("[!] requests not installed: pip install requests --break-system-packages")

from .config import (
    USER_AGENTS, BASE_HEADERS, REQUEST_TIMEOUT,
    CONNECT_TIMEOUT, CDN_FINGERPRINTS, WAF_FINGERPRINTS,
    get_tool,
)
from .logger import log


# ─────────────────────────────────────────────
# SESSION
# ─────────────────────────────────────────────

def make_session() -> requests.Session:
    """Create a requests session with sane defaults."""
    s = requests.Session()
    s.verify  = False
    s.headers.update(BASE_HEADERS)
    s.headers["User-Agent"] = random.choice(USER_AGENTS)
    adapter = requests.adapters.HTTPAdapter(
        max_retries=requests.adapters.Retry(
            total=2,
            backoff_factor=0.3,
            status_forcelist=[500, 502, 503, 504],
        )
    )
    s.mount("http://",  adapter)
    s.mount("https://", adapter)
    return s


_SESSION = make_session()


def rotate_ua():
    """Rotate the global session's User-Agent."""
    _SESSION.headers["User-Agent"] = random.choice(USER_AGENTS)


# ─────────────────────────────────────────────
# REQUEST HELPERS
# ─────────────────────────────────────────────

def safe_get(
    url            : str,
    *,
    allow_redirects: bool = True,
    extra_headers  : Optional[Dict] = None,
    timeout        : int = REQUEST_TIMEOUT,
    session        : Optional[requests.Session] = None,
) -> Optional[requests.Response]:
    s = session or _SESSION
    h = {}
    if extra_headers:
        h.update(extra_headers)
    try:
        rotate_ua()
        return s.get(url, headers=h, timeout=timeout,
                     allow_redirects=allow_redirects, verify=False)
    except Exception:
        return None


def safe_post(
    url         : str,
    json_body   : Optional[Dict] = None,
    data        : Optional[Dict] = None,
    extra_headers: Optional[Dict] = None,
    timeout     : int = REQUEST_TIMEOUT,
    session     : Optional[requests.Session] = None,
) -> Optional[requests.Response]:
    s = session or _SESSION
    h = {"Content-Type": "application/json"}
    if extra_headers:
        h.update(extra_headers)
    try:
        rotate_ua()
        return s.post(url, headers=h, json=json_body, data=data,
                      timeout=timeout, verify=False)
    except Exception:
        return None


def safe_request(
    method      : str,
    url         : str,
    timeout     : int = REQUEST_TIMEOUT,
    extra_headers: Optional[Dict] = None,
    json_body   : Optional[Dict] = None,
    allow_redirects: bool = False,
    session     : Optional[requests.Session] = None,
) -> Tuple[Optional[requests.Response], Optional[str]]:
    s = session or _SESSION
    h = {}
    if extra_headers:
        h.update(extra_headers)
    try:
        rotate_ua()
        r = s.request(method, url, headers=h, json=json_body,
                      timeout=timeout, verify=False,
                      allow_redirects=allow_redirects)
        return r, None
    except requests.RequestException as e:
        return None, str(e)


# ─────────────────────────────────────────────
# RESPONSE HELPERS
# ─────────────────────────────────────────────

def extract_title(html: str) -> str:
    m = re.search(r'<title[^>]*>(.*?)</title>', html, re.I | re.S)
    return re.sub(r'\s+', ' ', m.group(1)).strip()[:120] if m else ""


def snippet(r: requests.Response, limit: int = 300) -> str:
    return re.sub(r'\s+', ' ', r.text or "").strip()[:limit]


def get_cookies_list(r: requests.Response) -> List[str]:
    """Extract all Set-Cookie headers from a response."""
    raw = getattr(r.raw, "headers", None)
    if raw is not None:
        getter = getattr(raw, "getlist", None) or getattr(raw, "get_all", None)
        if callable(getter):
            return getter("Set-Cookie") or []
    single = r.headers.get("Set-Cookie")
    return [single] if single else []


# ─────────────────────────────────────────────
# CDN / WAF DETECTION
# ─────────────────────────────────────────────

def detect_cdn(r: requests.Response) -> str:
    """Return CDN name or empty string."""
    headers_str = str(r.headers).lower()
    for cdn_name, markers in CDN_FINGERPRINTS.items():
        if any(m.lower() in headers_str for m in markers):
            return cdn_name
    return ""


def detect_waf(r: requests.Response, body: str = "") -> str:
    """Return WAF name or empty string."""
    check = str(r.headers).lower() + body.lower()
    for waf_name, markers in WAF_FINGERPRINTS.items():
        if any(m.lower() in check for m in markers):
            return waf_name
    return ""


# ─────────────────────────────────────────────
# SPA DETECTION
# ─────────────────────────────────────────────

def is_spa(base_url: str) -> bool:
    """Detect Single Page Applications that return 200 for any path."""
    import random, string
    token = "aerosec-" + "".join(random.choices(string.ascii_lowercase, k=10))
    r = safe_get(f"{base_url}/{token}")
    if r and r.status_code == 200:
        ct = r.headers.get("content-type", "").lower()
        if "text/html" in ct:
            return True
    return False


# ─────────────────────────────────────────────
# SSL/TLS
# ─────────────────────────────────────────────

def get_certificate(hostname: str, port: int = 443):
    """Extract SSL certificate info from a host."""
    from .models import Certificate
    import ssl
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode    = ssl.CERT_NONE
    try:
        conn = ctx.wrap_socket(
            socket.socket(socket.AF_INET),
            server_hostname=hostname
        )
        conn.settimeout(CONNECT_TIMEOUT)
        conn.connect((hostname, port))
        cert = conn.getpeercert()
        conn.close()

        san_domains = []
        for san_type, san_value in cert.get("subjectAltName", []):
            if san_type == "DNS":
                san_domains.append(san_value)

        subject = dict(x[0] for x in cert.get("subject", []))
        issuer  = dict(x[0] for x in cert.get("issuer", []))

        import datetime as dt
        valid_to  = cert.get("notAfter", "")
        expired   = False
        if valid_to:
            try:
                exp = dt.datetime.strptime(valid_to, "%b %d %H:%M:%S %Y %Z")
                expired = exp < dt.datetime.utcnow()
            except Exception:
                pass

        return Certificate(
            subject     = subject.get("commonName", ""),
            issuer      = issuer.get("commonName", ""),
            san_domains = san_domains,
            valid_from  = cert.get("notBefore", ""),
            valid_to    = valid_to,
            expired     = expired,
            self_signed = subject.get("commonName") == issuer.get("commonName"),
        )
    except Exception:
        return None


# ─────────────────────────────────────────────
# F5 BIG-IP COOKIE DECODER
# ─────────────────────────────────────────────

def decode_f5_cookie(cookie_val: str) -> Optional[Tuple[str, int]]:
    """
    Decode F5 BIG-IP persistence cookie to reveal internal IP:port.
    Two formats:
      Plain:    <ip_dec>.<port_dec>.0000   (e.g. 1677787402.20480.0000)
      Encoded:  <prefix><ip_hex_LE><port_hex_LE>...
    """
    import struct
    import re as _re
    try:
        clean = cookie_val.split(";")[0].strip()
        if not clean:
            return None

        # Format 1: dot-separated decimal - ip.port.0000
        m = _re.match(r'^(\d+)\.(\d+)\.\d+$', clean)
        if m:
            ip_int = int(m.group(1))
            port_le = int(m.group(2))
            ip = socket.inet_ntoa(struct.pack('<I', ip_int))
            # port is little-endian on the wire too
            port = ((port_le & 0xFF) << 8) | ((port_le >> 8) & 0xFF)
            if 1 <= port <= 65535 and not ip.startswith("0."):
                return ip, port

        # Format 2: hex-encoded — find longest hex run and try
        hex_runs = _re.findall(r'[0-9a-fA-F]{12,}', clean)
        for run in hex_runs:
            for offset in range(0, len(run) - 11, 2):
                ip_hex   = run[offset:offset+8]
                port_hex = run[offset+8:offset+12]
                try:
                    ip   = socket.inet_ntoa(struct.pack('<I', int(ip_hex, 16)))
                    port = int(port_hex, 16)
                    # validate
                    if 1 <= port <= 65535 and not ip.startswith(("0.", "255.")):
                        parts = [int(p) for p in ip.split(".")]
                        if all(0 <= p <= 255 for p in parts):
                            # heuristic: prefer RFC1918
                            if (parts[0] == 10 or
                                (parts[0] == 172 and 16 <= parts[1] <= 31) or
                                (parts[0] == 192 and parts[1] == 168) or
                                parts[0] in (127, 169)):
                                return ip, port
                except Exception:
                    continue
        return None
    except Exception:
        return None


# ─────────────────────────────────────────────
# SUBPROCESS RUNNER
# ─────────────────────────────────────────────

def run_tool(
    cmd     : List[str],
    timeout : int = 300,
    target  : str = "",
    stdin   : Optional[str] = None,
) -> Tuple[str, str, int]:
    """
    Run a subprocess tool and return (stdout, stderr, returncode).
    Handles timeouts gracefully.
    """
    try:
        result = subprocess.run(
            cmd,
            capture_output = True,
            text           = True,
            timeout        = timeout,
            input          = stdin,
        )
        return result.stdout.strip(), result.stderr.strip(), result.returncode
    except subprocess.TimeoutExpired:
        log("WARN", target or "tool", f"Tool timed out after {timeout}s: {cmd[0]}")
        return "", "timeout", -1
    except FileNotFoundError:
        log("ERR", target or "tool", f"Tool not found: {cmd[0]}")
        return "", "not_found", -1
    except Exception as e:
        log("ERR", target or "tool", f"Tool error: {e}")
        return "", str(e), -1


def tool_available(name: str) -> bool:
    from .config import get_tool
    return get_tool(name) is not None
