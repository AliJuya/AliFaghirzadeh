"""
AeroSecLab Recon Engine — Core Data Models
All modules read and write to these unified structures.
"""

from __future__ import annotations
from dataclasses import dataclass, field, asdict
from datetime import datetime
from typing import Dict, List, Optional, Any
from enum import Enum


# ─────────────────────────────────────────────
# ENUMS
# ─────────────────────────────────────────────

class Severity(str, Enum):
    CRITICAL = "critical"
    HIGH     = "high"
    MEDIUM   = "medium"
    LOW      = "low"
    INFO     = "info"


class RecordType(str, Enum):
    A     = "A"
    AAAA  = "AAAA"
    CNAME = "CNAME"
    MX    = "MX"
    NS    = "NS"
    TXT   = "TXT"
    SOA   = "SOA"
    PTR   = "PTR"
    SRV   = "SRV"


class CDN(str, Enum):
    CLOUDFLARE  = "cloudflare"
    CLOUDFRONT  = "cloudfront"
    ARVANCLOUD  = "arvancloud"
    AKAMAI      = "akamai"
    FASTLY      = "fastly"
    INCAPSULA   = "incapsula"
    SUCURI      = "sucuri"
    NONE        = ""


class PortState(str, Enum):
    OPEN     = "open"
    CLOSED   = "closed"
    FILTERED = "filtered"


# ─────────────────────────────────────────────
# PRIMITIVE MODELS
# ─────────────────────────────────────────────

@dataclass
class DNSRecord:
    type    : str
    value   : str
    ttl     : int = 0


@dataclass
class PortResult:
    port     : int
    state    : str
    protocol : str = "tcp"
    service  : str = ""
    version  : str = ""
    banner   : str = ""
    cpe      : str = ""


@dataclass
class TechStack:
    name       : str
    version    : str = ""
    confidence : int = 0       # 0-100
    category   : str = ""      # cms, framework, server, cdn, etc.


@dataclass
class Certificate:
    subject      : str = ""
    issuer       : str = ""
    san_domains  : List[str] = field(default_factory=list)
    valid_from   : str = ""
    valid_to     : str = ""
    expired      : bool = False
    self_signed  : bool = False


@dataclass
class ASNInfo:
    asn          : str = ""
    org          : str = ""
    country      : str = ""
    prefixes_v4  : List[str] = field(default_factory=list)
    prefixes_v6  : List[str] = field(default_factory=list)
    peers        : List[str] = field(default_factory=list)


@dataclass
class WhoisInfo:
    registrar      : str = ""
    registered     : str = ""
    updated        : str = ""
    expires        : str = ""
    name_servers   : List[str] = field(default_factory=list)
    registrant_org : str = ""
    registrant_country: str = ""
    emails         : List[str] = field(default_factory=list)
    raw            : str = ""


@dataclass
class Parameter:
    name     : str
    url      : str
    method   : str = "GET"
    type     : str = "query"   # query, body, header, cookie, path
    example  : str = ""


@dataclass
class CrawledLink:
    url        : str
    source     : str = ""      # page that contained this link
    status     : int = 0
    content_type: str = ""
    depth      : int = 0


@dataclass
class JSFile:
    url          : str
    size_kb      : float = 0.0
    api_urls     : List[str] = field(default_factory=list)
    api_paths    : List[str] = field(default_factory=list)
    transfer_paths: List[str] = field(default_factory=list)
    auth_headers : List[str] = field(default_factory=list)
    jwt_secrets  : List[str] = field(default_factory=list)
    api_keys     : List[str] = field(default_factory=list)
    s3_buckets   : List[str] = field(default_factory=list)
    private_ips  : List[str] = field(default_factory=list)
    websockets   : List[str] = field(default_factory=list)
    stomp_channels: List[str] = field(default_factory=list)
    firebase     : List[str] = field(default_factory=list)
    google_oauth : List[str] = field(default_factory=list)


@dataclass
class Finding:
    severity    : str
    title       : str
    url         : str
    evidence    : str
    module      : str = ""
    cve         : str = ""
    remediation : str = ""
    tags        : List[str] = field(default_factory=list)


# ─────────────────────────────────────────────
# HOST MODEL
# ─────────────────────────────────────────────

@dataclass
class LiveHost:
    fqdn        : str
    url         : str
    final_url   : str
    ip          : str = ""
    status      : int = 0
    server      : str = ""
    powered_by  : str = ""
    cdn         : str = ""
    waf         : str = ""
    title       : str = ""
    scheme      : str = "https"
    headers     : Dict[str, str] = field(default_factory=dict)
    cookies     : List[str] = field(default_factory=list)
    tech        : List[TechStack] = field(default_factory=list)
    cert        : Optional[Certificate] = None
    ports       : List[PortResult] = field(default_factory=list)
    redirect_chain: List[str] = field(default_factory=list)
    response_time_ms: int = 0
    is_spa      : bool = False


# ─────────────────────────────────────────────
# SUBDOMAIN MODEL
# ─────────────────────────────────────────────

@dataclass
class Subdomain:
    fqdn        : str
    ips         : List[str] = field(default_factory=list)
    cname       : str = ""
    source      : str = ""        # which tool/source found it
    dns_records : List[DNSRecord] = field(default_factory=list)
    is_wildcard : bool = False
    live_host   : Optional[LiveHost] = None


# ─────────────────────────────────────────────
# JS INTELLIGENCE AGGREGATE
# ─────────────────────────────────────────────

@dataclass
class JSIntelligence:
    files           : List[JSFile] = field(default_factory=list)
    # Aggregated across all files
    all_api_urls    : List[str] = field(default_factory=list)
    all_api_paths   : List[str] = field(default_factory=list)
    all_transfer_paths: List[str] = field(default_factory=list)
    all_auth_headers: List[str] = field(default_factory=list)
    all_jwt_secrets : List[str] = field(default_factory=list)
    all_api_keys    : List[str] = field(default_factory=list)
    all_s3_buckets  : List[str] = field(default_factory=list)
    all_private_ips : List[str] = field(default_factory=list)
    all_websockets  : List[str] = field(default_factory=list)
    all_firebase    : List[str] = field(default_factory=list)


# ─────────────────────────────────────────────
# MODULE REPORT BLOCKS
# ─────────────────────────────────────────────

@dataclass
class ModuleReport:
    module_name  : str
    started_at   : str = ""
    finished_at  : str = ""
    duration_sec : float = 0.0
    status       : str = "ok"    # ok, error, skipped
    error        : str = ""
    summary      : Dict[str, Any] = field(default_factory=dict)
    data         : Dict[str, Any] = field(default_factory=dict)
    findings     : List[Finding] = field(default_factory=list)

    def start(self):
        self.started_at = datetime.utcnow().isoformat()

    def finish(self, status="ok", error=""):
        self.finished_at = datetime.utcnow().isoformat()
        try:
            from datetime import datetime as dt
            s = dt.fromisoformat(self.started_at)
            f = dt.fromisoformat(self.finished_at)
            self.duration_sec = round((f - s).total_seconds(), 2)
        except Exception:
            pass
        self.status = status
        self.error  = error


# ─────────────────────────────────────────────
# UNIFIED RECON REPORT
# ─────────────────────────────────────────────

@dataclass
class ReconReport:
    # Target info
    target          : str
    generated_at    : str = field(default_factory=lambda: datetime.utcnow().isoformat())
    engine_version  : str = "2.1.0"

    # DNS & WHOIS
    dns_records     : List[DNSRecord] = field(default_factory=list)
    whois           : Optional[WhoisInfo] = None
    asn             : Optional[ASNInfo] = None

    # Discovery
    subdomains      : List[Subdomain] = field(default_factory=list)
    live_hosts      : List[LiveHost] = field(default_factory=list)

    # Intelligence
    js_intel        : Optional[JSIntelligence] = None
    crawled_links   : List[CrawledLink] = field(default_factory=list)
    parameters      : List[Parameter] = field(default_factory=list)

    # Module reports (per-module blocks)
    module_cert_transparency : Optional[ModuleReport] = None
    module_dns_enum          : Optional[ModuleReport] = None
    module_osint             : Optional[ModuleReport] = None
    module_whois_asn         : Optional[ModuleReport] = None
    module_subdomain_brute   : Optional[ModuleReport] = None
    module_port_scan         : Optional[ModuleReport] = None
    module_web_probe         : Optional[ModuleReport] = None
    module_cdn_bypass        : Optional[ModuleReport] = None
    module_js_intel          : Optional[ModuleReport] = None
    module_link_crawler      : Optional[ModuleReport] = None
    module_param_extractor   : Optional[ModuleReport] = None
    # New modules (v2)
    module_nuclei_scan       : Optional[ModuleReport] = None
    module_takeover          : Optional[ModuleReport] = None
    module_screenshots       : Optional[ModuleReport] = None
    module_cms_probes        : Optional[ModuleReport] = None
    module_graphql_intel     : Optional[ModuleReport] = None
    module_swagger_intel     : Optional[ModuleReport] = None
    module_git_secrets       : Optional[ModuleReport] = None
    module_favicon_hash      : Optional[ModuleReport] = None
    module_cloud_assets      : Optional[ModuleReport] = None
    # New modules (v2.1)
    module_service_exposure  : Optional[ModuleReport] = None
    module_local_exposure    : Optional[ModuleReport] = None
    module_tech_cve          : Optional[ModuleReport] = None

    # Aggregated findings across all modules
    findings        : List[Finding] = field(default_factory=list)

    def all_findings(self) -> List[Finding]:
        """Collect findings from all module reports + top-level."""
        all_f = list(self.findings)
        for attr in vars(self):
            if attr.startswith("module_"):
                mod = getattr(self, attr, None)
                if mod is not None and isinstance(mod, ModuleReport):
                    all_f += mod.findings
        # Dedupe by (title, url, module) so the same finding doesn't count twice
        seen = set()
        deduped = []
        for f in all_f:
            key = (f.title, f.url, f.module)
            if key in seen:
                continue
            seen.add(key)
            deduped.append(f)
        severity_order = {"critical": 0, "high": 1, "medium": 2, "low": 3, "info": 4}
        deduped.sort(key=lambda f: severity_order.get(f.severity, 99))
        return deduped

    def stats(self) -> Dict[str, Any]:
        all_f = self.all_findings()
        return {
            "subdomains_found"  : len(self.subdomains),
            "live_hosts"        : len(self.live_hosts),
            "total_findings"    : len(all_f),
            "critical"          : sum(1 for f in all_f if f.severity == "critical"),
            "high"              : sum(1 for f in all_f if f.severity == "high"),
            "medium"            : sum(1 for f in all_f if f.severity == "medium"),
            "low"               : sum(1 for f in all_f if f.severity == "low"),
            "info"              : sum(1 for f in all_f if f.severity == "info"),
            "open_ports_total"  : sum(len(h.ports) for h in self.live_hosts),
            "js_files_analyzed" : len(self.js_intel.files) if self.js_intel else 0,
            "links_crawled"     : len(self.crawled_links),
            "parameters_found"  : len(self.parameters),
        }

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)
