"""
AeroSecLab Recon Engine — Core: Risk Scoring Engine

Converts the raw finding list into a quantitative risk score for:
  - each individual finding
  - each asset (live host / subdomain)
  - the target as a whole

Scoring model:
  Base severity points:
    critical = 40, high = 15, medium = 5, low = 1, info = 0.2

  Finding multipliers:
    x1.5 if finding has a CVE ID
    x1.3 if tag "credentials" or "critical" or "auth-bypass"
    x1.2 if tag "takeover" (ownership impact)
    x0.6 if tag "version-disclosure" only (often informational-only)

  Asset exposure multiplier:
    x1.4  if host.status == 200 and no WAF
    x1.2  if host is listed in passive DNS / in SAN of apex cert
    x0.8  if host is behind major CDN and WAF

  Asset sensitivity multiplier:
    x1.5  if tech contains admin/dev tool (Jenkins, Strapi admin, Grafana, etc.)
    x1.4  if fqdn contains api/auth/admin/internal
    x1.3  if fqdn contains prod/production

Target-level score is min(100, Σ(asset_scores) / scaling).
Each tier gets a letter grade:
    A: 0-10    (clean)
    B: 11-25   (minor issues)
    C: 26-45   (notable concerns)
    D: 46-70   (significant exposure)
    F: 71-100  (critical posture)
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional

from .models import Finding, LiveHost, ReconReport, Subdomain


@dataclass
class FindingScore:
    finding : Finding
    score   : float
    reasons : List[str] = field(default_factory=list)


@dataclass
class AssetScore:
    fqdn         : str
    url          : str
    raw_score    : float        # sum of finding scores weighted by asset multipliers
    finding_count: int
    critical_count: int
    high_count   : int
    medium_count : int
    low_count    : int
    info_count   : int
    findings     : List[FindingScore] = field(default_factory=list)
    notes        : List[str] = field(default_factory=list)


@dataclass
class TargetScore:
    target       : str
    score        : float        # 0-100
    grade        : str          # A/B/C/D/F
    grade_color  : str          # hex
    summary      : str          # 1-line description
    per_asset    : Dict[str, AssetScore] = field(default_factory=dict)
    top_findings : List[FindingScore]    = field(default_factory=list)


# ─────────────────────────────────────────────
# CONSTANTS
# ─────────────────────────────────────────────

BASE_SEVERITY_POINTS = {
    "critical": 40.0,
    "high":     15.0,
    "medium":   5.0,
    "low":      1.0,
    "info":     0.2,
}

GRADES = [
    (10.0,  "A", "#2ea44f", "Clean posture — only minor informational findings"),
    (25.0,  "B", "#84c36e", "Minor issues — mostly low-severity or hardening gaps"),
    (45.0,  "C", "#f0ad4e", "Notable concerns — medium-severity issues warrant attention"),
    (70.0,  "D", "#e9730d", "Significant exposure — multiple high-severity findings"),
    (100.1, "F", "#d73a49", "Critical posture — immediate remediation required"),
]

HIGH_VALUE_TAGS = {
    "credentials":      1.3,
    "critical":         1.3,
    "auth-bypass":      1.3,
    "rce-risk":         1.4,
    "takeover":         1.2,
    "open-registration":1.2,
    "full-repo":        1.3,
    "no-auth":          1.25,
    "public-list":      1.2,
    "origin-ip":        1.15,
}

LOW_VALUE_TAGS = {
    "version-disclosure": 0.6,
}


# ─────────────────────────────────────────────
# SCORING
# ─────────────────────────────────────────────

def score_finding(finding: Finding) -> FindingScore:
    """Score a single finding."""
    reasons: List[str] = []

    base = BASE_SEVERITY_POINTS.get(finding.severity, 0.2)
    reasons.append(f"base: {finding.severity}→{base}")

    score = base

    # CVE multiplier
    if finding.cve:
        score *= 1.5
        reasons.append(f"CVE boost (x1.5): {finding.cve}")

    # Tag-based multipliers
    tags_lower = [t.lower() for t in (finding.tags or [])]

    # Apply the strongest high-value multiplier
    high_multipliers = [HIGH_VALUE_TAGS[t] for t in tags_lower
                        if t in HIGH_VALUE_TAGS]
    if high_multipliers:
        m = max(high_multipliers)
        score *= m
        reasons.append(f"high-value tag (x{m})")

    # Apply the strongest low-value multiplier (dampener)
    low_multipliers = [LOW_VALUE_TAGS[t] for t in tags_lower
                       if t in LOW_VALUE_TAGS]
    if low_multipliers:
        # Don't dampen if already boosted (e.g. CVE + version-disclosure means real CVE)
        if not finding.cve and not high_multipliers:
            m = min(low_multipliers)
            score *= m
            reasons.append(f"info-only tag (x{m})")

    return FindingScore(finding=finding, score=round(score, 2), reasons=reasons)


def score_asset(host: LiveHost, findings: List[Finding]) -> AssetScore:
    """Score a single asset by summing relevant finding scores × asset multipliers."""
    # Filter findings that reference this host
    asset_findings: List[FindingScore] = []
    for f in findings:
        if _finding_references_asset(f, host):
            asset_findings.append(score_finding(f))

    raw = sum(fs.score for fs in asset_findings)

    # Asset exposure multiplier
    multiplier = 1.0
    notes: List[str] = []

    # Exposed live host
    if host.status == 200:
        if not host.waf:
            multiplier *= 1.4
            notes.append("x1.4: HTTP 200, no WAF")
        else:
            multiplier *= 0.85
            notes.append(f"x0.85: WAF present ({host.waf})")

    # FQDN sensitivity
    fqdn_lower = host.fqdn.lower()
    for kw, mul in [
        ("admin",    1.3),
        ("internal", 1.3),
        ("prod",     1.25),
        ("api",      1.15),
        ("auth",     1.2),
        ("dev",      1.1),
        ("stg",      1.1),
        ("test",     1.05),
    ]:
        if kw in fqdn_lower:
            multiplier *= mul
            notes.append(f"x{mul}: fqdn contains '{kw}'")
            break

    # Admin/dev tool detection
    admin_tech_keywords = {
        "jenkins", "grafana", "kibana", "gitlab", "nexus", "artifactory",
        "phpmyadmin", "adminer", "strapi", "solr", "druid", "metabase",
        "superset", "airflow",
    }
    tech_names = {t.name.lower() for t in host.tech}
    if any(k in " ".join(tech_names) for k in admin_tech_keywords):
        multiplier *= 1.35
        notes.append("x1.35: admin/dev tool detected")

    final = raw * multiplier

    counts: Dict[str, int] = {"critical": 0, "high": 0, "medium": 0, "low": 0, "info": 0}
    for fs in asset_findings:
        counts[fs.finding.severity] = counts.get(fs.finding.severity, 0) + 1

    return AssetScore(
        fqdn          = host.fqdn,
        url           = host.url,
        raw_score     = round(final, 2),
        finding_count = len(asset_findings),
        critical_count= counts.get("critical", 0),
        high_count    = counts.get("high", 0),
        medium_count  = counts.get("medium", 0),
        low_count     = counts.get("low", 0),
        info_count    = counts.get("info", 0),
        findings      = asset_findings,
        notes         = notes,
    )


def _finding_references_asset(f: Finding, host: LiveHost) -> bool:
    """Does finding f pertain to this host?"""
    if not f.url:
        return False
    url_lower = f.url.lower()
    return (
        host.fqdn in url_lower or
        host.url in url_lower or
        url_lower == host.fqdn
    )


def score_target(report: ReconReport) -> TargetScore:
    """Compute per-asset and overall target scores."""
    all_findings = report.all_findings()

    per_asset: Dict[str, AssetScore] = {}
    for host in report.live_hosts:
        asset_score = score_asset(host, all_findings)
        per_asset[host.fqdn] = asset_score

    # Orphan findings (not tied to a specific asset) - still count toward target
    orphan_score = 0.0
    attached_fqdns = {h.fqdn for h in report.live_hosts}
    attached_urls  = {h.url for h in report.live_hosts}
    for f in all_findings:
        if not any(fqdn in (f.url or "") for fqdn in attached_fqdns) and \
           not any(u in (f.url or "")    for u in attached_urls):
            orphan_score += score_finding(f).score

    # Aggregate: the target score is a normalized sum of asset scores.
    # We use a log-soft scaling so a single host with dozens of findings
    # can still hit F, but one single critical on a clean org stays B/C.
    total_raw = sum(a.raw_score for a in per_asset.values()) + orphan_score
    # Scaling: 100 points = raw total of ~250
    scaled = min(100.0, (total_raw / 2.5))

    # Also take max per-asset score if one single asset is catastrophic
    if per_asset:
        max_asset_score = max(a.raw_score for a in per_asset.values())
        # If any single asset has >100 raw, lock target to at least D
        if max_asset_score > 100 and scaled < 50:
            scaled = max(scaled, 50.0)

    grade_char, grade_color, grade_summary = _grade_for_score(scaled)

    # Top findings (global, not per-asset)
    all_scored = [score_finding(f) for f in all_findings]
    all_scored.sort(key=lambda fs: fs.score, reverse=True)
    top_findings = all_scored[:15]

    return TargetScore(
        target       = report.target,
        score        = round(scaled, 1),
        grade        = grade_char,
        grade_color  = grade_color,
        summary      = grade_summary,
        per_asset    = per_asset,
        top_findings = top_findings,
    )


def _grade_for_score(score: float) -> tuple:
    for threshold, grade, color, summary in GRADES:
        if score <= threshold:
            return grade, color, summary
    return "F", "#d73a49", "Critical posture"


# ─────────────────────────────────────────────
# DIFF — compare two report.json snapshots
# ─────────────────────────────────────────────

def diff_reports(previous: Dict, current: Dict) -> Dict:
    """
    Compare two report.json dicts and return a structured diff:
      - new_live_hosts:       hosts present now, absent before
      - removed_live_hosts:   hosts present before, absent now
      - new_findings:         findings present now, absent before
      - resolved_findings:    findings present before, absent now
      - score_delta:          numerical change in target risk score
      - grade_change:         tuple (prev_grade, current_grade) or None

    Findings are matched by (severity, title, url) tuple — the same key
    the report uses for finding IDs.
    """
    prev_findings = {
        (f.get('severity'), f.get('title'), f.get('url'))
        for f in previous.get('findings', [])
    }
    curr_findings = {
        (f.get('severity'), f.get('title'), f.get('url'))
        for f in current.get('findings', [])
    }
    prev_hosts = {h.get('url') for h in previous.get('live_hosts', []) if h.get('url')}
    curr_hosts = {h.get('url') for h in current.get('live_hosts', []) if h.get('url')}

    new_findings = [
        f for f in current.get('findings', [])
        if (f.get('severity'), f.get('title'), f.get('url')) not in prev_findings
    ]
    resolved_findings = [
        f for f in previous.get('findings', [])
        if (f.get('severity'), f.get('title'), f.get('url')) not in curr_findings
    ]

    prev_score = (previous.get('risk', {}) or {}).get('score', 0) or 0
    curr_score = (current.get('risk', {}) or {}).get('score', 0) or 0
    prev_grade = (previous.get('risk', {}) or {}).get('grade')
    curr_grade = (current.get('risk', {}) or {}).get('grade')

    return {
        "new_live_hosts": sorted(curr_hosts - prev_hosts),
        "removed_live_hosts": sorted(prev_hosts - curr_hosts),
        "new_findings": new_findings,
        "resolved_findings": resolved_findings,
        "score_delta": round(curr_score - prev_score, 2),
        "grade_change": [prev_grade, curr_grade] if prev_grade != curr_grade else None,
        "previous_generated_at": previous.get('meta', {}).get('generated_at'),
    }


def executive_summary_bullets(target_score: TargetScore,
                              report: ReconReport,
                              max_bullets: int = 7) -> List[str]:
    """Generate a concise executive-summary bullet list from the scored report."""
    bullets: List[str] = []
    stats = report.stats()

    # Opening statement
    bullets.append(
        f"Assessment identified **{stats['total_findings']}** findings across "
        f"**{stats['live_hosts']}** live web assets and **{stats['subdomains_found']}** "
        f"subdomains. Overall risk grade: **{target_score.grade}** "
        f"({target_score.score}/100)."
    )

    # Severity breakdown
    if stats["critical"] or stats["high"]:
        bullets.append(
            f"**Severity distribution:** "
            f"{stats['critical']} critical, {stats['high']} high, "
            f"{stats['medium']} medium, {stats['low']} low, {stats['info']} info."
        )

    # Top 3 findings
    if target_score.top_findings:
        top3 = target_score.top_findings[:3]
        names = ", ".join(f'"{fs.finding.title[:60]}"' for fs in top3)
        bullets.append(f"**Top findings by risk weight:** {names}.")

    # Riskiest asset
    if target_score.per_asset:
        ranked = sorted(target_score.per_asset.values(),
                       key=lambda a: a.raw_score, reverse=True)
        if ranked and ranked[0].raw_score > 0:
            top_asset = ranked[0]
            bullets.append(
                f"**Most-at-risk asset:** `{top_asset.fqdn}` "
                f"(score: {top_asset.raw_score:.0f}, "
                f"findings: {top_asset.critical_count} critical, "
                f"{top_asset.high_count} high, {top_asset.medium_count} medium)."
            )

    # Takeover
    takeover_findings = [f for f in report.all_findings()
                         if "takeover" in (f.tags or []) and f.severity in ("critical", "high")]
    if takeover_findings:
        bullets.append(
            f"**Subdomain takeover vulnerabilities:** "
            f"{len(takeover_findings)} dangling DNS records point to claimable cloud resources."
        )

    # CVE density
    cve_findings = [f for f in report.all_findings() if f.cve]
    if cve_findings:
        bullets.append(
            f"**{len(cve_findings)}** findings map to known CVEs "
            f"(prioritize patching affected versions)."
        )

    # Info-disclosure density
    info_tags = ["info-disclosure", "credentials", "git-exposure"]
    leak_findings = [f for f in report.all_findings()
                     if any(t in (f.tags or []) for t in info_tags)]
    if len(leak_findings) >= 5:
        bullets.append(
            f"**Information disclosure surface is broad:** {len(leak_findings)} findings "
            f"reveal internal data, credentials, or repository contents."
        )

    return bullets[:max_bullets]
