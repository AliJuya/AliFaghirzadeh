"""
AeroSecLab Recon Engine — Global Configuration
All tool paths, timeouts, wordlists, and engine settings.
"""

from __future__ import annotations
import os
import shutil
from pathlib import Path
from typing import Dict, List, Optional

# ─────────────────────────────────────────────
# ENGINE META
# ─────────────────────────────────────────────
ENGINE_VERSION = "2.1.0"
ENGINE_NAME    = "AeroSecLab Recon Engine"

# ─────────────────────────────────────────────
# PATHS
# ─────────────────────────────────────────────
BASE_DIR      = Path(__file__).parent.parent
WORDLIST_DIR  = BASE_DIR / "wordlists"
OUTPUT_BASE   = Path(os.environ.get("AEROSEC_OUTPUT", "/home/aero/lab/results"))
TOOLS_DIR     = Path(os.environ.get("AEROSEC_TOOLS", "/home/aero/go/bin"))

# Common tool locations
TOOL_PATHS = {
    # Go tools (installed via go install)
    "subfinder"    : [str(TOOLS_DIR / "subfinder"),    "/usr/local/bin/subfinder",    shutil.which("subfinder")],
    "amass"        : [str(TOOLS_DIR / "amass"),         "/usr/local/bin/amass",         shutil.which("amass")],
    "httpx"        : [str(TOOLS_DIR / "httpx"),         "/usr/local/bin/httpx",         shutil.which("httpx")],
    "dnsx"         : [str(TOOLS_DIR / "dnsx"),          "/usr/local/bin/dnsx",          shutil.which("dnsx")],
    "katana"       : [str(TOOLS_DIR / "katana"),        "/usr/local/bin/katana",        shutil.which("katana")],
    "waybackurls"  : [str(TOOLS_DIR / "waybackurls"),  "/usr/local/bin/waybackurls",   shutil.which("waybackurls")],
    "assetfinder"  : [str(TOOLS_DIR / "assetfinder"),  "/usr/local/bin/assetfinder",   shutil.which("assetfinder")],
    "hakrawler"    : [str(TOOLS_DIR / "hakrawler"),    "/usr/local/bin/hakrawler",     shutil.which("hakrawler")],
    "gau"          : [str(TOOLS_DIR / "gau"),           "/usr/local/bin/gau",           shutil.which("gau")],
    "tlsx"         : [str(TOOLS_DIR / "tlsx"),          "/usr/local/bin/tlsx",          shutil.which("tlsx")],
    "naabu"        : [str(TOOLS_DIR / "naabu"),         "/usr/local/bin/naabu",         shutil.which("naabu")],
    "nuclei"       : [str(TOOLS_DIR / "nuclei"),        "/usr/local/bin/nuclei",        shutil.which("nuclei")],
    "gowitness"    : [str(TOOLS_DIR / "gowitness"),    "/usr/local/bin/gowitness",     shutil.which("gowitness")],
    "findomain"    : [str(TOOLS_DIR / "findomain"),    "/usr/local/bin/findomain",     shutil.which("findomain")],
    # System tools
    "nmap"         : ["/usr/bin/nmap",    shutil.which("nmap")],
    "masscan"      : ["/usr/bin/masscan", shutil.which("masscan")],
    "dig"          : ["/usr/bin/dig",     shutil.which("dig")],
    "whois"        : ["/usr/bin/whois",   shutil.which("whois")],
    "curl"         : ["/usr/bin/curl",    shutil.which("curl")],
    "ffuf"         : ["/usr/bin/ffuf",    "/usr/local/bin/ffuf", shutil.which("ffuf")],
    "gobuster"     : ["/usr/bin/gobuster",shutil.which("gobuster")],
    "whatweb"      : ["/usr/bin/whatweb", shutil.which("whatweb")],
    "wafw00f"      : [shutil.which("wafw00f"), "/usr/local/bin/wafw00f"],
    "massdns"      : ["/usr/bin/massdns", "/usr/local/bin/massdns", shutil.which("massdns")],
    "dnsrecon"     : [shutil.which("dnsrecon"), "/usr/bin/dnsrecon"],
    "arjun"        : [shutil.which("arjun"), "/usr/local/bin/arjun"],
    "paramspider"  : [shutil.which("paramspider")],
    "git"          : ["/usr/bin/git",     shutil.which("git")],
    "go"           : ["/usr/local/go/bin/go", "/usr/bin/go", shutil.which("go")],
    "pip3"         : ["/usr/bin/pip3",    shutil.which("pip3")],
    "apt"          : ["/usr/bin/apt",     shutil.which("apt")],
}


def get_tool(name: str) -> Optional[str]:
    """Return the first valid path for a tool, or None."""
    paths = TOOL_PATHS.get(name, [])
    for p in paths:
        if p and Path(p).exists():
            return p
    return None


def tool_available(name: str) -> bool:
    return get_tool(name) is not None


# ─────────────────────────────────────────────
# THREADING & PERFORMANCE
# ─────────────────────────────────────────────
MAX_THREADS_SUBDOMAIN_PROBE = 50   # concurrent HTTP probes
MAX_THREADS_PORT_SCAN       = 10   # parallel nmap instances
MAX_THREADS_MODULE          = 8    # within-module parallelism
MAX_THREADS_JS              = 10   # concurrent JS downloads

REQUEST_TIMEOUT    = 10     # seconds per HTTP request
CONNECT_TIMEOUT    = 5      # TCP connect timeout
DNS_TIMEOUT        = 5      # DNS query timeout
TOOL_TIMEOUT       = 300    # max seconds for any tool subprocess
MASSCAN_RATE       = 10000  # packets per second
FFUF_RATE          = 500    # requests per second for ffuf

# ─────────────────────────────────────────────
# HTTP
# ─────────────────────────────────────────────
USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:125.0) Gecko/20100101 Firefox/125.0",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_4_1) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4.1 Safari/605.1.15",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36 Edg/124.0.0.0",
]

BASE_HEADERS = {
    "Accept"         : "text/html,application/xhtml+xml,application/json,*/*;q=0.9",
    "Accept-Language": "en-US,en;q=0.9",
    "Accept-Encoding": "gzip, deflate, br",
    "Connection"     : "keep-alive",
}

MAX_JS_SIZE_MB    = 20
MAX_CRAWL_DEPTH   = 3
MAX_CRAWL_PAGES   = 500
MAX_JS_FILES      = 25

# ─────────────────────────────────────────────
# PORT SCANNING
# ─────────────────────────────────────────────
# Web-focused port list
WEB_PORTS = [
    80, 81, 443, 591, 2082, 2086, 2087, 2095, 2096,
    3000, 3001, 3002, 3128, 4000, 4443, 4848,
    5000, 5001, 5601, 6443, 7000, 7001, 7443,
    8000, 8001, 8008, 8009, 8080, 8081, 8082, 8083,
    8084, 8085, 8086, 8087, 8088, 8089, 8090, 8091,
    8161, 8172, 8180, 8181, 8222, 8243, 8280, 8281,
    8333, 8443, 8444, 8500, 8530, 8531, 8600, 8800,
    8880, 8888, 8983, 9000, 9001, 9002, 9080, 9090,
    9091, 9200, 9300, 9443, 9800, 9981, 10000,
    10250, 10443, 11211, 15672, 16080, 27017,
]

ALL_PORTS_RANGE = "1-65535"
TOP_1000        = "--top-ports 1000"

# ─────────────────────────────────────────────
# WORDLISTS
# ─────────────────────────────────────────────

# Exchange-specific subdomain prefixes
EXCHANGE_SUBDOMAINS: List[str] = [
    # APIs
    "api", "api2", "api3", "api4", "api5", "api-v2", "api-v3",
    "api-demo", "api-test", "api-stg", "api-prod", "api-dev",
    "api-internal", "api-private", "api-public", "api-gateway",
    "api-referral", "api-saba", "api-sejel", "api-staking",
    "api-ws", "api-websocket",
    # Admin/Management
    "admin", "administrator", "superadmin", "backoffice",
    "dashboard", "panel", "control", "management", "manager",
    "cp", "controlpanel", "adminpanel",
    # Frontend
    "www", "app", "web", "mobile", "m", "pwa",
    "platform", "trade", "exchange", "market",
    # CMS / Content
    "cms", "cms-demo", "cms-dev", "cms-stg", "cms-prod",
    "strapi", "content", "wp", "wordpress", "blog", "news",
    "media", "uploads", "assets2",
    # Auth
    "auth", "oauth", "sso", "login", "accounts", "identity",
    "iam", "keycloak", "id",
    # Dev environments
    "dev", "dev2", "dev3", "test", "test2", "stg", "staging",
    "preprod", "uat", "qa", "sandbox", "beta", "demo",
    "local", "internal-dev",
    # WebSocket
    "ws", "wss", "socket", "websocket", "realtime", "live",
    "stream", "push", "notify",
    # Finance/Wallet
    "pay", "payment", "gateway", "checkout", "billing",
    "wallet", "funds", "finance", "treasury", "bank",
    "deposit", "withdraw", "transfer",
    # Exchange specific
    "launchpad", "staking", "earn", "defi", "swap",
    "futures", "spot", "margin", "derivatives",
    "otc", "p2p", "fiat",
    # Support
    "support", "help", "destek", "hc", "uye-destek",
    "ticket", "helpdesk",
    # Static / CDN
    "static", "assets", "cdn", "cdn2", "media", "img",
    "images", "files", "storage", "s3", "backup",
    "bstatic", "gstatics", "statics",
    # Monitoring
    "status", "monitor", "health", "uptime", "ping",
    "metrics", "grafana", "kibana", "prometheus",
    "elastic", "elasticsearch", "logstash",
    # Docs
    "docs", "doc", "developer", "developers", "dev-docs",
    "swagger", "openapi", "apidoc", "redoc",
    # HR/Internal
    "ik", "hr", "careers", "jobs", "recruit",
    "analiz", "analytics", "report", "reporting",
    # Infrastructure
    "internal", "intranet", "corp", "vpn", "remote",
    "git", "gitlab", "github", "bitbucket", "jenkins",
    "ci", "cd", "cicd", "deploy", "k8s", "kubernetes",
    "docker", "registry",
    # Mail
    "mail", "smtp", "webmail", "email", "mx", "imap",
    # Finance platform specific
    "ohlc", "chart", "charting", "tradingview",
    "akademi", "academy", "learn", "education",
    "research", "donate", "donation", "donate",
    "dig", "explore", "explorer",
    # Global/International
    "global", "mtglobal", "orellius", "international",
    "world", "eu", "us", "tr", "ir", "fa",
    # Misc
    "verify", "kyc", "aml", "compliance", "legal",
    "affiliate", "referral", "partner",
    "webhook", "callback", "notify", "notification",
    "feed", "rss", "sitemap",
    "old", "legacy", "archive", "v1", "v2",
]

# Paths for sensitive file discovery
SENSITIVE_PATHS: List[str] = [
    "/.env", "/.env.local", "/.env.production", "/.env.dev",
    "/.env.backup", "/.env.bak", "/.env.old", "/.env.example",
    "/.git/HEAD", "/.git/config", "/.git/index",
    "/.git/COMMIT_EDITMSG", "/.git/logs/HEAD",
    "/.gitignore", "/.gitconfig",
    "/.DS_Store", "/Thumbs.db",
    "/config.php", "/config.json", "/config.yaml", "/config.yml",
    "/configuration.php", "/settings.py", "/settings.php",
    "/wp-config.php", "/wp-config.php.bak",
    "/database.php", "/db.php", "/db.json",
    "/composer.json", "/composer.lock",
    "/package.json", "/package-lock.json", "/yarn.lock",
    "/requirements.txt", "/Pipfile", "/Pipfile.lock",
    "/Dockerfile", "/docker-compose.yml", "/docker-compose.yaml",
    "/.dockerenv",
    "/server-status", "/server-status?auto", "/server-info",
    "/phpinfo.php", "/info.php", "/php.php", "/test.php",
    "/backup.zip", "/backup.tar.gz", "/backup.sql",
    "/dump.sql", "/database.sql", "/db.sql",
    "/robots.txt", "/sitemap.xml", "/crossdomain.xml",
    "/security.txt", "/.well-known/security.txt",
    "/actuator", "/actuator/env", "/actuator/health",
    "/actuator/info", "/actuator/mappings", "/actuator/beans",
    "/actuator/trace", "/actuator/dump", "/actuator/loggers",
    "/health", "/healthz", "/ready", "/readyz", "/live", "/livez",
    "/metrics", "/prometheus", "/stats",
    "/swagger-ui.html", "/swagger-ui/", "/swagger-ui/index.html",
    "/swagger.json", "/swagger.yaml",
    "/v2/api-docs", "/v3/api-docs", "/openapi.json", "/openapi.yaml",
    "/api-docs", "/api/swagger", "/api/docs",
    "/graphql", "/graphiql", "/playground",
    "/console", "/h2-console", "/h2/",
    "/phpmyadmin", "/phpmyadmin/", "/pma", "/mysql",
    "/adminer", "/adminer.php",
    "/debug", "/debug/pprof", "/debug/vars",
    "/trace", "/__debug__/",
    "/admin", "/admin/", "/admin/login",
    "/admin/init", "/admin/information", "/admin/project-type",
    "/api/users", "/api/users/me", "/api/users?populate=*",
    "/api/auth/local/register", "/api/auth/local",
    "/ws/info", "/sockjs-node/info",
    "/signalr/negotiate", "/hubs/negotiate",
    "/users/sign_in", "/api/v4/version",
    "/api/v4/projects?visibility=public",
    "/.aws/credentials", "/.ssh/id_rsa", "/.ssh/known_hosts",
    "/private.key", "/server.key", "/ssl.key",
    "/id_rsa", "/id_dsa", "/id_ecdsa",
    "/web.config", "/applicationHost.config",
    "/crossdomain.xml", "/clientaccesspolicy.xml",
    "/trace.axd", "/elmah.axd",
    "/vendor/phpunit/phpunit/src/Util/PHP/eval-stdin.php",
    "/.svn/entries", "/.hg/hgrc",
]

# CDN/WAF fingerprints
CDN_FINGERPRINTS: Dict[str, List[str]] = {
    "cloudflare"  : ["cloudflare", "cf-ray", "cf-cache-status", "__cfduid"],
    "cloudfront"  : ["cloudfront", "x-amz-cf-id", "x-amz-cf-pop"],
    "arvancloud"  : ["arvancloud", "x-arvan-cache", "x-sid", "ar-arvan"],
    "akamai"      : ["akamai", "x-check-cacheable", "x-akamai-transformed"],
    "fastly"      : ["fastly", "x-fastly-request-id", "x-served-by"],
    "incapsula"   : ["incapsula", "x-iinfo", "visid_incap"],
    "sucuri"      : ["sucuri", "x-sucuri-id", "x-sucuri-cache"],
    "bunnycdn"    : ["bunnycdn", "x-bunny-cache", "x-pulled-from"],
    "stackpath"   : ["stackpath", "x-sp-url"],
}

WAF_FINGERPRINTS: Dict[str, List[str]] = {
    "cloudflare"  : ["cloudflare", "attention required", "cf-mitigated"],
    "arvancloud"  : ["arvancloud", "arvan", "access denied"],
    "aws_waf"     : ["aws waf", "x-amzn-requestid"],
    "modsecurity" : ["mod_security", "modsecurity", "naxsi"],
    "f5_big_ip"   : ["bigip", "f5", "x-wa-info", "x-cnection"],
    "barracuda"   : ["barracuda", "barra_counter_session"],
    "imperva"     : ["imperva", "incapsula", "_imfm_"],
    "fortiweb"    : ["fortiweb", "fortigate"],
}

# API key patterns for JS mining
API_KEY_PATTERNS: Dict[str, str] = {
    "google_api"       : r'AIza[0-9A-Za-z_-]{35}',
    "firebase_url"     : r'https://[a-z0-9-]+\.firebaseio\.com',
    "firebase_key"     : r'(?:firebase|FIREBASE)["\s:=]+["\`]([A-Za-z0-9_-]{35,})["\`]',
    "aws_access_key"   : r'AKIA[0-9A-Z]{16}',
    "aws_secret"       : r'(?:aws_secret|AWS_SECRET)["\s:=]+["\`]([A-Za-z0-9/+=]{40})["\`]',
    "stripe_live"      : r'sk_live_[0-9a-zA-Z]{24,}',
    "stripe_pub"       : r'pk_live_[0-9a-zA-Z]{24,}',
    "github_token"     : r'ghp_[A-Za-z0-9]{36}',
    "jwt_token"        : r'eyJ[A-Za-z0-9_-]+\.eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+',
    "private_key"      : r'-----BEGIN (?:RSA |EC |DSA |OPENSSH )?PRIVATE KEY-----',
    "basic_auth"       : r'(?:Authorization|auth)["\s:=]+["\`]Basic [A-Za-z0-9+/=]{8,}["\`]',
    "bearer_token"     : r'(?:Authorization|auth)["\s:=]+["\`]Bearer ([A-Za-z0-9_.-]{20,})["\`]',
    "mailgun_key"      : r'key-[0-9a-zA-Z]{32}',
    "sendgrid_key"     : r'SG\.[A-Za-z0-9_-]{22}\.[A-Za-z0-9_-]{43}',
    "twilio_sid"       : r'AC[a-z0-9]{32}',
    "slack_token"      : r'xox[baprs]-[0-9A-Za-z-]+',
    "telegram_token"   : r'[0-9]{8,10}:[A-Za-z0-9_-]{35}',
    "generic_secret"   : r'(?:secret|password|passwd|pwd|token|key|api_key|apikey|access_key|auth_token|private_key)["\s:=]+["\`]([^\s"\'`]{8,64})["\`]',
}

# JS patterns for intelligence extraction
JS_PATTERNS: Dict[str, str] = {
    "api_base_urls"    : r'(?:baseUrl|apiUrl|API_URL|baseURL|endpoint|API_BASE|apiBase|API_ENDPOINT)["\s:=]+["\`](https?://[^"\`\s]{6,})["\`]',
    "all_urls"         : r'https?://[a-zA-Z0-9._-]+\.[a-zA-Z]{2,}(?:/[a-zA-Z0-9._/?=&%#-]*)?',
    "api_paths"        : r'["\`](/(?:api|v\d+|auth|admin|user|account|wallet|trade|market|order|deposit|withdraw|transfer|payment|fund|balance|portfolio)[a-zA-Z0-9/_.-]*)["\`]',
    "transfer_paths"   : r'["\`](/(?:transfer|withdraw|deposit|send|fund|payment|pay|remit|payout)[a-zA-Z0-9/_.-]*)["\`]',
    "auth_headers"     : r'(?:authHeader|x-auth-token|x-api-key|Authorization|Bearer|x-bitlo-auth|x-access-token)["\s:=]+["\`]([^"\`\s]{4,80})["\`]',
    "jwt_secrets"      : r'(?:jwtSecret|jwt_secret|JWT_SECRET|JWT_KEY|jwtKey|tokenSecret|TOKEN_SECRET)["\s:=]+["\`]([^"\`\s]{8,})["\`]',
    "api_keys"         : r'(?:apiKey|api_key|API_KEY|accessKey|ACCESS_KEY|appKey|APP_KEY|clientKey|CLIENT_KEY)["\s:=]+["\`]([a-zA-Z0-9_\-\.]{16,})["\`]',
    "s3_buckets"       : r'[a-zA-Z0-9._-]+\.s3[.-][a-zA-Z0-9._-]*\.amazonaws\.com',
    "private_ips"      : r'\b(?:10\.\d{1,3}\.\d{1,3}\.\d{1,3}|172\.(?:1[6-9]|2\d|3[01])\.\d{1,3}\.\d{1,3}|192\.168\.\d{1,3}\.\d{1,3})\b',
    "websocket_urls"   : r'wss?://[a-zA-Z0-9._/:\-]+',
    "stomp_channels"   : r'(?:subscribe|destination|SUBSCRIBE|SEND)\s*["\s:=]+["\`](/[a-zA-Z0-9/_.-]+)["\`]',
    "firebase"         : r'(?:projectId|authDomain|databaseURL|storageBucket|messagingSenderId)["\s:]+["\`]([^"\`]{4,})["\`]',
    "google_oauth"     : r'\d{12}-[a-zA-Z0-9_-]{32}\.apps\.googleusercontent\.com',
    "internal_hosts"   : r'(?:http://|https://|wss?://)((?:internal|intranet|local|dev|staging|test|admin|private)\.[a-zA-Z0-9._-]+)',
    "env_vars"         : r'process\.env\.([A-Z_]{4,})',
    "graphql_queries"  : r'(?:gql|graphql|GraphQL)`([^`]{10,})`',
}

# ─────────────────────────────────────────────
# OSINT API KEYS (optional, from env)
# ─────────────────────────────────────────────
SHODAN_API_KEY        = os.environ.get("SHODAN_API_KEY", "")
SECURITYTRAILS_KEY    = os.environ.get("SECURITYTRAILS_KEY", "")
CENSYS_API_ID         = os.environ.get("CENSYS_API_ID", "")
CENSYS_API_SECRET     = os.environ.get("CENSYS_API_SECRET", "")
VIRUSTOTAL_KEY        = os.environ.get("VIRUSTOTAL_KEY", "")
FOFA_EMAIL            = os.environ.get("FOFA_EMAIL", "")
FOFA_KEY              = os.environ.get("FOFA_KEY", "")

# ─────────────────────────────────────────────
# TOOL INSTALL SPECS
# ─────────────────────────────────────────────
# Each entry: (tool_name, install_method, install_command)
TOOL_INSTALL_SPECS = [
    # apt packages
    ("nmap",        "apt",  "nmap"),
    ("masscan",     "apt",  "masscan"),
    ("dig",         "apt",  "dnsutils"),
    ("whois",       "apt",  "whois"),
    ("curl",        "apt",  "curl"),
    ("ffuf",        "apt",  "ffuf"),
    ("gobuster",    "apt",  "gobuster"),
    ("whatweb",     "apt",  "whatweb"),
    ("dnsrecon",    "apt",  "dnsrecon"),
    ("git",         "apt",  "git"),
    ("go",          "apt",  "golang-go"),
    ("massdns",     "apt",  "massdns"),
    # Go tools
    ("subfinder",   "go",   "github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest"),
    ("httpx",       "go",   "github.com/projectdiscovery/httpx/cmd/httpx@latest"),
    ("dnsx",        "go",   "github.com/projectdiscovery/dnsx/cmd/dnsx@latest"),
    ("katana",      "go",   "github.com/projectdiscovery/katana/cmd/katana@latest"),
    ("naabu",       "go",   "github.com/projectdiscovery/naabu/v2/cmd/naabu@latest"),
    ("nuclei",      "go",   "github.com/projectdiscovery/nuclei/v3/cmd/nuclei@latest"),
    ("tlsx",        "go",   "github.com/projectdiscovery/tlsx/cmd/tlsx@latest"),
    ("assetfinder", "go",   "github.com/tomnomnom/assetfinder@latest"),
    ("waybackurls", "go",   "github.com/tomnomnom/waybackurls@latest"),
    ("gau",         "go",   "github.com/lc/gau/v2/cmd/gau@latest"),
    ("hakrawler",   "go",   "github.com/hakluke/hakrawler@latest"),
    ("gowitness",   "go",   "github.com/sensepost/gowitness@latest"),
    ("findomain",   "go",   "github.com/Edu4rdSHL/findomain@latest"),
    ("amass",       "go",   "github.com/owasp-amass/amass/v4/...@latest"),
    # pip packages
    ("wafw00f",     "pip",  "wafw00f"),
    ("arjun",       "pip",  "arjun"),
    ("paramspider", "pip",  "paramspider"),
]
