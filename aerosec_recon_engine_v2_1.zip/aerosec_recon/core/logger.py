"""
AeroSecLab Recon Engine — Logger
Unified colored logging across all modules.
"""

from __future__ import annotations
import sys
from datetime import datetime
from typing import List


class C:
    RED    = "\033[91m"
    GREEN  = "\033[92m"
    YELLOW = "\033[93m"
    BLUE   = "\033[94m"
    PURPLE = "\033[95m"
    CYAN   = "\033[96m"
    WHITE  = "\033[97m"
    BOLD   = "\033[1m"
    DIM    = "\033[2m"
    RESET  = "\033[0m"


_ICONS = {
    "INFO" : f"{C.BLUE}[*]{C.RESET}",
    "OK"   : f"{C.GREEN}[+]{C.RESET}",
    "WARN" : f"{C.YELLOW}[!]{C.RESET}",
    "ERR"  : f"{C.RED}[-]{C.RESET}",
    "HEAD" : f"{C.PURPLE}{C.BOLD}[>]{C.RESET}",
    "CRIT" : f"{C.RED}{C.BOLD}[!!]{C.RESET}",
    "TOOL" : f"{C.CYAN}[T]{C.RESET}",
    "FIND" : f"{C.YELLOW}{C.BOLD}[F]{C.RESET}",
}


def log(level: str, target: str, msg: str) -> None:
    ts   = datetime.now().strftime("%H:%M:%S")
    icon = _ICONS.get(level.upper(), "[?]")
    tgt  = f"{C.CYAN}[{target}]{C.RESET}"
    print(f"{C.DIM}{ts}{C.RESET} {icon} {tgt} {msg}", flush=True)


def log_finding(target: str, severity: str, title: str, url: str) -> None:
    sev_colors = {
        "critical": C.RED + C.BOLD,
        "high"    : C.YELLOW + C.BOLD,
        "medium"  : C.YELLOW,
        "low"     : C.BLUE,
        "info"    : C.DIM,
    }
    color = sev_colors.get(severity.lower(), "")
    icon  = "!!" if severity in ("critical", "high") else "!"
    print(
        f"{C.DIM}{datetime.now().strftime('%H:%M:%S')}{C.RESET} "
        f"{color}[{icon}]{C.RESET} "
        f"{C.CYAN}[{target}]{C.RESET} "
        f"{color}[{severity.upper()}] {title}{C.RESET} "
        f"{C.DIM}@ {url}{C.RESET}",
        flush=True
    )


def banner(target: str) -> None:
    print(f"""
{C.BOLD}{C.PURPLE}
╔══════════════════════════════════════════════════════════════╗
║          AeroSecLab — World-Class Recon Engine               ║
║          Authorized Security Assessment Framework            ║
╚══════════════════════════════════════════════════════════════╝{C.RESET}
  {C.CYAN}Target  :{C.RESET} {C.BOLD}{target}{C.RESET}
  {C.CYAN}Started :{C.RESET} {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S UTC')}
""", flush=True)


def phase_header(target: str, phase: str, modules: List[str]) -> None:
    print(f"\n{C.BOLD}{C.BLUE}{'─'*60}{C.RESET}", flush=True)
    print(f"{C.BOLD}{C.BLUE}  PHASE: {phase.upper()}{C.RESET}", flush=True)
    print(f"{C.DIM}  Modules: {', '.join(modules)}{C.RESET}", flush=True)
    print(f"{C.BOLD}{C.BLUE}{'─'*60}{C.RESET}\n", flush=True)


def progress(current: int, total: int, label: str = "") -> None:
    pct  = int(current / total * 100) if total else 0
    bar  = "█" * (pct // 5) + "░" * (20 - pct // 5)
    sys.stdout.write(
        f"\r  {C.DIM}[{bar}] {current}/{total} {label}{C.RESET}  "
    )
    sys.stdout.flush()
    if current >= total:
        print()
