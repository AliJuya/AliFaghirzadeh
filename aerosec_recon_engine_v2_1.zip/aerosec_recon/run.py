#!/usr/bin/env python3
"""
AeroSecLab Recon Engine — Entry Point

Usage examples:
  python3 run.py --target bitlo.com
  python3 run.py --target cms.bitlo.com --phases passive active
  python3 run.py --list /home/aero/lab/client_list.txt --threads 3
  python3 run.py --target tabdeal.org --modules cert_transparency dns_enum js_intel
  python3 run.py --target bitpin.ir --output /home/aero/lab/results/bitpin
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path


def parse_args():
    p = argparse.ArgumentParser(
        prog        = "aerosec_recon",
        description = "AeroSecLab World-Class Recon Engine",
        formatter_class=argparse.RawTextHelpFormatter,
        epilog="""
Phases:
  passive   — cert_transparency, dns_enum, osint, whois_asn
  active    — subdomain_brute, port_scan, web_probe, cdn_bypass,
              nuclei_scan, takeover, screenshots, cms_probes,
              service_exposure
  analysis  — js_intel, link_crawler, param_extractor,
              graphql_intel, swagger_intel, git_secrets,
              favicon_hash, cloud_assets,
              local_exposure, tech_cve

Modules (use --modules to select specific ones):
  Passive:  cert_transparency  dns_enum  osint  whois_asn
  Active:   subdomain_brute    port_scan  web_probe  cdn_bypass
            nuclei_scan        takeover   screenshots  cms_probes
            service_exposure
  Analysis: js_intel           link_crawler  param_extractor
            graphql_intel      swagger_intel git_secrets
            favicon_hash       cloud_assets
            local_exposure     tech_cve

Examples:
  # Full recon on single target
  python3 run.py --target bitlo.com

  # Only passive + JS analysis
  python3 run.py --target tabdeal.org --phases passive analysis

  # Run specific modules only
  python3 run.py --target bitpin.ir --modules js_intel link_crawler

  # Just nuclei + takeover
  python3 run.py --target example.com --modules nuclei_scan takeover

  # Re-run for diff comparison
  python3 run.py --target example.com --output ./results/example
  # ... wait some time ...
  python3 run.py --target example.com --output ./results/example
  # → report.md now includes a "Changes Since Previous Run" section

  # Multi-target from file, 3 parallel scans
  python3 run.py --list clients.txt --threads 3
        """
    )

    # Target selection
    tgt = p.add_mutually_exclusive_group(required=True)
    tgt.add_argument(
        "--target", "-t",
        metavar="DOMAIN",
        help="Single target domain (e.g. bitlo.com)"
    )
    tgt.add_argument(
        "--list", "-l",
        metavar="FILE",
        help="File with one target domain per line"
    )

    # Phase/module selection
    p.add_argument(
        "--phases",
        nargs="+",
        choices=["passive", "active", "analysis"],
        default=["passive", "active", "analysis"],
        metavar="PHASE",
        help="Phases to run (default: all)"
    )
    p.add_argument(
        "--modules",
        nargs="+",
        metavar="MODULE",
        choices=[
            # Passive
            "cert_transparency", "dns_enum", "osint", "whois_asn",
            # Active
            "subdomain_brute", "port_scan", "web_probe", "cdn_bypass",
            "nuclei_scan", "takeover", "screenshots", "cms_probes",
            "service_exposure",
            # Analysis
            "js_intel", "link_crawler", "param_extractor",
            "graphql_intel", "swagger_intel", "git_secrets",
            "favicon_hash", "cloud_assets",
            "local_exposure", "tech_cve",
        ],
        help="Run only specific modules (overrides --phases)"
    )

    # Output
    p.add_argument(
        "--output", "-o",
        metavar="DIR",
        help="Output directory (default: /home/aero/lab/results/<target>)"
    )

    # Multi-target parallelism
    p.add_argument(
        "--threads", "-T",
        type=int,
        default=1,
        metavar="N",
        help="Number of parallel target scans (default: 1)"
    )

    # Misc
    p.add_argument(
        "--verify-tools",
        action="store_true",
        help="Check tool availability and exit"
    )
    p.add_argument(
        "--install",
        action="store_true",
        help="Run installer to install missing tools"
    )

    return p.parse_args()


def main():
    args = parse_args()

    # Add parent dir to path so imports work
    sys.path.insert(0, str(Path(__file__).parent.parent))

    # Install mode
    if args.install:
        from aerosec_recon.installer import install_all
        install_all()
        return

    # Tool verification
    if args.verify_tools:
        from aerosec_recon.installer import verify_installation
        verify_installation()
        return

    # Import engine
    from aerosec_recon.core.orchestrator import Orchestrator, run_targets

    phases  = set(args.phases)
    modules = set(args.modules) if args.modules else None
    output  = Path(args.output) if args.output else None

    # Single target
    if args.target:
        orch = Orchestrator(
            target     = args.target,
            phases     = phases,
            modules    = modules,
            output_dir = output,
        )
        orch.run()

    # Multi-target from file
    elif args.list:
        list_path = Path(args.list)
        if not list_path.exists():
            print(f"[-] File not found: {args.list}", file=sys.stderr)
            sys.exit(1)

        targets = [
            line.strip() for line in list_path.read_text().splitlines()
            if line.strip() and not line.startswith("#")
        ]

        if not targets:
            print(f"[-] No targets in {args.list}", file=sys.stderr)
            sys.exit(1)

        print(f"[*] Loaded {len(targets)} targets from {args.list}")

        run_targets(
            targets     = targets,
            phases      = phases,
            modules     = modules,
            parallel    = args.threads,
            output_base = output,
        )


if __name__ == "__main__":
    main()
