"""
AeroSecLab Recon Engine — Export: Report Generator
Produces structured JSON report + human-readable Markdown report.
"""

from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path
from typing import Dict, List

from ..core.models import ReconReport, Finding, LiveHost, Subdomain


SEVERITY_EMOJI = {
    "critical": "🔴",
    "high"    : "🟠",
    "medium"  : "🟡",
    "low"     : "🔵",
    "info"    : "⚪",
}


class Reporter:
    def __init__(self, report: ReconReport, output_dir: Path):
        self.report     = report
        self.output_dir = output_dir
        self.output_dir.mkdir(parents=True, exist_ok=True)

    # ─── JSON ──────────────────────────────────────────────────────────

    def write_json(self):
        """Write the full report as JSON with per-module blocks."""
        data = {
            "meta": {
                "target"        : self.report.target,
                "generated_at"  : self.report.generated_at,
                "engine_version": self.report.engine_version,
                "stats"         : self.report.stats(),
            },
            "whois": self.report.whois.__dict__ if self.report.whois else {},
            "asn"  : self.report.asn.__dict__   if self.report.asn else {},
            "dns_records": [
                {"type": r.type, "value": r.value, "ttl": r.ttl}
                for r in self.report.dns_records
            ],
            "subdomains": [
                {
                    "fqdn"       : s.fqdn,
                    "ips"        : s.ips,
                    "cname"      : s.cname,
                    "source"     : s.source,
                    "live"       : s.live_host is not None,
                    "status"     : s.live_host.status if s.live_host else 0,
                    "title"      : s.live_host.title  if s.live_host else "",
                    "cdn"        : s.live_host.cdn    if s.live_host else "",
                    "waf"        : s.live_host.waf    if s.live_host else "",
                    "tech"       : [t.name for t in s.live_host.tech] if s.live_host else [],
                }
                for s in sorted(self.report.subdomains, key=lambda x: x.fqdn)
            ],
            "live_hosts": [
                {
                    "fqdn"      : h.fqdn,
                    "url"       : h.url,
                    "final_url" : h.final_url,
                    "ip"        : h.ip,
                    "status"    : h.status,
                    "title"     : h.title,
                    "server"    : h.server,
                    "cdn"       : h.cdn,
                    "waf"       : h.waf,
                    "is_spa"    : h.is_spa,
                    "tech"      : [t.name for t in h.tech],
                    "ports"     : [
                        {"port": p.port, "proto": p.protocol,
                         "service": p.service, "version": p.version}
                        for p in h.ports
                    ],
                    "cert": {
                        "subject"    : h.cert.subject,
                        "issuer"     : h.cert.issuer,
                        "san_domains": h.cert.san_domains,
                        "valid_from" : h.cert.valid_from,
                        "valid_to"   : h.cert.valid_to,
                        "expired"    : h.cert.expired,
                        "self_signed": h.cert.self_signed,
                    } if h.cert else {},
                }
                for h in self.report.live_hosts
            ],
            "js_intel": {
                "files_analyzed" : len(self.report.js_intel.files) if self.report.js_intel else 0,
                "api_urls"       : self.report.js_intel.all_api_urls[:100] if self.report.js_intel else [],
                "api_paths"      : self.report.js_intel.all_api_paths[:200] if self.report.js_intel else [],
                "transfer_paths" : self.report.js_intel.all_transfer_paths if self.report.js_intel else [],
                "auth_headers"   : self.report.js_intel.all_auth_headers if self.report.js_intel else [],
                "api_keys"       : self.report.js_intel.all_api_keys if self.report.js_intel else [],
                "s3_buckets"     : self.report.js_intel.all_s3_buckets if self.report.js_intel else [],
                "private_ips"    : self.report.js_intel.all_private_ips if self.report.js_intel else [],
                "websockets"     : self.report.js_intel.all_websockets if self.report.js_intel else [],
                "firebase"       : self.report.js_intel.all_firebase if self.report.js_intel else [],
            },
            "crawled_links": [
                {"url": l.url, "status": l.status}
                for l in self.report.crawled_links[:2000]
            ],
            "parameters": [
                {"url": p.url, "name": p.name, "method": p.method, "type": p.type}
                for p in self.report.parameters
            ],
            "findings": [
                {
                    "severity"    : f.severity,
                    "title"       : f.title,
                    "url"         : f.url,
                    "evidence"    : f.evidence,
                    "module"      : f.module,
                    "cve"         : f.cve,
                    "remediation" : f.remediation,
                    "tags"        : f.tags,
                }
                for f in self.report.all_findings()
            ],
            "modules": self._modules_to_dict(),
        }

        out_path = self.output_dir / "report.json"
        out_path.write_text(json.dumps(data, indent=2, ensure_ascii=False))

    def _modules_to_dict(self) -> Dict:
        result = {}
        for attr in vars(self.report):
            if attr.startswith("module_"):
                mod = getattr(self.report, attr)
                if mod:
                    result[attr] = {
                        "status"      : mod.status,
                        "duration_sec": mod.duration_sec,
                        "started_at"  : mod.started_at,
                        "finished_at" : mod.finished_at,
                        "error"       : mod.error,
                        "summary"     : mod.summary,
                        "findings_count": len(mod.findings),
                    }
        return result

    # ─── Markdown ────────────────────────────────────────────────────

    def write_markdown(self):
        lines = []
        r     = self.report
        stats = r.stats()
        all_f = r.all_findings()
        now   = datetime.utcnow().strftime("%Y-%m-%d %H:%M UTC")

        # ── Header ────────────────────────────────────────────────────
        lines += [
            f"# AeroSecLab Recon Report",
            f"",
            f"**Target:** `{r.target}`  ",
            f"**Generated:** {now}  ",
            f"**Engine:** AeroSecLab Recon Engine v{r.engine_version}  ",
            f"",
            f"---",
            f"",
        ]

        # ── Summary stats ─────────────────────────────────────────────
        lines += [
            f"## Summary",
            f"",
            f"| Metric | Count |",
            f"|--------|-------|",
            f"| Subdomains | {stats['subdomains_found']} |",
            f"| Live Hosts | {stats['live_hosts']} |",
            f"| Open Ports | {stats['open_ports_total']} |",
            f"| JS Files Analyzed | {stats['js_files_analyzed']} |",
            f"| Links Crawled | {stats['links_crawled']} |",
            f"| Parameters Found | {stats['parameters_found']} |",
            f"| **Total Findings** | **{stats['total_findings']}** |",
            f"| 🔴 Critical | {stats['critical']} |",
            f"| 🟠 High | {stats['high']} |",
            f"| 🟡 Medium | {stats['medium']} |",
            f"| 🔵 Low | {stats['low']} |",
            f"| ⚪ Info | {stats['info']} |",
            f"",
        ]

        # ── WHOIS ──────────────────────────────────────────────────────
        if r.whois:
            w = r.whois
            lines += [
                f"## WHOIS",
                f"",
                f"- **Registrar:** {w.registrar}",
                f"- **Registered:** {w.registered}",
                f"- **Expires:** {w.expires}",
                f"- **Registrant Org:** {w.registrant_org}",
                f"- **Country:** {w.registrant_country}",
                f"- **Name Servers:** {', '.join(w.name_servers)}",
                f"- **Emails:** {', '.join(w.emails)}",
                f"",
            ]

        # ── ASN ────────────────────────────────────────────────────────
        if r.asn:
            a = r.asn
            lines += [
                f"## ASN / Network",
                f"",
                f"- **ASN:** {a.asn}",
                f"- **Org:** {a.org}",
                f"- **Country:** {a.country}",
                f"- **IPv4 Prefixes:** {', '.join(a.prefixes_v4[:10])}",
                f"",
            ]

        # ── DNS Records ───────────────────────────────────────────────
        if r.dns_records:
            lines += [f"## DNS Records", f"", f"```"]
            for rec in r.dns_records:
                lines.append(f"{rec.type:8} {rec.value}")
            lines += [f"```", f""]

        # ── Findings ──────────────────────────────────────────────────
        lines += [f"## Findings", f""]

        for sev in ["critical", "high", "medium", "low", "info"]:
            sev_findings = [f for f in all_f if f.severity == sev]
            if not sev_findings:
                continue
            emoji = SEVERITY_EMOJI[sev]
            lines.append(f"### {emoji} {sev.upper()} ({len(sev_findings)})")
            lines.append("")
            for i, f in enumerate(sev_findings, 1):
                lines += [
                    f"#### {i}. {f.title}",
                    f"",
                    f"- **URL:** `{f.url}`",
                    f"- **Module:** `{f.module}`",
                    f"- **CVE:** {f.cve or 'N/A'}",
                    f"- **Evidence:**",
                    f"  ```",
                    f"  {f.evidence[:400]}",
                    f"  ```",
                    f"- **Remediation:** {f.remediation}",
                    f"- **Tags:** {', '.join(f.tags)}",
                    f"",
                ]

        # ── Subdomains ────────────────────────────────────────────────
        lines += [f"## Subdomains ({len(r.subdomains)})", f""]
        lines += [f"| FQDN | IPs | Status | CDN | Title |"]
        lines += [f"|------|-----|--------|-----|-------|"]
        for sub in sorted(r.subdomains, key=lambda x: x.fqdn):
            ips    = ", ".join(sub.ips[:2])
            status = sub.live_host.status if sub.live_host else ""
            cdn    = sub.live_host.cdn    if sub.live_host else ""
            title  = (sub.live_host.title or "")[:50] if sub.live_host else ""
            lines.append(f"| `{sub.fqdn}` | {ips} | {status} | {cdn} | {title} |")
        lines.append("")

        # ── Live Hosts ────────────────────────────────────────────────
        lines += [f"## Live Hosts ({len(r.live_hosts)})", f""]
        for host in r.live_hosts:
            tech_str = ", ".join(t.name for t in host.tech
                                if t.category not in ("security", "finding"))[:100]
            ports_str = ", ".join(f"{p.port}/{p.protocol}" for p in host.ports[:10])
            lines += [
                f"### `{host.fqdn}`",
                f"",
                f"- **URL:** {host.url}",
                f"- **Status:** {host.status}",
                f"- **Title:** {host.title}",
                f"- **Server:** {host.server}",
                f"- **CDN:** {host.cdn or 'none'}",
                f"- **WAF:** {host.waf or 'none'}",
                f"- **Tech:** {tech_str}",
                f"- **Ports:** {ports_str or 'none scanned'}",
                f"- **SPA:** {'yes' if host.is_spa else 'no'}",
                f"",
            ]

        # ── JS Intelligence ────────────────────────────────────────────
        if r.js_intel and (r.js_intel.all_api_paths or r.js_intel.all_transfer_paths):
            lines += [f"## JS Intelligence", f""]
            if r.js_intel.all_transfer_paths:
                lines += [f"### Financial API Paths", f""]
                lines += [f"```"]
                lines += r.js_intel.all_transfer_paths[:30]
                lines += [f"```", f""]
            if r.js_intel.all_websockets:
                lines += [f"### WebSocket Endpoints", f""]
                lines += [f"```"]
                lines += r.js_intel.all_websockets[:10]
                lines += [f"```", f""]
            if r.js_intel.all_private_ips:
                lines += [f"### Private IPs in JS", f""]
                lines += [f"```"]
                lines += r.js_intel.all_private_ips
                lines += [f"```", f""]
            if r.js_intel.all_s3_buckets:
                lines += [f"### S3 Buckets", f""]
                lines += [f"```"]
                lines += r.js_intel.all_s3_buckets
                lines += [f"```", f""]

        # ── Parameters ────────────────────────────────────────────────
        if r.parameters:
            interesting = [p for p in r.parameters
                          if p.name.lower() in {
                              "id","user_id","uid","redirect","url","file",
                              "webhook","debug","token","path","include",
                          }]
            if interesting:
                lines += [f"## High-Value Parameters", f""]
                lines += [f"| URL | Name | Method | Type |"]
                lines += [f"|-----|------|--------|------|"]
                for p in interesting[:50]:
                    lines.append(f"| `{p.url[:60]}` | `{p.name}` | {p.method} | {p.type} |")
                lines.append("")

        # ── Module Status ─────────────────────────────────────────────
        lines += [f"## Module Status", f""]
        lines += [f"| Module | Status | Duration | Findings |"]
        lines += [f"|--------|--------|----------|---------|"]
        for attr in vars(r):
            if attr.startswith("module_"):
                mod = getattr(r, attr)
                if mod:
                    icon = "✅" if mod.status == "ok" else "❌"
                    lines.append(
                        f"| {attr.replace('module_', '')} | "
                        f"{icon} {mod.status} | "
                        f"{mod.duration_sec:.1f}s | "
                        f"{len(mod.findings)} |"
                    )
        lines.append("")

        out_path = self.output_dir / "report.md"
        out_path.write_text("\n".join(lines), encoding="utf-8")
