"""
AeroSecLab Recon Engine — Orchestrator
Coordinates execution of all recon modules in the correct phase order.
Handles parallelism within phases, error recovery, and progress tracking.
"""

from __future__ import annotations

import concurrent.futures
import sys
import time
import traceback
from datetime import datetime
from pathlib import Path
from typing import List, Optional, Set

from .models import ReconReport, ModuleReport
from .config import OUTPUT_BASE, ENGINE_VERSION
from .logger import log, banner, phase_header, C


# ─────────────────────────────────────────────
# PHASE DEFINITIONS
# ─────────────────────────────────────────────

PHASE_ORDER = [
    "passive",   # cert_transparency, dns_enum, osint, whois_asn
    "active",    # subdomain_brute, port_scan, web_probe, cdn_bypass
    "analysis",  # js_intel, link_crawler, param_extractor
]

ALL_MODULES = {
    "passive": [
        "cert_transparency",
        "dns_enum",
        "osint",
        "whois_asn",
    ],
    "active": [
        "subdomain_brute",
        "port_scan",
        "web_probe",
        "cdn_bypass",
    ],
    "analysis": [
        "js_intel",
        "link_crawler",
        "param_extractor",
    ],
}


# ─────────────────────────────────────────────
# ORCHESTRATOR
# ─────────────────────────────────────────────

class Orchestrator:
    def __init__(
        self,
        target     : str,
        phases     : Optional[Set[str]] = None,
        modules    : Optional[Set[str]] = None,
        output_dir : Optional[Path] = None,
    ):
        self.target     = target.lower().strip()
        self.phases     = phases or {"passive", "active", "analysis"}
        self.modules    = modules  # None = run all in selected phases
        self.output_dir = output_dir or (OUTPUT_BASE / self.target.replace(".", "_"))
        self.output_dir.mkdir(parents=True, exist_ok=True)

        self.report = ReconReport(
            target         = self.target,
            engine_version = ENGINE_VERSION,
        )

        self._start_time = time.time()

    # ─── Module runner ───────────────────────

    def _run_module(self, module_name: str) -> ModuleReport:
        """Import and execute a single module. Returns its ModuleReport."""
        mod_report = ModuleReport(module_name=module_name)
        mod_report.start()

        try:
            log("INFO", self.target, f"  Running module: {module_name}")

            # Dynamic import
            phase = self._get_phase(module_name)
            if phase is None:
                raise ValueError(f"Unknown module: {module_name}")

            module = self._import_module(phase, module_name)

            # Each module exposes a run(target, report, output_dir) function
            module.run(
                target     = self.target,
                report     = self.report,
                mod_report = mod_report,
                output_dir = self.output_dir,
            )

            mod_report.finish(status="ok")
            log("OK", self.target,
                f"  Module {module_name} finished in {mod_report.duration_sec:.1f}s"
                f" — {len(mod_report.findings)} finding(s)")

        except ImportError as e:
            err = f"Module import failed: {e}"
            log("ERR", self.target, f"  {err}")
            mod_report.finish(status="error", error=err)

        except Exception as e:
            err = f"{type(e).__name__}: {e}\n{traceback.format_exc()}"
            log("ERR", self.target, f"  Module {module_name} crashed: {e}")
            mod_report.finish(status="error", error=err)

        return mod_report

    def _import_module(self, phase: str, module_name: str):
        """Dynamically import a module from the correct phase package."""
        import importlib
        module_path = f"aerosec_recon.{phase}.{module_name}"
        return importlib.import_module(module_path)

    def _get_phase(self, module_name: str) -> Optional[str]:
        for phase, mods in ALL_MODULES.items():
            if module_name in mods:
                return phase
        return None

    def _attach_mod_report(self, module_name: str, mod_report: ModuleReport):
        """Attach module report to the unified ReconReport."""
        attr = f"module_{module_name}"
        if hasattr(self.report, attr):
            setattr(self.report, attr, mod_report)

    # ─── Phase runners ───────────────────────

    def _run_phase(self, phase: str, parallel: bool = True):
        """Run all modules in a phase, optionally in parallel."""
        modules_to_run = ALL_MODULES.get(phase, [])

        # Filter to selected modules if specified
        if self.modules:
            modules_to_run = [m for m in modules_to_run if m in self.modules]

        if not modules_to_run:
            return

        phase_header(self.target, phase, modules_to_run)

        if parallel and len(modules_to_run) > 1:
            # Run modules in parallel within the phase
            with concurrent.futures.ThreadPoolExecutor(
                max_workers=len(modules_to_run)
            ) as executor:
                futures = {
                    executor.submit(self._run_module, mod): mod
                    for mod in modules_to_run
                }
                for future in concurrent.futures.as_completed(futures):
                    mod_name   = futures[future]
                    mod_report = future.result()
                    self._attach_mod_report(mod_name, mod_report)
        else:
            # Sequential execution
            for mod in modules_to_run:
                mod_report = self._run_module(mod)
                self._attach_mod_report(mod, mod_report)

    # ─── Main pipeline ───────────────────────

    def run(self) -> ReconReport:
        """Execute the full recon pipeline."""
        banner(self.target)

        log("HEAD", self.target, f"Target     : {self.target}")
        log("HEAD", self.target, f"Phases     : {', '.join(sorted(self.phases))}")
        log("HEAD", self.target, f"Output dir : {self.output_dir}")
        log("HEAD", self.target, f"Started at : {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S UTC')}")

        for phase in PHASE_ORDER:
            if phase not in self.phases:
                log("INFO", self.target, f"Skipping phase: {phase}")
                continue

            # Passive runs sequentially (API rate limits)
            # Active and analysis run in parallel
            parallel = phase in ("active", "analysis")
            self._run_phase(phase, parallel=parallel)

        # Write reports
        self._write_reports()

        # Print summary
        self._print_summary()

        return self.report

    # ─── Reporting ───────────────────────────

    def _write_reports(self):
        """Write unified JSON and Markdown reports."""
        from ..export.report import Reporter
        reporter = Reporter(self.report, self.output_dir)
        reporter.write_json()
        reporter.write_markdown()
        log("OK", self.target,
            f"Reports written to {self.output_dir}")

    def _print_summary(self):
        elapsed = time.time() - self._start_time
        stats   = self.report.stats()
        all_f   = self.report.all_findings()

        print(f"\n{C.BOLD}{C.PURPLE}{'═'*65}{C.RESET}")
        print(f"{C.BOLD}  RECON COMPLETE — {self.target}{C.RESET}")
        print(f"{C.BOLD}{C.PURPLE}{'═'*65}{C.RESET}")
        print(f"  Total time     : {elapsed:.1f}s")
        print(f"  Subdomains     : {stats['subdomains_found']}")
        print(f"  Live hosts     : {stats['live_hosts']}")
        print(f"  Open ports     : {stats['open_ports_total']}")
        print(f"  JS files       : {stats['js_files_analyzed']}")
        print(f"  Links crawled  : {stats['links_crawled']}")
        print(f"  Parameters     : {stats['parameters_found']}")
        print(f"  Total findings : {stats['total_findings']}")
        print(f"  {C.RED}Critical : {stats['critical']}{C.RESET}  "
              f"{C.YELLOW}High: {stats['high']}{C.RESET}  "
              f"Medium: {stats['medium']}  Low: {stats['low']}")

        critical = [f for f in all_f if f.severity == "critical"]
        if critical:
            print(f"\n{C.RED}{C.BOLD}  !! CRITICAL FINDINGS:{C.RESET}")
            for f in critical:
                print(f"  {C.RED}[!!] {f.title}{C.RESET}")
                print(f"       {f.url}")
                print(f"       {f.evidence[:120]}")

        high = [f for f in all_f if f.severity == "high"]
        if high:
            print(f"\n{C.YELLOW}{C.BOLD}  ! HIGH FINDINGS:{C.RESET}")
            for f in high[:10]:
                print(f"  {C.YELLOW}[!] {f.title}{C.RESET}")
                print(f"      {f.url}")

        print(f"\n  {C.CYAN}Report : {self.output_dir / 'report.md'}{C.RESET}")
        print(f"  {C.CYAN}Data   : {self.output_dir / 'report.json'}{C.RESET}")
        print()


# ─────────────────────────────────────────────
# MULTI-TARGET RUNNER
# ─────────────────────────────────────────────

def run_targets(
    targets    : List[str],
    phases     : Set[str],
    modules    : Optional[Set[str]] = None,
    parallel   : int = 1,
    output_base: Optional[Path] = None,
) -> List[ReconReport]:
    """Run recon against multiple targets, optionally in parallel."""
    reports = []
    base    = output_base or OUTPUT_BASE

    def _run_one(target: str) -> ReconReport:
        orch = Orchestrator(
            target     = target,
            phases     = phases,
            modules    = modules,
            output_dir = base / target.replace(".", "_"),
        )
        return orch.run()

    if parallel > 1:
        with concurrent.futures.ThreadPoolExecutor(max_workers=parallel) as ex:
            futures = {ex.submit(_run_one, t): t for t in targets}
            for f in concurrent.futures.as_completed(futures):
                try:
                    reports.append(f.result())
                except Exception as e:
                    log("ERR", futures[f], f"Target failed: {e}")
    else:
        for t in targets:
            try:
                reports.append(_run_one(t))
            except Exception as e:
                log("ERR", t, f"Target failed: {e}")

    return reports
