"""
AeroSecLab Recon Engine — Installer
Auto-installs all required tools via apt, go install, and pip.
Run once before first use: python3 -m aerosec_recon.installer
"""

from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path


CYAN  = "\033[96m"
GREEN = "\033[92m"
RED   = "\033[91m"
YELLOW= "\033[93m"
BOLD  = "\033[1m"
DIM   = "\033[2m"
RESET = "\033[0m"


def log(level: str, msg: str):
    icons = {"OK": f"{GREEN}[+]{RESET}", "ERR": f"{RED}[-]{RESET}",
             "INFO": f"{CYAN}[*]{RESET}", "WARN": f"{YELLOW}[!]{RESET}"}
    print(f"{icons.get(level,'[?]')} {msg}", flush=True)


def run_cmd(cmd: list, timeout: int = 300) -> bool:
    try:
        result = subprocess.run(
            cmd, capture_output=True, text=True, timeout=timeout
        )
        return result.returncode == 0
    except Exception as e:
        log("ERR", f"Command failed: {e}")
        return False


def is_installed(binary: str) -> bool:
    import shutil
    return shutil.which(binary) is not None


def install_apt_packages():
    log("INFO", "Installing apt packages...")
    apt_packages = [
        "nmap", "masscan", "dnsutils", "whois", "curl", "ffuf",
        "gobuster", "whatweb", "dnsrecon", "git", "golang-go",
        "massdns", "python3-pip", "libpcap-dev", "unzip", "wget",
    ]
    run_cmd(["apt-get", "update", "-qq"])
    for pkg in apt_packages:
        if run_cmd(["apt-get", "install", "-y", "-qq", pkg]):
            log("OK", f"  apt: {pkg}")
        else:
            log("WARN", f"  apt: {pkg} — failed (may already be installed)")


def install_go_tools():
    log("INFO", "Installing Go tools...")

    go_tools = [
        ("subfinder",   "github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest"),
        ("httpx",       "github.com/projectdiscovery/httpx/cmd/httpx@latest"),
        ("dnsx",        "github.com/projectdiscovery/dnsx/cmd/dnsx@latest"),
        ("katana",      "github.com/projectdiscovery/katana/cmd/katana@latest"),
        ("naabu",       "github.com/projectdiscovery/naabu/v2/cmd/naabu@latest"),
        ("nuclei",      "github.com/projectdiscovery/nuclei/v3/cmd/nuclei@latest"),
        ("tlsx",        "github.com/projectdiscovery/tlsx/cmd/tlsx@latest"),
        ("assetfinder", "github.com/tomnomnom/assetfinder@latest"),
        ("waybackurls", "github.com/tomnomnom/waybackurls@latest"),
        ("gau",         "github.com/lc/gau/v2/cmd/gau@latest"),
        ("hakrawler",   "github.com/hakluke/hakrawler@latest"),
        ("gowitness",   "github.com/sensepost/gowitness@latest"),
        ("findomain",   "github.com/Edu4rdSHL/findomain@latest"),
        ("amass",       "github.com/owasp-amass/amass/v4/...@latest"),
    ]

    go_path = _get_go_path()
    if not go_path:
        log("ERR", "go not found — skipping Go tools. Install Go first.")
        return

    # Set GOPATH env
    gopath = os.environ.get("GOPATH", str(Path.home() / "go"))
    env    = {**os.environ, "GOPATH": gopath, "PATH": f"{gopath}/bin:{os.environ.get('PATH','')}"}

    for binary, pkg in go_tools:
        if is_installed(binary):
            log("OK", f"  go: {binary} (already installed)")
            continue
        log("INFO", f"  go install {binary}...")
        try:
            result = subprocess.run(
                [go_path, "install", pkg],
                env=env, capture_output=True, text=True, timeout=300
            )
            if result.returncode == 0:
                log("OK", f"  go: {binary}")
            else:
                log("WARN", f"  go: {binary} — {result.stderr[:100]}")
        except subprocess.TimeoutExpired:
            log("WARN", f"  go: {binary} — timed out")
        except Exception as e:
            log("ERR", f"  go: {binary} — {e}")


def install_pip_packages():
    log("INFO", "Installing pip packages...")
    pip_packages = [
        "requests", "urllib3", "wafw00f", "arjun", "paramspider",
    ]
    for pkg in pip_packages:
        if run_cmd([sys.executable, "-m", "pip", "install",
                    pkg, "--break-system-packages", "-q"]):
            log("OK", f"  pip: {pkg}")
        else:
            log("WARN", f"  pip: {pkg} — failed")


def install_wafw00f():
    """Install wafw00f separately as it may need special handling."""
    if is_installed("wafw00f"):
        log("OK", "  wafw00f already installed")
        return
    cmds = [
        [sys.executable, "-m", "pip", "install", "wafw00f", "--break-system-packages"],
        ["pip3", "install", "wafw00f", "--break-system-packages"],
        ["pip", "install", "wafw00f"],
    ]
    for cmd in cmds:
        if run_cmd(cmd):
            log("OK", "  wafw00f installed")
            return
    log("WARN", "  wafw00f install failed — WAF detection will use header-based fallback")


def setup_wordlists():
    """Ensure wordlists are available."""
    log("INFO", "Setting up wordlists...")

    # SecLists — install if not present
    seclists_path = Path("/usr/share/seclists")
    if not seclists_path.exists():
        log("INFO", "  Installing SecLists...")
        if run_cmd(["apt-get", "install", "-y", "-qq", "seclists"]):
            log("OK", "  SecLists installed")
        else:
            # Try git clone
            log("INFO", "  Cloning SecLists from GitHub...")
            run_cmd([
                "git", "clone", "--depth", "1",
                "https://github.com/danielmiessler/SecLists.git",
                str(seclists_path)
            ], timeout=600)
    else:
        log("OK", "  SecLists already present")

    # Generate exchange-specific wordlist
    _generate_exchange_wordlist()


def _generate_exchange_wordlist():
    from core.config import EXCHANGE_SUBDOMAINS
    wl_dir = Path(__file__).parent / "wordlists"
    wl_dir.mkdir(exist_ok=True)
    wl_path = wl_dir / "exchange_subdomains.txt"
    wl_path.write_text("\n".join(EXCHANGE_SUBDOMAINS))
    log("OK", f"  Exchange wordlist: {len(EXCHANGE_SUBDOMAINS)} entries → {wl_path}")


def _get_go_path() -> str:
    import shutil
    for candidate in [
        "/usr/local/go/bin/go",
        "/usr/bin/go",
        shutil.which("go"),
    ]:
        if candidate and Path(candidate).exists():
            return candidate
    return ""


def verify_installation():
    """Check which tools are installed and report status."""
    from core.config import TOOL_PATHS
    print(f"\n{BOLD}Tool Verification:{RESET}")
    print(f"{'Tool':<20} {'Status':<10} {'Path'}")
    print("-" * 60)
    for tool_name, paths in sorted(TOOL_PATHS.items()):
        found_path = None
        for p in paths:
            if p and Path(p).exists():
                found_path = p
                break
        if found_path:
            print(f"  {tool_name:<18} {GREEN}✓ found{RESET}  {found_path}")
        else:
            print(f"  {tool_name:<18} {RED}✗ missing{RESET}")
    print()


def install_all():
    print(f"""
{BOLD}{CYAN}
╔══════════════════════════════════════════════════════════╗
║      AeroSecLab Recon Engine — Tool Installer            ║
╚══════════════════════════════════════════════════════════╝{RESET}
""")
    if os.geteuid() != 0:
        log("WARN", "Not running as root — apt installs may fail. Consider: sudo python3 installer.py")

    install_apt_packages()
    install_go_tools()
    install_pip_packages()
    install_wafw00f()
    setup_wordlists()
    verify_installation()
    log("OK", "Installation complete. Run: python3 run.py --target example.com")


if __name__ == "__main__":
    install_all()
