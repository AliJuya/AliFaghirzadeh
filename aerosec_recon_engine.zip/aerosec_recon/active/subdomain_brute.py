"""
AeroSecLab Recon Engine — Active: Subdomain Brute Force
Tools: subfinder, amass, assetfinder, findomain, ffuf, gobuster
Also adds exchange-specific wordlist probing.
"""

from __future__ import annotations

import concurrent.futures
import json
import socket
import tempfile
from pathlib import Path
from typing import List, Set

from ..core.models import ModuleReport, ReconReport, Subdomain, Finding
from ..core.config import (
    get_tool, TOOL_TIMEOUT, EXCHANGE_SUBDOMAINS,
    MAX_THREADS_SUBDOMAIN_PROBE, FFUF_RATE,
)
from ..core.logger import log, progress
from ..core.http_utils import run_tool


MODULE_NAME = "subdomain_brute"

# Wordlist paths - use Kali's built-in lists
WORDLIST_PATHS = [
    "/usr/share/seclists/Discovery/DNS/subdomains-top1million-110000.txt",
    "/usr/share/seclists/Discovery/DNS/subdomains-top1million-20000.txt",
    "/usr/share/seclists/Discovery/DNS/dns-Jhaddix.txt",
    "/usr/share/wordlists/dirb/common.txt",
    "/usr/share/amass/wordlists/subdomains.lst",
]


def run(
    target     : str,
    report     : ReconReport,
    mod_report : ModuleReport,
    output_dir : Path,
):
    log("INFO", target, "Subdomain Brute Force — starting")
    found: Set[str] = set()

    # ── subfinder ────────────────────────────────────────────────────
    if get_tool("subfinder"):
        sf_subs = _run_subfinder(target, output_dir)
        found  |= sf_subs
        log("OK", target, f"  subfinder → {len(sf_subs)}")
    else:
        log("WARN", target, "  subfinder not found — skipping")

    # ── amass passive ────────────────────────────────────────────────
    if get_tool("amass"):
        amass_subs = _run_amass(target, output_dir)
        found     |= amass_subs
        log("OK", target, f"  amass → {len(amass_subs)}")
    else:
        log("WARN", target, "  amass not found — skipping")

    # ── assetfinder ──────────────────────────────────────────────────
    if get_tool("assetfinder"):
        af_subs = _run_assetfinder(target)
        found  |= af_subs
        log("OK", target, f"  assetfinder → {len(af_subs)}")

    # ── findomain ────────────────────────────────────────────────────
    if get_tool("findomain"):
        fd_subs = _run_findomain(target, output_dir)
        found  |= fd_subs
        log("OK", target, f"  findomain → {len(fd_subs)}")

    # ── DNS brute force with wordlist ─────────────────────────────────
    wordlist = _get_best_wordlist()
    if wordlist and get_tool("ffuf"):
        bf_subs = _run_ffuf_dns(target, wordlist, output_dir)
        found  |= bf_subs
        log("OK", target, f"  ffuf DNS brute → {len(bf_subs)}")
    elif wordlist:
        # Fallback: manual resolution
        bf_subs = _manual_brute(target, wordlist)
        found  |= bf_subs
        log("OK", target, f"  manual DNS brute → {len(bf_subs)}")

    # ── Exchange-specific wordlist ────────────────────────────────────
    exchange_subs = _exchange_wordlist_probe(target)
    found        |= exchange_subs
    log("OK", target, f"  exchange wordlist → {len(exchange_subs)}")

    # ── Permutation/alteration brute force ───────────────────────────
    existing_labels = {s.fqdn.replace(f".{target}", "")
                       for s in report.subdomains if s.fqdn.endswith(f".{target}")}
    perm_subs = _permutation_brute(target, list(existing_labels)[:50])
    found    |= perm_subs
    log("OK", target, f"  permutation → {len(perm_subs)}")

    # ── Merge ─────────────────────────────────────────────────────────
    existing  = {s.fqdn for s in report.subdomains}
    new_count = 0
    for fqdn in sorted(found):
        if fqdn not in existing:
            report.subdomains.append(Subdomain(fqdn=fqdn, source=MODULE_NAME))
            existing.add(fqdn)
            new_count += 1

    # Save output
    (output_dir / f"{MODULE_NAME}_raw.txt").write_text("\n".join(sorted(found)))

    mod_report.summary = {
        "total_found"   : len(found),
        "new_subdomains": new_count,
        "tools_used"    : [t for t in ["subfinder","amass","assetfinder","findomain","ffuf"]
                          if get_tool(t)],
    }
    mod_report.data = {"subdomains": sorted(found)}
    log("OK", target, f"  Brute force complete: {len(found)} found ({new_count} new)")


# ─────────────────────────────────────────────
# TOOL RUNNERS
# ─────────────────────────────────────────────

def _run_subfinder(target: str, output_dir: Path) -> Set[str]:
    subs     = set()
    out_file = str(output_dir / "subfinder.txt")
    tool     = get_tool("subfinder")

    stdout, stderr, rc = run_tool(
        [
            tool, "-d", target,
            "-all",               # Use all sources
            "-recursive",
            "-silent",
            "-o", out_file,
            "-t", "100",          # 100 threads
            "-timeout", "30",
        ],
        timeout=TOOL_TIMEOUT,
        target=target,
    )

    out_path = Path(out_file)
    if out_path.exists():
        for line in out_path.read_text().splitlines():
            line = line.strip().lower()
            if line.endswith(f".{target}") or line == target:
                subs.add(line)
    return subs


def _run_amass(target: str, output_dir: Path) -> Set[str]:
    subs     = set()
    out_file = str(output_dir / "amass.txt")
    tool     = get_tool("amass")

    stdout, stderr, rc = run_tool(
        [
            tool, "enum",
            "-passive",
            "-d", target,
            "-o", out_file,
            "-timeout", "10",
        ],
        timeout=TOOL_TIMEOUT,
        target=target,
    )

    out_path = Path(out_file)
    if out_path.exists():
        for line in out_path.read_text().splitlines():
            line = line.strip().lower()
            if line.endswith(f".{target}") or line == target:
                subs.add(line)

    return subs


def _run_assetfinder(target: str) -> Set[str]:
    subs    = set()
    tool    = get_tool("assetfinder")
    stdout, _, _ = run_tool(
        [tool, "--subs-only", target],
        timeout=60,
        target=target,
    )
    for line in stdout.splitlines():
        line = line.strip().lower()
        if line.endswith(f".{target}") or line == target:
            subs.add(line)
    return subs


def _run_findomain(target: str, output_dir: Path) -> Set[str]:
    subs     = set()
    out_file = str(output_dir / "findomain.txt")
    tool     = get_tool("findomain")

    stdout, _, _ = run_tool(
        [tool, "-t", target, "-u", out_file, "--quiet"],
        timeout=120,
        target=target,
    )

    out_path = Path(out_file)
    if out_path.exists():
        for line in out_path.read_text().splitlines():
            line = line.strip().lower()
            if line.endswith(f".{target}") or line == target:
                subs.add(line)
    return subs


def _run_ffuf_dns(target: str, wordlist: str, output_dir: Path) -> Set[str]:
    """DNS subdomain brute force using ffuf with virtual host mode."""
    subs     = set()
    out_file = str(output_dir / "ffuf_dns.json")
    tool     = get_tool("ffuf")

    # Use ffuf in DNS resolution mode via vhost fuzzing
    stdout, _, rc = run_tool(
        [
            tool,
            "-u", f"https://{target}",
            "-H", f"Host: FUZZ.{target}",
            "-w", wordlist,
            "-rate", str(FFUF_RATE),
            "-t", "100",
            "-timeout", "5",
            "-mc", "200,301,302,400,401,403,405,500",
            "-fc", "404",
            "-o", out_file,
            "-of", "json",
            "-s",
        ],
        timeout=TOOL_TIMEOUT,
        target=target,
    )

    out_path = Path(out_file)
    if out_path.exists():
        try:
            data = json.loads(out_path.read_text())
            for result in data.get("results", []):
                word = result.get("input", {}).get("FUZZ", "")
                if word:
                    fqdn = f"{word.lower()}.{target}"
                    subs.add(fqdn)
        except Exception:
            pass

    return subs


def _get_best_wordlist() -> str:
    """Return the best available DNS wordlist."""
    for path in WORDLIST_PATHS:
        if Path(path).exists():
            return path
    return ""


def _manual_brute(target: str, wordlist: str) -> Set[str]:
    """Fallback DNS brute force using socket resolution."""
    subs  = set()
    try:
        with open(wordlist) as f:
            words = [line.strip() for line in f
                    if line.strip() and not line.startswith("#")][:5000]
    except Exception:
        return subs

    def resolve(word: str):
        fqdn = f"{word}.{target}"
        try:
            socket.gethostbyname(fqdn)
            return fqdn
        except Exception:
            return None

    with concurrent.futures.ThreadPoolExecutor(max_workers=MAX_THREADS_SUBDOMAIN_PROBE) as ex:
        done = 0
        for result in ex.map(resolve, words):
            done += 1
            if done % 100 == 0:
                progress(done, len(words), "DNS brute force")
            if result:
                subs.add(result)

    return subs


# ─────────────────────────────────────────────
# EXCHANGE-SPECIFIC WORDLIST
# ─────────────────────────────────────────────

def _exchange_wordlist_probe(target: str) -> Set[str]:
    """Resolve all exchange-specific subdomain prefixes."""
    subs  = set()
    fqdns = [f"{prefix}.{target}" for prefix in EXCHANGE_SUBDOMAINS]

    def resolve(fqdn: str):
        try:
            socket.gethostbyname(fqdn)
            return fqdn
        except Exception:
            return None

    with concurrent.futures.ThreadPoolExecutor(
        max_workers=MAX_THREADS_SUBDOMAIN_PROBE
    ) as ex:
        for result in ex.map(resolve, fqdns):
            if result:
                subs.add(result)

    return subs


# ─────────────────────────────────────────────
# PERMUTATION BRUTE FORCE
# ─────────────────────────────────────────────

PERMUTATION_PREFIXES = [
    "dev", "test", "stg", "staging", "prod", "production",
    "new", "old", "legacy", "v1", "v2", "v3", "beta", "alpha",
    "internal", "ext", "external", "pub", "private", "priv",
    "backup", "bak", "archive", "temp", "tmp",
    "us", "eu", "ap", "sg", "uk", "tr", "ir",
    "east", "west", "north", "south", "central",
    "lb", "cdn", "cache", "static", "media",
    "primary", "secondary", "replica", "slave", "master",
    "k8s", "kube", "docker", "container",
    "0", "1", "2", "3", "01", "02", "03",
]

PERMUTATION_SUFFIXES = [
    "-dev", "-test", "-stg", "-staging", "-prod",
    "-new", "-old", "-v1", "-v2", "-api", "-app",
    "-internal", "-external", "-pub", "-private",
    "-backup", "-bak", "-temp", "-1", "-2", "-3",
    "1", "2", "3", "01", "02",
]


def _permutation_brute(target: str, existing_labels: List[str]) -> Set[str]:
    """Generate and resolve permutations of existing subdomains."""
    subs      = set()
    candidates= set()

    for label in existing_labels[:30]:
        # prefix permutations
        for pref in PERMUTATION_PREFIXES:
            candidates.add(f"{pref}-{label}.{target}")
            candidates.add(f"{pref}.{label}.{target}")
            candidates.add(f"{label}-{pref}.{target}")
        # suffix permutations
        for suf in PERMUTATION_SUFFIXES:
            candidates.add(f"{label}{suf}.{target}")

    def resolve(fqdn: str):
        try:
            socket.gethostbyname(fqdn)
            return fqdn
        except Exception:
            return None

    with concurrent.futures.ThreadPoolExecutor(max_workers=50) as ex:
        for result in ex.map(resolve, list(candidates)):
            if result:
                subs.add(result)

    return subs
