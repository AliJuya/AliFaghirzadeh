"""
AeroSecLab Recon Engine — Analysis: JS Intelligence
Downloads and mines all JavaScript bundles for secrets, endpoints,
internal IPs, WebSocket channels, API keys, and more.
"""

from __future__ import annotations

import concurrent.futures
import json
import re
from pathlib import Path
from typing import Dict, List, Optional, Set
from urllib.parse import urljoin, urlparse

import requests

from ..core.models import (
    ModuleReport, ReconReport, JSFile, JSIntelligence, Finding
)
from ..core.config import (
    JS_PATTERNS, API_KEY_PATTERNS, REQUEST_TIMEOUT,
    MAX_JS_FILES, MAX_JS_SIZE_MB, MAX_THREADS_JS,
)
from ..core.logger import log, progress
from ..core.http_utils import safe_get, make_session


MODULE_NAME = "js_intel"

JS_EXTENSION_RE = re.compile(r'\.js(\?[^"\']*)?$', re.I)
INLINE_JS_RE    = re.compile(r'<script[^>]*>(.*?)</script>', re.S | re.I)
SRC_RE          = re.compile(r'<script[^>]+src=["\']([^"\']+)["\']', re.I)
LINK_RE         = re.compile(r'(?:href|src|action)=["\']([^"\']+)["\']', re.I)

# Transfer / finance endpoint keywords
TRANSFER_KEYWORDS = [
    "transfer", "withdraw", "deposit", "send", "fund", "payout",
    "remit", "pay", "wallet", "balance", "invoice", "checkout",
]

# Auth / API header keywords
AUTH_HEADER_KEYWORDS = [
    "authorization", "x-auth", "x-api-key", "x-token", "x-access-token",
    "x-bitlo-auth", "x-tabdeal", "x-session", "x-client-id",
    "api-key", "apikey",
]


def run(
    target     : str,
    report     : ReconReport,
    mod_report : ModuleReport,
    output_dir : Path,
):
    log("INFO", target, "JS Intelligence — starting")

    # Collect all JS file URLs from live hosts
    js_urls: Set[str] = set()

    for host in report.live_hosts:
        host_js = _discover_js_urls(host.url, host.fqdn)
        js_urls.update(host_js)

    log("INFO", target, f"  Discovered {len(js_urls)} JS file URLs")

    # Cap to avoid spending too long
    js_url_list = list(js_urls)[:MAX_JS_FILES * 3]

    # Download and analyze JS files in parallel
    js_files: List[JSFile] = []
    done = 0

    with concurrent.futures.ThreadPoolExecutor(max_workers=MAX_THREADS_JS) as ex:
        futures = {ex.submit(_analyze_js_url, url, target): url
                   for url in js_url_list}
        for f in concurrent.futures.as_completed(futures):
            done += 1
            if done % 5 == 0:
                progress(done, len(js_url_list), "JS analysis")
            result = f.result()
            if result:
                js_files.append(result)
                if len(js_files) >= MAX_JS_FILES:
                    # Cancel remaining
                    for pending in futures:
                        if not pending.done():
                            pending.cancel()
                    break

    log("OK", target, f"  Analyzed {len(js_files)} JS files")

    # Build aggregate intelligence object
    intel = _aggregate(js_files)
    report.js_intel = intel

    # Generate findings
    findings = _generate_findings(intel, target, report)
    mod_report.findings.extend(findings)

    # Save raw intel to disk
    _save_intel(intel, output_dir)

    # Summary
    mod_report.summary = {
        "js_files_analyzed"   : len(js_files),
        "api_urls"            : len(intel.all_api_urls),
        "api_paths"           : len(intel.all_api_paths),
        "transfer_paths"      : len(intel.all_transfer_paths),
        "auth_headers"        : len(intel.all_auth_headers),
        "api_keys"            : len(intel.all_api_keys),
        "jwt_secrets"         : len(intel.all_jwt_secrets),
        "s3_buckets"          : len(intel.all_s3_buckets),
        "private_ips"         : len(intel.all_private_ips),
        "websockets"          : len(intel.all_websockets),
        "firebase"            : len(intel.all_firebase),
        "findings"            : len(findings),
    }
    mod_report.data = {
        "api_urls"      : intel.all_api_urls[:100],
        "api_paths"     : intel.all_api_paths[:200],
        "transfer_paths": intel.all_transfer_paths,
        "auth_headers"  : intel.all_auth_headers,
        "api_keys"      : intel.all_api_keys,
        "jwt_secrets"   : ["[REDACTED]"] * len(intel.all_jwt_secrets),
        "s3_buckets"    : intel.all_s3_buckets,
        "private_ips"   : intel.all_private_ips,
        "websockets"    : intel.all_websockets,
        "firebase"      : intel.all_firebase,
    }
    log("OK", target, f"  JS intel complete — {len(findings)} findings")


# ─────────────────────────────────────────────
# JS URL DISCOVERY
# ─────────────────────────────────────────────

def _discover_js_urls(base_url: str, fqdn: str) -> Set[str]:
    """Crawl a page and collect all JS file URLs."""
    urls = set()

    r = safe_get(base_url, allow_redirects=True, timeout=REQUEST_TIMEOUT)
    if not r:
        return urls

    html = r.text

    # Explicit <script src="..."> tags
    for src in SRC_RE.findall(html):
        full = _resolve_url(src, base_url)
        if full and _is_js(full):
            urls.add(full)

    # Webpack chunk discovery: look for chunk manifest patterns
    for pattern in [
        r'["\'](/[^"\']+\.chunk\.js)["\']',
        r'["\'](/static/js/[^"\']+\.js)["\']',
        r'["\'](/assets/[^"\']+\.js)["\']',
        r'["\']([^"\']+\.[a-f0-9]{8}\.js)["\']',  # hashed bundles
    ]:
        for match in re.findall(pattern, html):
            full = _resolve_url(match, base_url)
            if full:
                urls.add(full)

    # React/Next.js: look for _buildManifest.js and chunk files
    for pattern in [
        r'"(/_next/static/[^"]+\.js)"',
        r'"(/static/js/[^"]+\.js)"',
    ]:
        for match in re.findall(pattern, html):
            urls.add(_resolve_url(match, base_url))

    # Try common bundle paths
    common_paths = [
        "/static/js/main.js", "/static/js/bundle.js",
        "/js/app.js", "/js/main.js", "/js/bundle.js",
        "/assets/js/app.js", "/dist/bundle.js", "/dist/main.js",
        "/app.js", "/bundle.js", "/main.js",
        "/js/vendor.js", "/js/chunk-vendors.js",
        "/static/js/vendors~main.chunk.js",
    ]
    for path in common_paths:
        full = _resolve_url(path, base_url)
        if full:
            urls.add(full)

    return urls


def _resolve_url(path: str, base_url: str) -> Optional[str]:
    if not path or path.startswith("data:") or path.startswith("javascript:"):
        return None
    try:
        full = urljoin(base_url, path)
        parsed = urlparse(full)
        if parsed.scheme in ("http", "https"):
            return full
    except Exception:
        pass
    return None


def _is_js(url: str) -> bool:
    path = urlparse(url).path
    return JS_EXTENSION_RE.search(path) is not None


# ─────────────────────────────────────────────
# JS FILE ANALYSIS
# ─────────────────────────────────────────────

def _analyze_js_url(url: str, target: str) -> Optional[JSFile]:
    """Download and analyze a single JS file."""
    try:
        r = safe_get(url, timeout=REQUEST_TIMEOUT)
        if not r:
            return None

        ct = r.headers.get("content-type", "").lower()
        # Accept JS content types
        if r.status_code != 200:
            return None
        if ct and "html" in ct and "javascript" not in ct and "json" not in ct:
            return None

        content = r.text
        if not content:
            return None

        size_kb = len(content.encode("utf-8")) / 1024
        if size_kb > MAX_JS_SIZE_MB * 1024:
            log("WARN", target, f"  Skipping oversized JS: {url} ({size_kb:.0f}KB)")
            return None

        return _mine_js(url, content, size_kb)

    except Exception:
        return None


def _mine_js(url: str, content: str, size_kb: float) -> JSFile:
    """Extract intelligence from JS content."""
    js = JSFile(url=url, size_kb=round(size_kb, 1))

    # Run all patterns
    for pattern_name, pattern in JS_PATTERNS.items():
        try:
            matches = list(set(re.findall(pattern, content, re.I)))
            matches = [m if isinstance(m, str) else m[0] for m in matches]
            matches = [m.strip() for m in matches if m.strip()]

            if pattern_name == "api_base_urls":
                js.api_urls = _filter_urls(matches)
            elif pattern_name == "all_urls":
                # Merge into api_urls, filter for interesting ones
                extra = _filter_urls(matches)
                merged = list(set(js.api_urls + extra))
                js.api_urls = merged[:100]
            elif pattern_name == "api_paths":
                js.api_paths = sorted(set(matches))[:100]
            elif pattern_name == "transfer_paths":
                js.transfer_paths = sorted(set(matches))[:50]
            elif pattern_name == "auth_headers":
                js.auth_headers = matches[:20]
            elif pattern_name == "jwt_secrets":
                js.jwt_secrets = matches[:10]
            elif pattern_name == "s3_buckets":
                js.s3_buckets = sorted(set(matches))
            elif pattern_name == "private_ips":
                js.private_ips = sorted(set(matches))
            elif pattern_name == "websocket_urls":
                js.websockets = sorted(set(matches))
            elif pattern_name == "stomp_channels":
                js.stomp_channels = sorted(set(matches))[:30]
            elif pattern_name == "firebase":
                js.firebase = matches[:10]
            elif pattern_name == "google_oauth":
                js.google_oauth = matches[:5]
        except Exception:
            pass

    # Run API key patterns
    all_keys = []
    for key_name, pattern in API_KEY_PATTERNS.items():
        try:
            matches = re.findall(pattern, content)
            for match in matches:
                val = match if isinstance(match, str) else match[0]
                val = val.strip()
                if val and len(val) > 8:
                    all_keys.append(f"{key_name}:{val[:60]}")
        except Exception:
            pass
    js.api_keys = all_keys[:20]

    # Extract transfer/financial paths that may not match the strict pattern
    for keyword in TRANSFER_KEYWORDS:
        path_re = re.compile(
            rf'["\'](/[a-zA-Z0-9/_-]*{keyword}[a-zA-Z0-9/_.-]*)["\']',
            re.I
        )
        for match in path_re.findall(content):
            if match not in js.transfer_paths:
                js.transfer_paths.append(match)

    # Deduplicate
    js.transfer_paths = sorted(set(js.transfer_paths))[:100]

    # Internal service URLs (http://localhost, 127.0.0.1, internal hostnames)
    internal_re = re.compile(
        r'["\`]((?:http://(?:localhost|127\.0\.0\.1|0\.0\.0\.0)'
        r'|https?://(?:internal|intranet|local|dev-|staging-)'
        r')[a-zA-Z0-9:/_.-]*)["\`]',
        re.I
    )
    internal_urls = internal_re.findall(content)
    if internal_urls:
        for iurl in internal_urls[:20]:
            if iurl not in js.api_urls:
                js.api_urls.append(iurl)

    return js


def _filter_urls(urls: List[str]) -> List[str]:
    """Filter URL list to interesting ones (APIs, not CDN assets)."""
    skip_ext = {".png", ".jpg", ".gif", ".svg", ".ico", ".woff",
                ".woff2", ".ttf", ".css", ".mp4", ".webm"}
    result   = []
    for url in urls:
        path = urlparse(url).path.lower()
        if any(path.endswith(ext) for ext in skip_ext):
            continue
        # Keep API-looking URLs
        if any(kw in url.lower() for kw in [
            "api", "auth", "user", "account", "wallet", "trade",
            "market", "order", "deposit", "withdraw", "transfer",
            "payment", "fund", "balance", "portfolio", "localhost",
            "internal", ":1337", ":3000", ":8080", ":5000",
        ]):
            result.append(url)
        elif re.search(r'\.[a-z]{2,6}(?::\d+)?$', urlparse(url).netloc or ""):
            result.append(url)

    return list(set(result))[:150]


# ─────────────────────────────────────────────
# AGGREGATION
# ─────────────────────────────────────────────

def _aggregate(js_files: List[JSFile]) -> JSIntelligence:
    """Aggregate intelligence across all JS files."""
    intel = JSIntelligence(files=js_files)

    all_api_urls      : Set[str] = set()
    all_api_paths     : Set[str] = set()
    all_transfer_paths: Set[str] = set()
    all_auth_headers  : Set[str] = set()
    all_jwt_secrets   : Set[str] = set()
    all_api_keys      : Set[str] = set()
    all_s3_buckets    : Set[str] = set()
    all_private_ips   : Set[str] = set()
    all_websockets    : Set[str] = set()
    all_firebase      : Set[str] = set()

    for js in js_files:
        all_api_urls.update(js.api_urls)
        all_api_paths.update(js.api_paths)
        all_transfer_paths.update(js.transfer_paths)
        all_auth_headers.update(js.auth_headers)
        all_jwt_secrets.update(js.jwt_secrets)
        all_api_keys.update(js.api_keys)
        all_s3_buckets.update(js.s3_buckets)
        all_private_ips.update(js.private_ips)
        all_websockets.update(js.websockets)
        all_firebase.update(js.firebase)

    intel.all_api_urls      = sorted(all_api_urls)
    intel.all_api_paths     = sorted(all_api_paths)
    intel.all_transfer_paths= sorted(all_transfer_paths)
    intel.all_auth_headers  = sorted(all_auth_headers)
    intel.all_jwt_secrets   = sorted(all_jwt_secrets)
    intel.all_api_keys      = sorted(all_api_keys)
    intel.all_s3_buckets    = sorted(all_s3_buckets)
    intel.all_private_ips   = sorted(all_private_ips)
    intel.all_websockets    = sorted(all_websockets)
    intel.all_firebase      = sorted(all_firebase)

    return intel


# ─────────────────────────────────────────────
# FINDINGS GENERATION
# ─────────────────────────────────────────────

def _generate_findings(
    intel  : JSIntelligence,
    target : str,
    report : ReconReport,
) -> List[Finding]:
    findings = []

    # Private IPs in JS
    for ip in intel.all_private_ips:
        findings.append(Finding(
            severity    = "medium",
            title       = f"Private IP leaked in JavaScript: {ip}",
            url         = target,
            evidence    = f"Private IP {ip} found in JS bundle",
            module      = MODULE_NAME,
            remediation = "Remove internal IP references from client-side code",
            tags        = ["info-disclosure", "private-ip", "js"],
        ))

    # API keys / secrets
    for key_entry in intel.all_api_keys:
        key_type = key_entry.split(":")[0] if ":" in key_entry else "generic"
        val      = key_entry.split(":", 1)[1] if ":" in key_entry else key_entry

        sev = "critical" if key_type in (
            "aws_access_key", "stripe_live", "github_token", "private_key"
        ) else "high" if key_type in (
            "google_api", "firebase_key", "jwt_token", "bearer_token"
        ) else "medium"

        findings.append(Finding(
            severity    = sev,
            title       = f"Sensitive credential in JS bundle: {key_type}",
            url         = target,
            evidence    = f"Type: {key_type}  Value: {val[:50]}...",
            module      = MODULE_NAME,
            remediation = "Move all secrets to server-side environment variables; never embed in client JS",
            tags        = ["credentials", "secret", "js", key_type],
        ))

    # JWT secrets
    for secret in intel.all_jwt_secrets:
        findings.append(Finding(
            severity    = "critical",
            title       = "JWT signing secret exposed in JavaScript",
            url         = target,
            evidence    = f"Secret: {secret[:30]}...",
            module      = MODULE_NAME,
            remediation = "Rotate all JWT secrets immediately; never embed in client-side code",
            tags        = ["jwt", "credentials", "critical"],
        ))

    # Firebase API key + database URL
    if intel.all_firebase:
        firebase_block = "\n".join(intel.all_firebase[:10])
        findings.append(Finding(
            severity    = "high",
            title       = "Firebase configuration exposed in JavaScript",
            url         = target,
            evidence    = firebase_block[:300],
            module      = MODULE_NAME,
            remediation = "Implement Firebase Security Rules; restrict API key via HTTP referrer rules in GCP Console",
            tags        = ["firebase", "credentials", "js"],
        ))

    # S3 buckets
    for bucket in intel.all_s3_buckets:
        findings.append(Finding(
            severity    = "medium",
            title       = f"S3 bucket URL exposed: {bucket}",
            url         = f"https://{bucket}",
            evidence    = f"S3 bucket found in JS: {bucket}",
            module      = MODULE_NAME,
            remediation = "Verify bucket permissions; ensure no public access; check for bucket takeover if bucket name available",
            tags        = ["s3", "aws", "info-disclosure"],
        ))

    # WebSocket channels
    if intel.all_websockets:
        all_ws = "\n".join(intel.all_websockets[:10])
        findings.append(Finding(
            severity    = "info",
            title       = f"WebSocket endpoints found in JS ({len(intel.all_websockets)})",
            url         = target,
            evidence    = all_ws[:300],
            module      = MODULE_NAME,
            remediation = "Test WebSocket endpoints for authentication and authorization vulnerabilities",
            tags        = ["websocket", "info-disclosure"],
        ))

    # Financial transfer paths
    if intel.all_transfer_paths:
        paths_str = "\n".join(intel.all_transfer_paths[:20])
        findings.append(Finding(
            severity    = "info",
            title       = f"Financial API endpoints discovered in JS ({len(intel.all_transfer_paths)})",
            url         = target,
            evidence    = paths_str[:400],
            module      = MODULE_NAME,
            remediation = "Test all financial endpoints for authentication, authorization, and business logic flaws",
            tags        = ["financial-api", "attack-surface"],
        ))

    # Auth headers in client code
    for header in intel.all_auth_headers:
        if any(kw in header.lower() for kw in AUTH_HEADER_KEYWORDS):
            if len(header) > 20 and re.search(r'[a-zA-Z0-9_\-]{8,}', header):
                findings.append(Finding(
                    severity    = "high",
                    title       = f"Custom auth header hardcoded in JS",
                    url         = target,
                    evidence    = header[:100],
                    module      = MODULE_NAME,
                    remediation = "Never hardcode auth credentials in client-side code",
                    tags        = ["auth-header", "credentials"],
                ))

    return findings


# ─────────────────────────────────────────────
# OUTPUT
# ─────────────────────────────────────────────

def _save_intel(intel: JSIntelligence, output_dir: Path):
    """Save JS intelligence to structured files."""
    js_dir = output_dir / "js_intel"
    js_dir.mkdir(exist_ok=True)

    if intel.all_api_paths:
        (js_dir / "api_paths.txt").write_text("\n".join(sorted(intel.all_api_paths)))
    if intel.all_transfer_paths:
        (js_dir / "transfer_paths.txt").write_text("\n".join(sorted(intel.all_transfer_paths)))
    if intel.all_api_urls:
        (js_dir / "api_urls.txt").write_text("\n".join(sorted(intel.all_api_urls)))
    if intel.all_websockets:
        (js_dir / "websockets.txt").write_text("\n".join(sorted(intel.all_websockets)))
    if intel.all_private_ips:
        (js_dir / "private_ips.txt").write_text("\n".join(sorted(intel.all_private_ips)))
    if intel.all_api_keys:
        (js_dir / "api_keys.txt").write_text("\n".join(intel.all_api_keys))
    if intel.all_s3_buckets:
        (js_dir / "s3_buckets.txt").write_text("\n".join(sorted(intel.all_s3_buckets)))

    # Summary JSON
    summary = {
        "files_analyzed"  : len(intel.files),
        "api_urls"        : len(intel.all_api_urls),
        "api_paths"       : len(intel.all_api_paths),
        "transfer_paths"  : len(intel.all_transfer_paths),
        "api_keys"        : len(intel.all_api_keys),
        "jwt_secrets"     : len(intel.all_jwt_secrets),
        "s3_buckets"      : len(intel.all_s3_buckets),
        "private_ips"     : len(intel.all_private_ips),
        "websockets"      : len(intel.all_websockets),
        "firebase"        : len(intel.all_firebase),
    }
    (js_dir / "summary.json").write_text(json.dumps(summary, indent=2))
